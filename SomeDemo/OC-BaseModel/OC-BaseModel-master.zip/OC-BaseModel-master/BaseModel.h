//
//  BaseModel.h
//  NormalDemo
//
//  Created by YangTianCi on 2017/12/19.
//  Copyright © 2017年 ytc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject

-(instancetype)initWithDictionary:(NSDictionary*)dictionary;

@end
