




import 'package:flutter/material.dart';
import './GridWPage.dart';
import './ListWPage.dart';
import '../LoginModule/LoginPage.dart';
import '../CommonTool/NetWorkManager.dart';


class MainPage extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: new AppBar(
        title: new Text("MainPage"),
      ),
      body: mainListView(),
    );
  }


}



// 新建一个 list View

class mainListView extends StatefulWidget{

  @override
  State<StatefulWidget> createState() => new _mainListViewState();

}


class _mainListViewState extends State<mainListView>{

  void CellPressMethod(int idx){
    if(idx == 0){
      print(idx);
      Navigator.push(context, new MaterialPageRoute(builder: (context) => GridWPage()));
    }else if(idx == 1){
      Navigator.push(context, new MaterialPageRoute(builder: (context) => ListWPage()));
    }else if(idx == 2){
      Navigator.push(context, new MaterialPageRoute(builder: (context) => LoginPage()));
    }
  }



  @override 
  Widget build(BuildContext context) {
    // TODO: implement build
    return new ListView.builder(itemCount: 100,itemBuilder: buildItem,);
  }

  Widget buildItem (BuildContext context, int idx){

    var imgV = new Image.asset("images/lake.jpg",width: 50,height: 50,);
    var title = "";
    if(idx == 0){
      title = "GridView == CollectionView";
    }else if(idx == 1){
      title = "ListView == TableVIew";
    }else if(idx == 2){
      title = "登录界面";
    }
    else{
      title = "暂定";
    }

    return new Container(
      padding: new EdgeInsets.only(left: 20,right: 15),
      child: new Center(
        child: new Row(
          children: <Widget>[

            new Expanded(child:
            new Text(title,style: TextStyle(fontSize: 16,color: Colors.pink[200]),),
              flex: 3,
            ),

            new Expanded(child:
            new IconButton(icon: Icon(Icons.aspect_ratio), onPressed:(){
              CellPressMethod(idx);
            }),
            ),

            new Expanded(child:
              Container(
                child: imgV,
                width: 45,
                height: 30,
              )
            ),

          ],
        ),
      ),
    );

  }




}




