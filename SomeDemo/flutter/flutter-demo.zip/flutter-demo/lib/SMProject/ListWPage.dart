
import 'package:flutter/material.dart';

class ListWPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: new AppBar(
        title: new Text("MainPage"),
      ),
      body: ListWDemo(),
    );
  }
}


class ListWDemo extends StatefulWidget{

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _ListDemoState();
  }
}


class _ListDemoState extends State<ListWDemo>{




  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Container(
      child: CreatListView(),
    );



  }



  // listView
Widget CreatListView(){


//    return ListView.builder(itemBuilder: itemBuilder, itemCount: 10,);

return new ListView(

  children: ForCreatCell(20),
);


}


List<Widget> ForCreatCell(int Count){
    List<Widget> list = List();
    for(int i = 0; i < Count; i++){
      list.add(itemBuilder(context, i));
    }
    return list;
}

Widget itemBuilder (BuildContext context, int idx ){

    return new Container(
      height: 49,
      padding: EdgeInsets.only(left: 30,right: 15,top: 20),

        child: new Row(
          children: <Widget>[
            Expanded(
              flex: 4,
              child: new GestureDetector(
              child: new Container(
                child: new Text("tableviewDemo", style: TextStyle(fontSize: 16, color: Colors.pink[200]),),
                width: 220,
              ),
              onTap: (){
                print("click");
              },
            ),
            ),
            new GestureDetector(
              child: new Container(
                padding: EdgeInsets.only(right: 5),
                width: 50,
                height: 50,
                child: Image(image: new NetworkImage("https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=495625508," "3408544765&fm=27&gp=0.jpg"), fit: BoxFit.cover, width: 45, height: 30, ),
              ),
              onTap: (){
                print("emmmmm");
              },
            ),
          ],
        ),
    );
}



}
