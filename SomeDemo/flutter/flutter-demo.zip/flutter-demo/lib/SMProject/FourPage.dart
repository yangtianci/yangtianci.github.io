

import 'package:flutter/material.dart';



class fourPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: new AppBar(
        title: new Text("界面-4"),
      ),
      body: new Center(


      ),
    );
  }
}