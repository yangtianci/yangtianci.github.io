

import 'package:flutter/material.dart';


import './FourPage.dart';


class thirdPage extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
            appBar: new AppBar(
              title: new Text("界面-3"),
            ),
            body: new Center(

              child: CreatContentWid(context),

            ),
    );
  }




  Widget CreatContentWid (context){

    return new Container(
      child: new Column(

        children: <Widget>[

          IconButton(icon: Icon(Icons.arrow_back_ios), onPressed: (){
            Navigator.pop(context);
          }),
          IconButton(icon: Icon(Icons.arrow_forward_ios), onPressed: (){
            Navigator.push(context, new MaterialPageRoute(builder: (context) => new  fourPage()));
          }),

        ],

      ),
    );

  }


}





