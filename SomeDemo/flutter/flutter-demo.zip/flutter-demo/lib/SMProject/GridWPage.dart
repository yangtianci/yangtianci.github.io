

import 'package:flutter/material.dart';
import 'package:sky_engine/math/math.dart';

class GridWPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: new AppBar(
        title: new Text("MainPage"),
      ),
      body: new GridViewDemo(),
    );
  }
}



  
  class GridViewDemo extends StatefulWidget{
  
    @override
    State<StatefulWidget> createState() {
    // TODO: implement createState
    return _GridViweDemoState();
  }
  
  }
  
  
  class _GridViweDemoState extends State<GridViewDemo> {


    final int count = 60;


    @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new GridView.count(

      primary: false,
      padding: const EdgeInsets.only(top: 30.0,bottom: 20,left: 10,right: 10),
      mainAxisSpacing: 10.0,
      //竖向间距
      crossAxisCount: 5,
      //横向Item的个数
      crossAxisSpacing: 15.0,
      children: buildGridTileList(30),

    );
  }


    List<Widget> buildGridTileList(int number) {
      List<Widget> widgetList = new List();
      for (int i = 0; i < number; i++) {
        widgetList.add(getItemWidget(i));
      }
      return widgetList;
    }

    String url = "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=495625508," "3408544765&fm=27&gp=0.jpg";

    Widget getItemWidget(int idx) {
      //BoxFit 可设置展示图片时 的填充方式
      return new GestureDetector(
        child: new Column(
          children: <Widget>[
            Expanded(child:
              Image(image: new NetworkImage(url), fit: BoxFit.cover ),
              flex: 2,
            ),
            Expanded(child:
              Text("标题"),
            ),

          ],
        ),
        onTap:(){
          print("被点击了, 啦啦啦");
          print(count);

        },
      );
    }

  }