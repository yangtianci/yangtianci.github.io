import 'package:flutter/material.dart';


import './thirdPage.dart';

void main() => runApp(OtherFilePage());


class OtherFilePage extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text("第二个文件"),
      ),
      body: new Center(

        child: new Container(
          margin: new EdgeInsets.only(top: 30),

          child: new Column(

            children: <Widget>[

              new Text(
                "啦啦啦, 已经成功跳转过来啦",
              ),

              new Text("lalla",),

              new IconButton(icon: Icon(Icons.arrow_forward), onPressed: (){
                Navigator.push(context, new MaterialPageRoute(builder: (context) => new thirdPage()));
              }),


            ],


          ),


        ),


      ),


    );
  }
}