
import 'package:flutter/material.dart';

import '../CommonTool/NetWorkManager.dart';

class LoginPage extends StatelessWidget{

  @override
  Widget build(BuildContext context) {

    final String count = "";
    final String pwd = "";



    // TODO: implement build

    /**
     *
     *  AppBar(
        title: Text("登录"),
        backgroundColor: Colors.blue[300],
        )
     */

    return new Scaffold(
      appBar: null,
      body: new Center(
        child: new Stack(
          children: <Widget>[
            loginMp(),
            loginPC(),
          ],
        ),
      ),
    );
  }

}


// 主界面 - 内容

class loginPC extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _loginPCS();
  }
}

class _loginPCS extends State<loginPC>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
        child: new Container(
          padding: EdgeInsets.only(top: 5,right: 50,left: 50, bottom: 80),
          child: new Column(
            children: <Widget>[
              Expanded(child:
              TopW(),
            flex: 2,
              ),
            Expanded(
              child:
              MiddleW(),
              flex: 1,
            ),
          Expanded(child:
              BottomW(),
            flex: 1,
          ),
            ],
          ),
        ),
    );
  }
}


// Top

class TopW extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => new _TopWS();
}

class _TopWS extends State<TopW>{

  var logo = Image.asset("images/Login/logoLogin.png",fit: BoxFit.contain,);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      width: 100,
      height: 198,
      child: Center(
        child: logo,
      ),
    );
  }
}

// middle

class MiddleW extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => new _MiddleWS();
}


class _MiddleWS extends State<MiddleW>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Column(
    children: <Widget>[
    RowNumber(),
    ],
    );
  }
}

class RowNumber extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => new _RowNumberS();
}

class _RowNumberS extends State<RowNumber>{


  void hidePwd(){

    // 隐藏密码

  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      child: new Column(
        children: <Widget>[
          Container(
            height: 35,
            child: new Row(
              children: <Widget>[
                Text("工号:",style: TextStyle(fontSize: 17,color: Colors.white),),
                Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Text("textfield 部分不知道为啥出不来,", style: TextStyle(color:Colors.white),),
                ),
              ],
            ),
          ),

          Container(
            height: 35,
            child: new Row(
              children: <Widget>[
                Text("工号:",style: TextStyle(fontSize: 17,color: Colors.white),),
                Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Text("textfield 部分不知道为啥出不来,", style: TextStyle(color:Colors.white),),
                ),
                Container(
                  width: 35,
                  height: 35,
                  padding: EdgeInsets.only(right: 5),
                  child: IconButton(icon: new Icon(Icons.adjust), onPressed: (){
                      hidePwd();
                  }),
                ),
              ],
            ),
          ),

          Container(
            padding: EdgeInsets.only(top: 10),

            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Text("重置密码",style: TextStyle(fontSize: 14, color: Colors.yellow[300],),),

              ],
            ),
          ),

        ],
      ),
    );
  }




}





// Bottom

class BottomW extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => new _BottomWS();
}

class _BottomWS extends State<BottomW>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      padding: EdgeInsets.only(right: 10,left: 10,bottom: 70),
      child: GestureDetector(
        onTap: (){
          LoginMethod("测试");
//          GetMethod("http://www.baidu.com");
        },
        child: Container(

          height: 30,
          width: 300,
          padding: EdgeInsets.only(right: 0,left: 0),
          color: Colors.yellow[300],
          child: Center(
            child: Text("登录",style: TextStyle(color: Colors.black45,fontSize: 18,),),
          ),
        ),
      ),
    );
  }



}



// 主界面 - 背景

class loginMp extends StatefulWidget{

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _loginMpSt();
  }

}

class _loginMpSt extends State<loginMp>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(

        child: Container(
        decoration: BoxDecoration(
        image: DecorationImage(image: AssetImage("images/Login/登陆1136.png"

        ),
          fit: BoxFit.fill,
        ),
      ),
        ),
    );
  }
}
