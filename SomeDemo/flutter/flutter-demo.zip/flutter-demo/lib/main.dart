import 'package:flutter/material.dart';

import './SMProject/firtJump.dart';


import './SMProject/MainPage.dart';

import 'package:flutter/rendering.dart';


void main(){

//  debugPaintSizeEnabled = true;

  runApp(
      MyApp()
  );
}

// 此处跳转位置实际在 MainPage 文件



class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '测试页面跳转',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(

      primaryColor: Colors.pink[300],
      ),
      home: MainPage(),

    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;




  void _incrementCounter() {
    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      _counter++;
    });
  }



  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.

    var imgObjc = CreatImgObjc();

    return Scaffold(
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title),
      ),
      body: Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.

        child: Column(
          children: <Widget>[
            Text("尝试不进行 pod install 是否可以动态集成代码 \n 是的, 直接修改 flutter 代码, 然后运行 iOS 代码即可更新 "),
            CreatImgObjc(),
            new FavoriteWidget(),
            new CusBtn(),
            new staBtn(),
            CreatOtherFileJump(),
          ],
        ),

      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );

  }


  Widget CreatOtherFileJump(){

    return new Container(

      child: RaisedButton(
          onPressed: (){
        Navigator.push(context, new MaterialPageRoute(builder: (context) => OtherFilePage()));
      },
        child: new Text("其他文件"),
      ),
    );
  }


  Widget CreatImgObjc(){
    var gesture = GestureDetector(
      onTap: (){
        print("图片被点击啦~~~");
      },
      child: new Container(
        height: 50,
        padding: const EdgeInsets.all(8),
        decoration: new BoxDecoration(
          borderRadius: new BorderRadius.circular(5),
          color: Colors.lightBlueAccent,
        ),
        child: new Center(
          child: new Image.asset("images/lake.jpg", width: 100, height: 100,),
        ),
      ),

    );

    return  gesture;

  }

}



class FavoriteWidget extends StatefulWidget {
  @override
  _FavoriteWidgetState createState() => new _FavoriteWidgetState();
}

class _FavoriteWidgetState extends State<FavoriteWidget> {
  bool _isFavorited = true;
  int _favoriteCount = 41;

  void _toggleFavorite() {
    
    
    Navigator.push(context, new MaterialPageRoute(builder: (context) => new SecondPage()));
    
//    setState(() {
      // If the lake is currently favorited, unfavorite it.
//      if (_isFavorited) {
//        _favoriteCount -= 1;
//        _isFavorited = false;
//        // Otherwise, favorite it.
//      } else {
//        _favoriteCount += 1;
//        _isFavorited = true;
//      }
//    }
//    );
  }

  @override
  Widget build(BuildContext context) {
    return new Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        new Container(
          padding: new EdgeInsets.all(0.0),
          child: new IconButton(

            icon: (_isFavorited
                ? new Icon(Icons.star)
                : new Icon(Icons.star_border)),
            color: Colors.red[500],
            onPressed: _toggleFavorite,
          ),
        ),
        new SizedBox(
          width: 18.0,
          child: new Container(
            child: new Text('$_favoriteCount'),
          ),
        ),
      ],
    );
  }
}

// 构建一个 button

class CusBtn extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new GestureDetector(

      onTap: (){
        print("llaal");
      },
      child: new Container(
        height: 36,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: new BoxDecoration(
          borderRadius: new BorderRadius.circular(5),
          color: Colors.red[500],
        ),
        child: new Center(
          child: new Text("Engage"),
        ),
      ),

    );
  }

}


// 有状态 btn



class btnState extends State<staBtn>{

  int la = 0;

  void lalal(){
    print("嘿嘿");

  }


  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Row(

      children: <Widget>[

        new RaisedButton(onPressed: (){
          lalal();
          setState(() {
            la ++;
          });
    },
        child: new Text("有状态按钮"),

        ),
        new Text("la : $la"),
      ],

    );
  }



}



class staBtn extends StatefulWidget{

   @override
   btnState createState() => new btnState();

}



// 创建一个新的界面并进行 push

class SecondPage extends StatelessWidget{

  @override
  Widget build(BuildContext context) {

    final la = 1;

    void testMethod (){



    }

    return new Scaffold(

      appBar: new AppBar(
        title: new Text("第二个界面"),
        backgroundColor: Colors.deepPurple[300],
      ),

      body: new Center(

        child: new Container(


          child: new RaisedButton(

              onPressed:(){
                  Navigator.push(context, new MaterialPageRoute(builder: (context) => OtherFilePage()));
              },

            child: new Text("这会不会再错了吧..."),


          ),

        ),


      ),

    );

  }

}




