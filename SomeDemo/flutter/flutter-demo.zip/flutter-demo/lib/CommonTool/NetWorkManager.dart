
import 'package:path/path.dart';
import 'package:dio/dio.dart';

import 'dart:io';
import 'dart:convert';


var interUrl = '';

void GetMethod(String url) async {

    Response response = await Dio().get(url,queryParameters: {"1":"2"});

    interUrl = url;

    print(response);

    print( interUrl);

}


void LoginMethod(String url) async{


    /**
        code = H000163;
        deviceNo = "F6F805CE-46C9-483F-8767-C2688B0893E8";
        deviceType = ios;
        netType = WiFi;
        password = 123456;
     * */


    var client = new HttpClient();
    var url = new Uri.http("172.16.163.54:8443", "/api/emp/login",{
        "code":"H000163",
        "deviceNo":"F6F805CE-46C9-483F-8767-C2688B0893E8",
        "deviceType":"ios",
        "netType":"netType",
        "password":"123456"
    });

    var req = await client.postUrl(url);
    var resp = await req.close();

    var responseBody = await resp.transform(Utf8Decoder()).join();

    Map data = jsonDecode(responseBody);


    print(data);



    
//    Response loginResp = await Dio().post("http://172.16.163.54:8443/api/emp/login",data: {
//        "code":"H000163",
//        "deviceNo":"F6F805CE-46C9-483F-8767-C2688B0893E8",
//        "deviceType":"ios",
//        "netType":"netType",
//        "password":"123456"
//    });

    print("================================ response start ");

//    print(loginResp);


    print("================================ response end ");

}

