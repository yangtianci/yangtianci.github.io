//
//  BaseVCEmptyView.m
//  NengGo
//
//  Created by 杨天赐 on 2018/11/2.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import "BaseVCEmptyView.h"


@interface BaseVCEmptyView ()


// 默认占位图
@property (strong, nonatomic) UIView *placeholderView;
@property (strong, nonatomic) UIImageView *placeholderImg;
@property (strong, nonatomic) UILabel *placeholderLab;


@end

@implementation BaseVCEmptyView



-(instancetype)init{
    
    if (self = [[BaseVCEmptyView alloc]init]) {
        [self configUI];
    }
    return self;
}


#pragma mark ================= 对外接口


// 此界面三种使用方式
/**
 
 1. 调用默认界面
 2. 调用默认界面并修改图片以及文字说明
 3. 自定义占位图片
 
 */

static BaseVCEmptyView *emptyView;
+(instancetype)shareManager{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        // 初始化请求管理类
        emptyView = [[BaseVCEmptyView alloc]init];
        emptyView.frame = [UIScreen mainScreen].bounds;
    });
    return emptyView;
}

-(void)customConfgigUIWithImgName:(NSString*)imgName LabelTitle:(NSString*)labStr{
    
    //此处需要添加根据图片大小变换布局的判断以及加载网络图片的判断
    
    self.placeholderImg.image = [UIImage imageNamed:imgName];
    self.placeholderLab.text = labStr;
    
}

#pragma mark ================= 配置默认 UI

-(void)configUI{
    
    CGSize screenSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    
    //--必须设置--
    CGRect viewRect = CGRectMake(screenSize.width/2 - 50, screenSize.height/2 + 30, 100, 100);
    self.placeholderView = [[UIView alloc]initWithFrame:viewRect];
    [self addSubview:self.placeholderView];
    
    
    //--必须设置--
    CGRect imgRect = CGRectMake(0, 0, 100, 60);
    self.placeholderImg = [[UIImageView alloc]initWithFrame:imgRect];
    [self.placeholderView addSubview:self.placeholderImg];
    self.placeholderImg.image = [UIImage imageNamed:@"lalala"];
    self.placeholderImg.backgroundColor = [UIColor blueColor];
    
    
    CGRect labelRect = CGRectMake(0, 60, 100, 40);
    self.placeholderLab = [[UILabel alloc]initWithFrame:labelRect];
    [self.placeholderView addSubview:self.placeholderLab];
    
    self.placeholderLab.font = [UIFont systemFontOfSize:14];
    self.placeholderLab.textColor = [UIColor blackColor];
    self.placeholderLab.textAlignment = NSTextAlignmentCenter;
    self.placeholderLab.numberOfLines = 0;
    self.placeholderLab.text = @"customLabel";
    
}









@end
