//
//  BaseWebViewController.m
//  NengGo
//
//  Created by 杨天赐 on 2018/10/31.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import "BaseWebViewController.h"

#import <WebKit/WebKit.h>

#define kStringIsEmpty(str) ([str isKindOfClass:[NSNull class]] || str == nil || [str length] < 1 ? YES : NO )

@interface BaseWebViewController ()<WKNavigationDelegate,UIScrollViewDelegate>
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) UIProgressView *progressView;

@end

@implementation BaseWebViewController


- (void)dealloc {
    
    [self.webView removeObserver:self forKeyPath:NSStringFromSelector(@selector(estimatedProgress))];
    if(self.headerTitle.length == 0){
        [self.webView removeObserver:self forKeyPath:@"title"];
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configUI];
}

- (void)BackAction{
    
    if([_webView canGoBack]){
        [_webView goBack];
    }else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - UI层

- (void)configUI{
    
    if (self.headerTitle.length > 0) {
        [self setNavTitle:self.headerTitle];
    }
    
    self.navigationController.navigationBar.translucent = NO;
    
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc]init];
    WKWebsiteDataStore *store;
    if(self.cache){
        store = [WKWebsiteDataStore defaultDataStore];
    }else{
        store = [WKWebsiteDataStore nonPersistentDataStore];
    }
    
    
    if (store) {
        config.websiteDataStore = store;
    }
    
    
    self.webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, [UIScreen mainScreen].bounds.size.height-44) configuration:config];
    self.webView.scrollView.showsHorizontalScrollIndicator = NO;
    self.webView.scrollView.showsVerticalScrollIndicator = NO;
    self.webView.navigationDelegate = self;
    
    [self.webView addObserver:self
                   forKeyPath:NSStringFromSelector(@selector(estimatedProgress))
                      options:0
                      context:nil];
    if (kStringIsEmpty(self.headerTitle)) {
        [self.webView addObserver:self forKeyPath:@"title" options:NSKeyValueObservingOptionNew context:NULL];
    }
    
    [self.view addSubview:self.webView];
    [self.view addSubview:self.progressView];
    
    if (_url) {
        if ([_url isKindOfClass:[NSString class]]) {
            
            NSString *newUrl = (NSString*)_url;
            if ([newUrl containsString:@"http"]) {
            }else{
                newUrl = [NSString stringWithFormat:@"http://%@",newUrl];
                _url = newUrl;
            }
            
            [self loadWebPageWithString:_url];
        }else{
            NSURLRequest *request =[NSURLRequest requestWithURL:_url];
            [_webView loadRequest:request];
        }
    }else{
        if (_htmlStr) {
            [_webView loadHTMLString:_htmlStr baseURL:nil];
        }
    }
    
}


- (void)loadWebPageWithString:(NSString*)urlString
{
    self.url = urlString;
    NSURL *url =[NSURL URLWithString:urlString];
    
    NSURLRequest *request =[NSURLRequest requestWithURL:url];
    [_webView loadRequest:request];
}


#pragma mark - 代理

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
    
    self.progressView.hidden = NO;
    self.progressView.transform = CGAffineTransformMakeScale(1.0f, 1.5f);
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    
    self.progressView.hidden = YES;
}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error{
    
    self.progressView.hidden = YES;
    if([error code] == NSURLErrorCancelled){
        return;
    }
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:[error localizedDescription] preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }]];
    [self presentViewController:alertController animated:YES completion:^{
        
    }];
    
}


- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction*)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    
    
    NSString *strRequest = [navigationAction.request.URL.absoluteString stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    if ([strRequest hasSuffix:@"gotoorder"]){ // 需要跳转到去预约
        
        decisionHandler(WKNavigationActionPolicyCancel);//不允许跳转
        
        [self.tabBarController setSelectedViewController:[self.tabBarController.viewControllers objectAtIndex:1]];
        [self.navigationController popToRootViewControllerAnimated:YES];
        
    }else{//截获页面里面的链接点击
        
        // 解决wkWebViewh5拨打电话功能无效的问题
        NSURL *URL = navigationAction.request.URL;
        NSString *scheme = [URL scheme];
        if ([scheme isEqualToString:@"tel"]) {
            NSString *resourceSpecifier = [URL resourceSpecifier];
            NSString *callPhone = [NSString stringWithFormat:@"telprompt://%@", resourceSpecifier];
            /// 防止iOS 10及其之后，拨打电话系统弹出框延迟出现
            dispatch_async(dispatch_get_global_queue(0, 0), ^{
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:callPhone]];
            });
        }
        decisionHandler(WKNavigationActionPolicyAllow);//允许跳转
    }
}




-(void)observeValueForKeyPath:(NSString *)keyPath
                     ofObject:(id)object
                       change:(NSDictionary<NSKeyValueChangeKey,id> *)change
                      context:(void *)context{
    
    if ([keyPath isEqualToString:NSStringFromSelector(@selector(estimatedProgress))]
        && object == self.webView) {
        [self.progressView setAlpha:1.0f];
        BOOL animated = self.webView.estimatedProgress > self.progressView.progress;
        [self.progressView setProgress:self.webView.estimatedProgress
                              animated:animated];
        
        if (self.webView.estimatedProgress >= 1.0f) {
            [UIView animateWithDuration:0.3f
                                  delay:0.3f
                                options:UIViewAnimationOptionCurveEaseOut
                             animations:^{
                                 [self.progressView setAlpha:0.0f];
                             }
                             completion:^(BOOL finished) {
                                 [self.progressView setProgress:0.0f animated:NO];
                             }];
        }
    }else if ([keyPath isEqualToString:@"title"]){
        
        if (object == self.webView && object == self.webView && !self.headerTitle) {
            self.title = self.webView.title;
        }
        
    }else{
        
        [super observeValueForKeyPath:keyPath
                             ofObject:object
                               change:change
                              context:context];
    }
}

#pragma mark - 懒加载
-(UIProgressView *)progressView{
    
    if (!_progressView) {
        _progressView = [[UIProgressView alloc]initWithProgressViewStyle:UIProgressViewStyleDefault];
        _progressView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 5);
        [_progressView setTrackTintColor:[UIColor colorWithRed:240.0/255 green:240.0/255 blue:240.0/255 alpha:1.0]];
        _progressView.progressTintColor = [UIColor redColor];
        self.progressView.transform = CGAffineTransformMakeScale(1.0f, 1.5f);
        
    }
    return _progressView;
}

//设置导航栏标题
- (void)setNavTitle:(NSString *)navTitle
{
    UILabel *t_label = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, 80, 44)];
    t_label.font = [UIFont systemFontOfSize:20];
    t_label.textColor = [UIColor darkTextColor];
    t_label.textAlignment = NSTextAlignmentCenter;
    t_label.text = navTitle;
    if (self.navigationItem) {
        self.navigationItem.titleView = t_label;
    }
}


@end
