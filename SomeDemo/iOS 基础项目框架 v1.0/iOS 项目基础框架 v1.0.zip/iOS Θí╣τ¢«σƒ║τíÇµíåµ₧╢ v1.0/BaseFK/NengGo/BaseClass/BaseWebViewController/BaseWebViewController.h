//
//  BaseWebViewController.h
//  NengGo
//
//  Created by 杨天赐 on 2018/10/31.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BaseWebViewController : BaseViewController

@property(nonatomic,copy) id  url;

@property (nonatomic, copy) NSString *htmlStr;

@property (nonatomic, copy) NSString *headerTitle; // 标题

@property (nonatomic, assign) BOOL cache; // 是否清除缓存

@end

NS_ASSUME_NONNULL_END
