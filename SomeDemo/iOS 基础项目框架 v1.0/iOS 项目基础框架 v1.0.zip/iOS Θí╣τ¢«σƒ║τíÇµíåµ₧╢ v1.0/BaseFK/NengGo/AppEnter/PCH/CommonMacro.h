//
//  CommonMacro.h
//  NengGo
//
//  Created by 杨天赐 on 2018/11/2.
//  Copyright © 2018 tidoo. All rights reserved.
//

#ifndef CommonMacro_h
#define CommonMacro_h


#pragma mark ------------ 弱引用 ------------

#define TDWeakSelf(weakSelf)    __weak __typeof(&*self)weakSelf = self;


#pragma mark -------------- 打印日志 ---------------

//DEBUG  模式下打印日志,当前行
#ifdef DEBUG
#define DLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
#define DLog(...)
#endif

//打印当前方法名
#define TDITTDPRINTMETHODNAME() ITTDPRINT(@"%s", __PRETTY_FUNCTION__)


#pragma mark ------------ 单例化一个类 ------------

//单例化一个类
#define TDSINGLETON_FOR_HEADER(className) \
\
+ (className *)shared##className;

#define TDSINGLETON_FOR_CLASS(className) \
\
+ (className *)shared##className { \
static className *shared##className = nil; \
static dispatch_once_t onceToken; \
dispatch_once(&onceToken, ^{ \
shared##className = [[self alloc] init]; \
}); \
return shared##className; \
}



#pragma mark =======================   目录宏

//沙盒目录

#define kPathTemp                   NSTemporaryDirectory()

#define kPathDocument               [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]

#define kPathCache                  [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0]


#pragma mark =======================   导航器跳转

#define NAV_PUSH_CONVTROLLER(vname,navigation){ vname *v = [[vname alloc] initWithNibName:nil bundle:nil];\
[navigation pushViewController:v animated:YES];}



#endif /* CommonMacro_h */
