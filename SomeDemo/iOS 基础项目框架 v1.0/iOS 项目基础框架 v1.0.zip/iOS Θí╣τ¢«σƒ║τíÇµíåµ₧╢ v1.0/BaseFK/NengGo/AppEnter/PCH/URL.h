//
//  URL.h
//  CommonFK
//
//  Created by mac on 2018/10/25.
//  Copyright © 2018年 yangtianci. All rights reserved.
//

#ifndef URL_h
#define URL_h

//定义 url 拼接方式, 增加接口, 则增加 path 即可
//针对各种不同形式的 url 的拼接方式, 全部通过 VM 内部自定义函数进行多样自定义拼接

#pragma mark ================================== 协议

#define ProjectProtocol @"http://" // 正式
//#define ProjectProtocol @"https://" // 测试

#pragma mark ================================== 域名

#define DominName @"www.baidu.com"

#pragma mark ================================== 端口

#define Prot @"80"

#pragma mark ================================== 路径

#define Path_homepage @"/homepagePath"









#endif /* URL_h */
