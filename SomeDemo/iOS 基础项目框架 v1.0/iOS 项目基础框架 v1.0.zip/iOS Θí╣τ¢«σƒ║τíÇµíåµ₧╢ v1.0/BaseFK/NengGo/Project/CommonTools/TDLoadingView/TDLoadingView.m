//
//  TDLoadingView.m
//  NengGo
//
//  Created by 范同欢 on 2018/10/30.
//  Copyright © 2018年 tidoo. All rights reserved.
//

#import "TDLoadingView.h"

@interface TDLoadingView ()

@property (nonatomic, strong) FLAnimatedImageView *loadingImageView;

@end

@implementation TDLoadingView

- (instancetype)init {
    if (self = [super init]) {
        TDWeakSelf(ws);
        
        self.backgroundColor = TDCOLOR_RGB(0xf5f5f5);
        
        self.loadingImageView = [[FLAnimatedImageView alloc] init];
        [self addSubview:self.loadingImageView];
        [self.loadingImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(ws);
            make.width.mas_equalTo(40);
            make.height.mas_equalTo(40);
        }];
        FLAnimatedImage *animatedImage = [FLAnimatedImage animatedImageWithGIFData:[[NSDataAsset alloc] initWithName:@"loading_gif"].data];
        self.loadingImageView.animatedImage = animatedImage;
        self.hidden = YES;
    }
    return self;
}

- (void)loadingShow {
    [self.loadingImageView startAnimating];
    self.hidden = NO;
    self.alpha = 1;
}

- (void)loadingHidden {
    [UIView animateWithDuration:0.2 animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        self.hidden = YES;
        [self.loadingImageView stopAnimating];
    }];
}

@end
