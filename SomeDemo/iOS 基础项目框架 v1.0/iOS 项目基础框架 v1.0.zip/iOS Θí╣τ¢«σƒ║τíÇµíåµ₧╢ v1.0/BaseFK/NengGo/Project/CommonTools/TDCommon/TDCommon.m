//
//  TDCommon.m
//  NengGo
//
//  Created by 范同欢 on 2018/10/30.
//  Copyright © 2018年 tidoo. All rights reserved.
//

#import "TDCommon.h"

@implementation TDCommon

//占位图
+ (UIImage *)placeholderImage {
    return [UIImage imageNamed:@""];
}

//占位头像
+ (UIImage *)placeholderAvatar {
    return [UIImage imageNamed:@""];
}

//程序是否在后台
+ (BOOL)runningInBackground {
    UIApplicationState state = [UIApplication sharedApplication].applicationState;
    BOOL result = (state == UIApplicationStateBackground);

    return result;
}

//程序是否在前台
+ (BOOL)runningInForeground {
    UIApplicationState state = [UIApplication sharedApplication].applicationState;
    BOOL result = (state == UIApplicationStateActive);

    return result;
}

@end
