//
//  ViewController.m
//  NengGo
//
//  Created by 杨天赐 on 2018/10/29.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import "ViewController.h"

#import "BaseViewModel.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    
    self.view.backgroundColor = [UIColor orangeColor];
    
//    BaseViewModel *VM = [[BaseViewModel alloc]init];
    
    //https://suggest.taobao.com/sug?code=utf-8&q=lala&callback=cb
    
//    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
//    [dict setObject:@"utf-8" forKey:@"code"];
//    [dict setObject:@"cb" forKey:@"callback"];
//    [dict setObject:@"lala" forKey:@"q"];
//
//    NSMutableDictionary *info = [NSMutableDictionary dictionary];
//    [info setObject:@"2" forKey:@"state"];
//
//    [VM PostData_WithPara:dict Info:info Path:@"http://suggest.taobao.com/sug" Success:^(NSDictionary *dict, id info) {
//
//
//
//    } Fail:^(NSURLSessionDataTask *task, id info) {
//
//
//
//    }];
    
}


@end
