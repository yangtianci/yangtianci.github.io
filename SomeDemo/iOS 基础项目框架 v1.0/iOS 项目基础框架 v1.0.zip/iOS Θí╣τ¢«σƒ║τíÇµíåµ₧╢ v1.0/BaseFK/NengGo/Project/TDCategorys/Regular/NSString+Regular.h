
/*~!
 | @FUNC  正则表达式
 | @AUTH  Nobility
 | @DATE  2016-10-17
 | @BRIF  <#brif#>
 */

#import <Foundation/Foundation.h>

@interface NSString (Regular)



//1.1 验证电话号码
- (BOOL)checkTelephoneNumber;

//1.2 验证身份证
- (BOOL)checkIDCard;

//1.3 验证邮箱
- (BOOL)checkEmail;

//1.4 验证URL
- (BOOL)checkURL;

//1.5 验证银行卡
-(BOOL)checkCardNo:(NSString*)cardNo;

#pragma 正则匹配用户密码6-18位数字和字母组合
+ (BOOL)checkPassword:(NSString *) password;







@end
