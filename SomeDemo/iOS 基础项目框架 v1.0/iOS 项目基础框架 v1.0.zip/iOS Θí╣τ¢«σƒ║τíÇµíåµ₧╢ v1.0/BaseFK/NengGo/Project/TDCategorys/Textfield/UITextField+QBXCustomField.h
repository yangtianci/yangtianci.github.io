//
//  UITextField+QBXCustomField.h
//  QianBuXian_V2
//
//  Created by YangTianCi on 2017/10/11.
//  Copyright © 2017年 qbx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (QBXCustomField)


-(void)custom_SafeAccessView;

-(void)custom_BackAccessView;

@end
