//
//  NetManager.m
//  CommonFK
//
//  Created by mac on 2018/10/25.
//  Copyright © 2018年 yangtianci. All rights reserved.
//

#import "NetManager.h"

#import <AFNetworking.h>

@interface NetManager()




@end

static AFHTTPSessionManager *manager;


@implementation NetManager





@end
