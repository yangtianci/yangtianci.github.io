//
//  UserInfoManager.m
//  NengGo
//
//  Created by 杨天赐 on 2018/10/31.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import "UserInfoManager.h"


@interface UserInfoManager()



@end


static UserInfoManager *InfoManager;

@implementation UserInfoManager













#pragma mark ================================ 单例

+(instancetype)shareInstance{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        InfoManager = [[UserInfoManager allocWithZone:NULL]init];
    });
    return InfoManager;
}

// 防止外部调用alloc 或者 new
+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    return [UserInfoManager shareInstance];
}

// 防止外部调用copy
- (id)copyWithZone:(nullable NSZone *)zone {
    return [UserInfoManager shareInstance];
}


// 防止外部调用mutableCopy
- (id)mutableCopyWithZone:(nullable NSZone *)zone {
    return [UserInfoManager shareInstance];
}





@end
