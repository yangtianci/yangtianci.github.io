//
//  ViewController.m
//  点击量文件
//
//  Created by YangTianCi on 2017/10/12.
//  Copyright © 2017年 ytc. All rights reserved.
//

#import "ViewController.h"

#import "ytcChainHeader.h"

#import "AFNetworking.h"

#define Margin 20

#define StandWidth [UIScreen mainScreen].bounds.size.width - Margin * 2

#define maro @"http://www.qianbuxian.com.cn//redshare/shareindex/"

// 佳凡 http://www.qianbuxian.com.cn//redshare/shareindex/CP21NQ/579

// 广京 http://www.qianbuxian.com.cn//redshare/shareindex/NN9Z8N/201

// 士杰 http://www.qianbuxian.com.cn//redshare/shareindex/NLMZQS/830

//  亭斌 http://www.qianbuxian.com.cn//redshare/shareindex/WSVPGH/582

//我的 http://www.qianbuxian.com.cn//redshare/shareindex/XEGTML/822

@interface ViewController ()<UIWebViewDelegate,NSXMLParserDelegate>

@property (nonatomic,strong) UITextField *PersonalInfoField;

@property (nonatomic,strong) UITextField *ClickCountField;

@property (strong, nonatomic) UIButton *sendButton;

@property (nonatomic,strong) UIWebView *webView;

@property (strong, nonatomic) UILabel *countLabel;

@property (nonatomic,assign) NSInteger countNumber;

@property (nonatomic,assign) NSInteger TotalNumber;


#pragma mark ============ 代理版本

@property (nonatomic,strong) AFHTTPSessionManager *sessionManager;

@property (nonatomic,strong) NSMutableArray *proxyArray;





@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.countNumber = 0;
    
    [self ParserXMLData];
    
    [self ConfigurationUI];
    
}


#pragma mark ============ http方式请求


//XML
-(void)ParserXMLData{
    
    NSString *htmlString = [NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://www.xicidaili.com/"] encoding:NSUTF8StringEncoding error:nil];
    
    
    NSRegularExpression *regexOne = [NSRegularExpression regularExpressionWithPattern:@"(\\d+\\.\\d+\\.\\d+\\.\\d+)" options:NSRegularExpressionCaseInsensitive error:nil];
    

    NSRegularExpression *regexPort = [NSRegularExpression regularExpressionWithPattern:@"(<td>\\d+[^\\.\\u4e00-\\u9fa5]</td>)" options:NSRegularExpressionCaseInsensitive error:nil];
    
    
    NSArray *ipARR = [regexOne matchesInString:htmlString options:NSMatchingWithTransparentBounds range:NSMakeRange(0, htmlString.length)];
    NSMutableArray *IpResultArr = [NSMutableArray array];
    for (NSTextCheckingResult *match in ipARR) {
        NSRange range = [match range];
        NSString *mStr = [htmlString substringWithRange:range];
        [IpResultArr addObject:mStr];
    }
    
    NSArray *portARR = [regexPort matchesInString:htmlString options:NSMatchingWithTransparentBounds range:NSMakeRange(0, htmlString.length)];
    NSMutableArray *PortResultArr = [NSMutableArray array];
    for (NSTextCheckingResult *match in portARR) {
        NSRange range = [match range];
        
        range.location += 4;
        range.length -= 9;
        
        NSString *mStr = [htmlString substringWithRange:range];

        [PortResultArr addObject:mStr];
    }
    
    NSMutableArray *resutltArr = [NSMutableArray array];
    
    for (int i = 0; i < 50; i++) {
        
        NSString *ipSTR = IpResultArr[i];
        NSString *portSTR = PortResultArr[i];
        
        NSString *resultStr = [NSString stringWithFormat:@"%@:%@",ipSTR,portSTR];
        
        [resutltArr addObject:resultStr];
        
    }

    self.proxyArray = resutltArr;

}


/**
 * 初始化HTTP
 */
- (void)httpInit
{
    
    if (self.countNumber == self.proxyArray.count - 1) {
        
        NSLog(@"循环结束");
        
        return;
        
    }
    
    //获取实例对象
    //self.manager = [AFHTTPSessionManager manager];
    
    self.sessionManager = nil;
    
    //设置代理并获取实例对象
    self.sessionManager = [[AFHTTPSessionManager manager] initWithBaseURL:nil sessionConfiguration:[self setProxyWithConfig]];
    
    //申明返回的结果是JSON类型
    self.sessionManager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    //如果报接受类型不一致请替换一致text/html
    self.sessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    
    //清求时间设置
    self.sessionManager.requestSerializer.timeoutInterval = 10;
    
    self.sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    [self.sessionManager GET:@"http://www.qianbuxian.com.cn//redshare/shareindex/XEGTML/822" parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSData *responseData = (NSData*)responseObject;
        
        NSString *str = [[NSString alloc]initWithData:responseData encoding:NSUTF8StringEncoding];
        
        self.countNumber ++;
        
        NSLog(@"代理可用 - %zd号",self.countNumber);
        
        [self httpInit];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"%zd号代理废弃",self.countNumber);
        
        self.countNumber ++;
        
        [self httpInit];
        
    }];

}



/**
 * 代理设置
 */
- (NSURLSessionConfiguration *)setProxyWithConfig
{
    
    NSString *dominStr = self.proxyArray[self.countNumber];
    
    NSArray *dominArr = [dominStr componentsSeparatedByString:@":"];
    
    NSString *IPStr = dominArr.firstObject;
    NSString *PortStr = dominArr.lastObject;
    
    int portInterger = [PortStr intValue];
    NSNumber *portNumber = [NSNumber numberWithInt:portInterger];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    config.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    config.connectionProxyDictionary = @
    {
        @"HTTPEnable":@YES,
        (id)kCFStreamPropertyHTTPProxyHost:IPStr,
        (id)kCFStreamPropertyHTTPProxyPort:portNumber,
        @"HTTPSEnable":@YES,
        (id)kCFStreamPropertyHTTPSProxyHost:IPStr,
        (id)kCFStreamPropertyHTTPSProxyPort:portNumber
    };
    
    return config;
}

#pragma mark ============ 配置UI
-(void)ConfigurationUI{
    
    //BGImg
    
    UIImageView *BGImg = [UIImageView tc_InitWithBlock:^(UIImageView *imgView) {
       
        imgView.frame = self.view.bounds;
        imgView.tc_ImageName(@"2").tc_SuperView(self.view);
        
    }];

    //infoField
    self.PersonalInfoField = [UITextField tc_InitWithBlock:^(UITextField *textField) {
       
        textField.tc_FrameValue(Margin, 120, StandWidth, 50).tc_textAlignment(NSTextAlignmentCenter).tc_text(@"XEGTML/822").tc_placeholder(@"输入个人身份信息: XXXX/1111形式").tc_borderStyle(UITextBorderStyleRoundedRect).tc_SuperView(self.view);
        [self custom_BackAccessViewWithField:textField];
    }];
    
    
    //countField
    self.ClickCountField = [UITextField tc_InitWithBlock:^(UITextField *textField) {
        
        textField.tc_FrameValue(Margin, 190, StandWidth, 50).tc_textAlignment(NSTextAlignmentCenter).tc_placeholder(@"输入次数").tc_borderStyle(UITextBorderStyleRoundedRect).tc_SuperView(self.view);
        
        textField.keyboardType = UIKeyboardTypeNumberPad;
        
        [self custom_BackAccessViewWithField:textField];
        
    }];
    
    //sendButton
    
    self.sendButton = [UIButton tc_InitWithBlock:^(UIButton *button) {
        
        button.tc_FrameValue(Margin, 260, StandWidth, 50).tc_setTitle(@"Ensure",UIControlStateNormal).tc_BGColor([UIColor redColor]).tc_AddTarget(self, @selector(sendButtonMethodWithSender:), UIControlEventTouchUpInside).tc_SuperView(self.view);
        
        button.layer.tc_CornerRadius(25).tc_MasksToBounds(YES);
        
    }];
    
    //label
    self.countLabel = [UILabel tc_InitWithBlock:^(UILabel *label) {
       
        label.tc_FrameValue(Margin, 330, StandWidth, 50).tc_Align(NSTextAlignmentCenter).tc_SuperView(self.view).tc_Text(@"当前执行数: 0").tc_FontSize(25).tc_BGColor([UIColor lightGrayColor]);
        label.layer.tc_CornerRadius(25).tc_MasksToBounds(YES);
        
    }];

    
    
//    CGRect webRect = CGRectMake(Margin, [UIScreen mainScreen].bounds.size.height/2 + 50, ([UIScreen mainScreen].bounds.size.height/2) * 0.5, [UIScreen mainScreen].bounds.size.height/2 - 50);
//
//    UIWebView *webView = [[UIWebView alloc]initWithFrame:webRect];
//
//    webView.backgroundColor = [UIColor clearColor];
//
//    self.webView = webView;
//    self.webView.delegate = self;
//    [self.view addSubview:self.webView];
//
//    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.xicidaili.com/"]]];
    
    
}








//sendB
-(void)sendButtonMethodWithSender:(UIButton*)sender{
    
    if (self.ClickCountField.text.length > 0) {
        self.TotalNumber = [self.ClickCountField.text integerValue];
    }else{
        self.TotalNumber = 2;
    }
    
    sender.enabled = NO;
    sender.tc_BGColor([UIColor lightGrayColor]);

    [self httpInit];
    
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
    
    return YES;
}


- (void)webViewDidStartLoad:(UIWebView *)webView{
    
    
}


- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
//    //清除cookies
//    NSHTTPCookie *cookie;
//    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
//    for (cookie in [storage cookies])
//    {
//        [storage deleteCookie:cookie];
//
////        NSLog(@"COOKIE{name: %@, value: %@}", [cookie name], [cookie value]);
//
//    }
//
//    self.countNumber ++;
//    self.countLabel.text = [NSString stringWithFormat:@"当前执行数: %zd",self.countNumber];
//
//    if (self.countNumber < self.TotalNumber) {
//
//        [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[self GetWebUrl]]]];
//
//    }else{
//        self.countLabel.text = [NSString stringWithFormat:@"已完成次数: %zd",self.countNumber];
//        self.countNumber = 0;
//
//        self.sendButton.enabled = YES;
//        self.sendButton.tc_BGColor([UIColor redColor]);
//
//    }

    //获取高匿网站节点数据
    
//    NSString *allHtmlInfo = [self.webView stringByEvaluatingJavaScriptFromString:@"document.getElementById('ip_list').innerText"];
    
}





/**
 
 ytc: http://www.qianbuxian.com.cn//redshare/shareindex/XEGTML/822
 
 */




- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{

    self.countLabel.text = [NSString stringWithFormat:@"请重试"];
    self.countNumber = 0;
    
    self.sendButton.enabled = YES;
    self.sendButton.tc_BGColor([UIColor redColor]);

}

//regist
-(void)registButtonMethodWithSender:(UIButton*)sender{
    [self.PersonalInfoField resignFirstResponder];
    [self.ClickCountField resignFirstResponder];
}

//设为只有返回的键盘
-(void)custom_BackAccessViewWithField:(UITextField*)field{
    
    //safeView
    UIView *safeView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 50)];
    safeView.backgroundColor = [UIColor whiteColor];
    
    //lineView
    //lineView
    UIView *lineView = [[UIView alloc]init];
    [safeView addSubview:lineView];
    lineView.backgroundColor = [UIColor purpleColor];
    lineView.frame = CGRectMake(0, 0, safeView.frame.size.width, 1);
    
    //regist按钮
    //--必须设置--
    UIButton *registButton = [[UIButton alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width - 100, 0, 80, 50)];
    [safeView addSubview:registButton];
    //--基本设置--<##>
    [registButton setTitle:@"完成" forState:UIControlStateNormal];
    [registButton setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
    registButton.titleLabel.font = [UIFont systemFontOfSize:20];
    
    [registButton addTarget:self action:@selector(registButtonMethodWithSender:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    safeView.tintColor = [UIColor redColor];
    
    //设置
    field.inputAccessoryView = safeView;
    
}


-(NSString*)GetWebUrl{
    
    NSString *webUrl = self.PersonalInfoField.text;
    
    if (webUrl.length == 0) {
        return @"";
    }else{
        
        webUrl = [NSString stringWithFormat:@"%@%@",maro, webUrl];
        
    }
    
    return webUrl;
}

@end
