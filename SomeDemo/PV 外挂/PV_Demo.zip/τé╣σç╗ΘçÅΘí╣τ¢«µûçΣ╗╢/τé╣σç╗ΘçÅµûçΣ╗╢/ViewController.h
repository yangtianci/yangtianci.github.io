//
//  ViewController.h
//  点击量文件
//
//  Created by YangTianCi on 2017/10/12.
//  Copyright © 2017年 ytc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

