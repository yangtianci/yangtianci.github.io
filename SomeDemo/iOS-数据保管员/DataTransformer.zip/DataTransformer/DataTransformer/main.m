//
//  main.m
//  DataTransformer
//
//  Created by 杨天赐 on 2019/5/31.
//  Copyright © 2019 YtcTestNoticfication. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
