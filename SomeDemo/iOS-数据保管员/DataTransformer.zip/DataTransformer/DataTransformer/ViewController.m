//
//  ViewController.m
//  DataTransformer
//
//  Created by 杨天赐 on 2019/5/31.
//  Copyright © 2019 YtcTestNoticfication. All rights reserved.
//

#import "ViewController.h"

#import "DataStoreMan.h"
#import "testModel.h"
@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITextView *deskF;

@property (strong, nonatomic) NSMutableArray *arr;

@property (strong, nonatomic) DataStoreMan *man;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.man = [DataStoreMan ShareInstance];
    
    self.arr = [NSMutableArray array];
    
}


- (IBAction)lastPage:(UIButton *)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}



- (IBAction)store:(UIButton *)sender {
 

        
        [self.man Storeman_WithdrawWithKey:@"啦啦啦" Response:^(id  _Nonnull money, NSDictionary * _Nonnull info) {
            NSMutableArray *arr;
            if (money == nil) {
                arr = [NSMutableArray array];
            }else{
                arr = (NSMutableArray*)money;
            }
            
            testModel *md = [[testModel alloc]init];
            md.content = self.deskF.text;
            [arr addObject:md];
            [self.man Storeman_StoreDataWithKey:@"啦啦啦" Value:arr Response:^(NSDictionary * _Nonnull info) {
                
                UIAlertController *Alert = [UIAlertController alertControllerWithTitle:@"successed" message:@"存储成功" preferredStyle:UIAlertControllerStyleAlert];
                [Alert addAction:[UIAlertAction actionWithTitle:@"title" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [Alert dismissViewControllerAnimated:Alert completion:^{
                        [Alert dismissViewControllerAnimated:YES completion:nil];
                    }];
                }]];
                [self presentViewController:Alert animated:YES completion:nil];
                
            }];
            
        }];
        

    
    
    
}

- (IBAction)withdraw:(UIButton *)sender {
    
    
    [self.man Storeman_WithdrawWithKey:@"啦啦啦" Response:^(id  _Nonnull money, NSDictionary * _Nonnull info) {
        NSMutableString *str = [NSMutableString string];
        if ([money isKindOfClass:[NSMutableArray class]]) {
            self.arr = (NSMutableArray*)money;
            for (testModel *md in self.arr) {
                [str appendString:md.content];
            }
        }
        self.deskF.text = str;
    }];
    
}


- (IBAction)nextPage:(UIButton *)sender {
    
    ViewController *VC = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"demo"];
    
    [self.navigationController pushViewController:VC animated:YES];
    
}



@end
