//
//  testModel.h
//  DataTransformer
//
//  Created by 杨天赐 on 2019/5/31.
//  Copyright © 2019 YtcTestNoticfication. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface testModel : NSObject

@property (strong, nonatomic) NSString *content;


@end

NS_ASSUME_NONNULL_END
