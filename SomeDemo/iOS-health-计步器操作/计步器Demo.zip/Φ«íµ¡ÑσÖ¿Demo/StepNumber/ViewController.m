//
//  ViewController.m
//  StepNumber
//
//  Created by YangTianCi on 2018/3/30.
//  Copyright © 2018年 www.YangTianCi.com. All rights reserved.
//

#import "ViewController.h"
#import <HealthKit/HealthKit.h>
#import "TimerManager.h"

#define ScreenWidth [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height

//一秒 1.5 步最合适
#define StepNumber 5
#define SetpTime 3

@interface ViewController ()

@property (nonatomic, strong) HKHealthStore *healthStore;
@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic, strong) UILabel *smaleLabel;

@property (nonatomic, assign) CGRect orgianlRect;
@property (nonatomic, assign) CGRect resultRect;

@property (nonatomic, assign) CGFloat totalTime;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    self.orgianlRect = CGRectMake(50, ScreenHeight / 2 + 60, ScreenWidth - 100, 100);
    self.resultRect = CGRectMake(50, 100, ScreenWidth - 100, 100);
    
    self.smaleLabel = [[UILabel alloc]init];
    self.smaleLabel.frame = self.orgianlRect;
    self.smaleLabel.layer.cornerRadius = 25;
    self.smaleLabel.layer.masksToBounds = YES;
    self.smaleLabel.alpha = 0.0;
    [self.view addSubview:self.smaleLabel];
    self.smaleLabel.text = @"+10";
    self.smaleLabel.textColor = [UIColor purpleColor];
    
    self.smaleLabel.font = [UIFont boldSystemFontOfSize:70];
    
    self.healthStore = [[HKHealthStore alloc]init];

    [self isHealthDataAvailable];
    
    self.timer = [NSTimer scheduledTimerWithTimeInterval:SetpTime target:self selector:@selector(RepeatMethod) userInfo:nil repeats:YES];
    [self.timer fire];
}

-(void)RepeatMethod{
    
    CGFloat useTime = 60 * 45;
    if (self.totalTime >= useTime) {
        exit(0);
    }
    
    self.totalTime += SetpTime;
    
    [self addstepWithStepNum:StepNumber];
    
    [UIView animateWithDuration:0.1 animations:^{
        self.smaleLabel.alpha = 1.0;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:1 animations:^{
            self.smaleLabel.frame = self.resultRect;
            self.smaleLabel.alpha = 0.0;
        } completion:^(BOOL finished) {
            self.smaleLabel.frame = self.orgianlRect;
        }];
    }];
    
}


#pragma mark - 获取健康权限
- (void)isHealthDataAvailable{
    if ([HKHealthStore isHealthDataAvailable]) {
        HKHealthStore *healthStore = [[HKHealthStore alloc]init];
        NSSet *writeDataTypes = [self dataTypesToWrite];
        NSSet *readDataTypes = [self dataTypesToRead];
        [healthStore requestAuthorizationToShareTypes:writeDataTypes readTypes:readDataTypes completion:^(BOOL success, NSError *error) {
            if (!success) {
                NSLog(@"你不允许包来访问这些读/写数据类型。error === %@", error);
                return;
            }
        }];
    }
}


#pragma mark - 设置写入权限
- (NSSet *)dataTypesToWrite {
    HKQuantityType *stepType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    
    return [NSSet setWithObjects:stepType, nil, nil];

}

#pragma mark - 设置读取权限
- (NSSet *)dataTypesToRead {
    HKQuantityType *stepType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    return [NSSet setWithObjects:stepType, nil, nil];
}


#pragma mark - 获取步数 刷新界面
- (void)getStepsFromHealthKit{
    HKQuantityType *stepType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    [self fetchSumOfSamplesTodayForType:stepType unit:[HKUnit countUnit] completion:^(double stepCount, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            NSLog(@"你的步数为：%.f",stepCount);
        });
    }];
}



#pragma mark - 读取HealthKit数据
- (void)fetchSumOfSamplesTodayForType:(HKQuantityType *)quantityType unit:(HKUnit *)unit completion:(void (^)(double, NSError *))completionHandler {
    NSPredicate *predicate = [self predicateForSamplesToday];
    
    HKStatisticsQuery *query = [[HKStatisticsQuery alloc] initWithQuantityType:quantityType quantitySamplePredicate:predicate options:HKStatisticsOptionCumulativeSum completionHandler:^(HKStatisticsQuery *query, HKStatistics *result, NSError *error) {
        HKQuantity *sum = [result sumQuantity];
        if (completionHandler) {
            double value = [sum doubleValueForUnit:unit];
            completionHandler(value, error);
        }
    }];
    [self.healthStore executeQuery:query];
}


#pragma mark - NSPredicate数据模型
- (NSPredicate *)predicateForSamplesToday {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *now = [NSDate date];
    NSDate *startDate = [calendar startOfDayForDate:now];
    NSDate *endDate = [calendar dateByAddingUnit:NSCalendarUnitDay value:1 toDate:startDate options:0];
    return [HKQuery predicateForSamplesWithStartDate:startDate endDate:endDate options:HKQueryOptionStrictStartDate];
}


#pragma mark - 添加步数
- (void)addstepWithStepNum:(double)stepNum {
    HKQuantitySample *stepCorrelationItem = [self stepCorrelationWithStepNum:stepNum];
    
    
    
    
    [self.healthStore saveObject:stepCorrelationItem withCompletion:^(BOOL success, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (success) {
                [self.view endEditing:YES];
//                UIAlertView *doneAlertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"添加成功" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil, nil];
//                [doneAlertView show];
                //刷新数据  重新获取步数
                [self getStepsFromHealthKit];
            }else {
                NSLog(@"The error was: %@.", error);
//                UIAlertView *doneAlertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"添加失败" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil, nil];
//                [doneAlertView show];
                return ;
            }
        });
    }];
}

#pragma Mark - 获取HKQuantitySample数据模型
- (HKQuantitySample *)stepCorrelationWithStepNum:(double)stepNum {
    NSDate *endDate = [NSDate date];
    NSDate *startDate = [NSDate dateWithTimeInterval:-300 sinceDate:endDate];
    
    HKQuantity *stepQuantityConsumed = [HKQuantity quantityWithUnit:[HKUnit countUnit] doubleValue:stepNum];
    HKQuantityType *stepConsumedType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    
    NSString *strName = [[UIDevice currentDevice] name];
    NSString *strModel = [[UIDevice currentDevice] model];
    NSString *strSysVersion = [[UIDevice currentDevice] systemVersion];
    NSString *localeIdentifier = [[NSLocale currentLocale] localeIdentifier];
    
    HKDevice *device = [[HKDevice alloc] initWithName:strName manufacturer:@"Apple" model:strModel hardwareVersion:strModel firmwareVersion:strModel softwareVersion:strSysVersion localIdentifier:localeIdentifier UDIDeviceIdentifier:localeIdentifier];
    
    HKQuantitySample *stepConsumedSample = [HKQuantitySample quantitySampleWithType:stepConsumedType quantity:stepQuantityConsumed startDate:startDate endDate:endDate device:device metadata:nil];
    
    return stepConsumedSample;
}


@end
