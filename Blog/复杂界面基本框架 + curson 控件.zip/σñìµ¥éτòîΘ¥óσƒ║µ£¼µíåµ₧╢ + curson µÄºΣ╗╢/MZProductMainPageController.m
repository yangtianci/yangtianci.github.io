//
//  MZProductMainPageController.m
//  RichGo
//
//  Created by 杨天赐 on 2021/1/25.
//  Copyright © 2021 chtwm. All rights reserved.
//

#import "MZProductMainPageController.h"

#import "MZProductViewModel.h"

#import "BaseScrollView.h"
#import "MPBusinessOpportunityPlaceView.h"

#import "MPScheduleModel.h"


#pragma mark ============================================== v4.0.5 内容

#import "MZPMPProductHeaderView.h"
#import "MZPMPBannerScrollView.h"

#import "MZPMPFirstSliderView.h"
#import "MZPMPSencondBanenrView.h"

#import "MZPMPSecondSliderView.h"
#import "MZPMPProductMentView.h"

#import "MZPMPImageBannerView.h"

#import "MZPMPThirdSliderView.h"
#import "MZPMPSubTableView.h"

#import "MZProductModel.h"

#import "MZGMWKWebViewController.h"
#import "MZSiMuPMPController.h"

#define First_MainHeadView_Height 170
#define Second_Banner_Height 65
#define Third_FirstSilder_Height 40
#define Fourth_FirstBanner_Height 120

#define Fifth_SecondSlider_Height 60
#define Sixth_SecondSession_Height 125

#define Seventh_SecondBanner_Height 120

#define Eighth_SubSlider_Height 75

#define Ninth_SubScrollview_Height kScreenH - kTopHeight - kTabBarHeight - Eighth_SubSlider_Height

static CGFloat BillCell_Heigth = 0.1;



#define MainScrollViewContent_Height First_MainHeadView_Height+Second_Banner_Height+Third_FirstSilder_Height+Fourth_FirstBanner_Height+Fifth_SecondSlider_Height+Sixth_SecondSession_Height+Seventh_SecondBanner_Height+Eighth_SubSlider_Height+Ninth_SubScrollview_Height+BillCell_Heigth


@interface MZProductMainPageController ()<UIScrollViewDelegate>

@property (strong, nonatomic) BaseScrollView *MainScrollView;

@property (nonatomic,assign) BOOL CanScroll_Main;

@property (strong, nonatomic) MZPMPProductHeaderView *MainHead;

@property (strong, nonatomic) MZPMPBannerScrollView *firstBanner;
    
@property (strong, nonatomic) MZPMPFirstSliderView *firstSlider;

@property (strong, nonatomic) MZPMPSencondBanenrView *secondBanner;

@property (strong, nonatomic) MZPMPSecondSliderView *secondSilder;

// 待修改
@property (strong, nonatomic) MPBusinessOpportunityPlaceView *businessOpportunityPlaceView;
@property (strong, nonatomic) UIView *MoneyManageView;
@property (strong, nonatomic) UIView *MoneyManageView_footerV;

@property (nonatomic,strong) MZPMPImageBannerView * thirdBanner;

@property (strong, nonatomic) MZPMPThirdSliderView *thirdSilder;

@property (strong, nonatomic) BaseScrollView *SubWrapperScrollView;

@property (strong, nonatomic) NSMutableArray *subTableViewArray;



@property (strong, nonatomic) MZProductViewModel *MainVM;

#pragma mark ============================================== 核心数据

// 观点聚焦
@property (strong, nonatomic) NSMutableArray *firstBannerDataArr;

// 理顾活动
@property (strong, nonatomic) NSMutableArray *firstSilderDataArr;
// 理顾活动 - banner
@property (strong, nonatomic) NSMutableArray *secondBannerDataArr;
// 活钱管理
@property (strong, nonatomic) NSMutableArray *secondSilderDataArr;
// 活钱管理 cell data - 二维数组
@property (strong, nonatomic) NSMutableArray *moneyManageCellDataArray;
// 活钱管理 cell - 二维数组
@property (strong, nonatomic) NSMutableArray *moneyManageCellViewArray;
// 活钱管理下 banner
@property (strong, nonatomic) NSMutableArray *thirdBannerDataArr;
// 荣耀榜单
@property (strong, nonatomic) NSMutableArray *thirdSilderDataArr;

@end

@implementation MZProductMainPageController


-(void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    // 下方 SubWrapperScrollView 跳转时自动改变 offset, 所以进入页面时需要读取并手动改变
    if (self.thirdSilder && self.SubWrapperScrollView) {
        self.SubWrapperScrollView.contentOffset = CGPointMake(kScreenW * self.thirdSilder.currentSelectIdx, 0);
    }

}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.CanScroll_Main = YES;
    
    [self ConfigUIMethod];
    
    [self AddRefreshMethod];
    
    // 需要将图层放在最上层, 因此位置放在此处
    [self GlobalConfig];
    
    // 滚动冲突解决需要的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(SolveConflictMethodWithNotic:) name:@"MPMainPageChangeScrollState" object:nil];
    
#pragma mark 测试数据
//    [self textSorce];
    
}



-(void)SolveConflictMethodWithNotic:(NSNotification*)notic{
    self.CanScroll_Main = YES;
    for (MZPMPSubTableView *subTable in self.subTableViewArray) {
        [subTable ChangeTabStatesMethodWithAimState:NO];
        
    }
}

-(void)GlobalConfig{
    
    self.MainVM = [[MZProductViewModel alloc]init];
    
    [self.view bringSubviewToFront:self.navBar];
    
    [self.navBar.leftBt setHidden:YES];
    self.navBar.alpha = 0.0;
    
    // 下划线
    UIView *lineView = [[UIView alloc]init];
    [self.navBar addSubview:lineView];
    lineView.backgroundColor = [UIColor colorWithHexString:@"efefef"];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.navBar.mas_bottom).with.offset(-0);
        make.right.mas_equalTo(self.navBar.mas_right).with.offset(-0);
        make.left.mas_equalTo(self.navBar.mas_left).with.offset(0);
        make.height.mas_equalTo(0.5);
    }];
    
}

-(void)AddRefreshMethod{
    
    __weak typeof(self)WS = self;
    
    MJRefreshNormalHeader *header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        [WS ReloadDataMethod];
        
    }];
    
    self.MainScrollView.mj_header = header;
    
    [self.MainScrollView.mj_header beginRefreshing];
    
}

// 观点聚焦
-(void)RequestViewPointFocusMethod{
//    [[CircleLoader shareInstance]stopAnimation];
    [self.MainVM RequestTextAndImageWithTypeName:@"恒品投条" PageNum:@"1" PageSize:@"6" Success:^(id  _Nonnull response) {
        
    } Fail:^(NSString * _Nonnull msg, id  _Nonnull info) {
        
        @try{
        }@catch(NSException*expt){
            [SRAlertView sr_showAlertWithMessage:@"返回信息解析失败"];
        }
        
    }];
    
}


// 产品首页活动标签查询
-(void)RequestMPActivityTagMethod{
    
    [self.MainVM RequestPMPTabsWithTypeName:@"产品首页活动" PageNum:@"1" PageSize:@"10" Success:^(id  _Nonnull response) {
        
    } Fail:^(NSString * _Nonnull msg, id  _Nonnull info) {
        
    }];
    
}


-(void)ReloadDataMethod{
    
    // 观点聚焦
    [self RequestViewPointFocusMethod];
    
    // 产品首页活动标签查询
    [self RequestMPActivityTagMethod];
    
    // app 首页查看 四笔钱信息 : 四笔钱类型 401 活钱管理 402 稳健理财 403 财富成长 404 养老计划
    [self.secondSilder ManualSetSelectIdx:0];
    [self RequestFourMoneyMethodWithPlateCode:@"401"];
    
    // 下方容器归位
    [self.thirdSilder ManualSetSelectIdx:0];
    
    [self.MainScrollView.mj_header endRefreshing];
}



-(void)ConfigUIMethod{
    
    __weak typeof(self)WS = self;
    
    // 界面布局依照最大可能高度进行布局, 头部, 中间 iCon, 下方 slider 均为固定高度, 唯一变动的就是下方 tableview cell 高度, cell 最多两行, 因此, 固定设置 cell 高度为 85
    
#pragma mark ============================================== MainScrollView
    self.MainScrollView = [[BaseScrollView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, kScreenH - kTabBarHeight)];
    [self.view addSubview:self.MainScrollView];
    self.MainScrollView.contentSize = CGSizeMake(kScreenW, MainScrollViewContent_Height);
    self.MainScrollView.scrollEnabled = YES;
    self.MainScrollView.showsVerticalScrollIndicator = NO;
    self.MainScrollView.showsHorizontalScrollIndicator = NO;
    self.MainScrollView.delegate = self;
    
#pragma mark ============================================== Fixed View
    
    
#pragma mark ================================ MainHead
    
    self.MainHead = [[MZPMPProductHeaderView alloc]init];
    [self.MainScrollView addSubview:self.MainHead];
    [self.MainHead configData];
    MJWeakSelf
    self.MainHead.iconBtnJumpBlock = ^(NSString * _Nonnull btnName) {
        if ([btnName isEqualToString:@"公募基金"]) {
            MZGMWKWebViewController * vc = [[MZGMWKWebViewController alloc] init];
            [vc ConfigOriginalUrlWith:@"" Info:nil];
            vc.hidesBottomBarWhenPushed = YES;
            [weakSelf.navigationController pushViewController:vc animated:YES];
        }else if ([btnName isEqualToString:@"私募基金"]){
            MZSiMuPMPController * vc = [[MZSiMuPMPController alloc] init];
            vc.hidesBottomBarWhenPushed = YES;
            [weakSelf.navigationController pushViewController:vc animated:YES];
        }else if ([btnName isEqualToString:@"私募FOF"]){
            
        }else if ([btnName isEqualToString:@"彩虹专户"]){
            
        }
    };
    
    self.MainHead.frame = CGRectMake(0, 0, kScreenW, First_MainHeadView_Height);
    
#pragma mark ================================ 第一个垂直文字 banner
    
    self.firstBanner = [[MZPMPBannerScrollView alloc]init];
    [self.MainScrollView addSubview:self.firstBanner];
    self.firstBanner.frame = CGRectMake(0, CGRectGetMaxY(self.MainHead.frame), kScreenW, Second_Banner_Height);
    
#pragma mark ================================ 理顾活动 slider
    
    self.firstSlider = [[MZPMPFirstSliderView alloc]init];
    [self.MainScrollView addSubview:self.firstSlider];
    self.firstSlider.frame = CGRectMake(0, CGRectGetMaxY(self.firstBanner.frame), kScreenW, Third_FirstSilder_Height);
    
    
    [self.firstSlider ConfigDataWithTitleArr:self.firstSilderDataArr];
    self.firstSlider.btnCallBack = ^(NSInteger idx, NSString * _Nonnull title) {
      
        
    };
    
#pragma mark ================================ 理顾活动 banner
    
    self.secondBanner = [[MZPMPSencondBanenrView alloc]init];
    [self.MainScrollView addSubview:self.secondBanner];
    self.secondBanner.frame = CGRectMake(0, CGRectGetMaxY(self.firstSlider.frame), kScreenW, Fourth_FirstBanner_Height);
    
#pragma mark ================================ 活钱管理 slider
    
    self.secondSilder = [[MZPMPSecondSliderView alloc]init];
    [self.MainScrollView addSubview:self.secondSilder];
    self.secondSilder.isAverage = YES;
    self.secondSilder.frame = CGRectMake(0, CGRectGetMaxY(self.secondBanner.frame), kScreenW, Fifth_SecondSlider_Height);
    
    
    [self.secondSilder ConfigDataWithTitleArr:@[@"活钱管理",@"稳健理财",@"财富成长",@"养老规划"]];
    self.secondSilder.btnCallBack = ^(NSInteger idx, NSString * _Nonnull title) {

        // 四笔钱类型 401 活钱管理 402 稳健理财 403 财富成长 404 养老计划
        NSString *code;
        if (idx == 0) {
            code = @"401";
        }else if (idx == 1) {
            code = @"402";
        }else if (idx == 2) {
            code = @"403";
        }else if (idx == 3) {
            code = @"404";
        }

        [WS RequestFourMoneyMethodWithPlateCode:code];
        
    };
    
    [self.secondSilder ManualSetSelectIdx:0];
    
    
#pragma mark ================================ 活钱管理容器
    
    self.MoneyManageView = [[UIView alloc]init];
    self.MoneyManageView.backgroundColor = [UIColor whiteColor];
    [self.MainScrollView addSubview:self.MoneyManageView];
    self.MoneyManageView.frame = CGRectMake(0, CGRectGetMaxY(self.secondSilder.frame), kScreenW, BillCell_Heigth);
    
    UIView *bgView = [[UIView alloc]init];
    [self.MoneyManageView addSubview:bgView];
    [bgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.MoneyManageView.mas_top);
        make.bottom.mas_equalTo(self.MoneyManageView.mas_bottom);
        make.left.mas_equalTo(self.MoneyManageView.mas_left).with.offset(15);
        make.right.mas_equalTo(self.MoneyManageView.mas_right).with.offset(-15);
    }];
    bgView.backgroundColor = [UIColor colorWithRed:252/255.0 green:242/255.0 blue:240/255.0 alpha:1];
    
#pragma mark ================================ 活钱管理_footer
    
    self.MoneyManageView_footerV = [[UIView alloc]init];
    self.MoneyManageView_footerV.backgroundColor = [UIColor whiteColor];
    [self.MainScrollView addSubview:self.MoneyManageView_footerV];
    self.MoneyManageView_footerV.frame = CGRectMake(0, CGRectGetMaxY(self.MoneyManageView.frame), kScreenW, 10);
    
    UIImageView *imgV = [[UIImageView alloc]init];
    [self.MoneyManageView_footerV addSubview:imgV];
    imgV.frame = CGRectMake(15, 0, kScreenW - 30, 10);
    imgV.image = [UIImage imageNamed:@"v4.0.5_02"];
    
#pragma mark ================================ 荣耀榜单上方 banner
    
    self.thirdBanner = [[MZPMPImageBannerView alloc]init];
    [self.MainScrollView addSubview:self.thirdBanner];

    self.thirdBanner.frame = CGRectMake(0, CGRectGetMaxY(self.MoneyManageView_footerV.frame), kScreenW, Seventh_SecondBanner_Height);
    
#pragma mark ================================ 荣耀榜单 slider
    
    self.thirdSilder = [[MZPMPThirdSliderView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.thirdBanner.frame), kScreenW, Eighth_SubSlider_Height)];
    [self.MainScrollView addSubview:self.thirdSilder];
    
    [self.thirdSilder ConfigDataWithTitleArr:self.thirdSilderDataArr];
    self.thirdSilder.btnCallBack = ^(NSInteger idx, NSString * _Nonnull title) {
      
        [UIView animateWithDuration:0.2 animations:^{
            WS.SubWrapperScrollView.contentOffset = CGPointMake(kScreenW * idx, 0);
            
        } completion:^(BOOL finished) {
            
            MZPMPSubTableView *subTab = WS.subTableViewArray[idx];
            [subTab RefreshMethodForSuperView];
            
        }];
        
    };
    
#pragma mark ================================ 底部 ScrollView
    
    self.SubWrapperScrollView = [[BaseScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.thirdSilder.frame), kScreenW, Ninth_SubScrollview_Height)];
    [self.MainScrollView addSubview:self.SubWrapperScrollView];

    self.SubWrapperScrollView.contentSize = CGSizeMake(kScreenW * self.thirdSilderDataArr.count, Ninth_SubScrollview_Height);

    self.SubWrapperScrollView.pagingEnabled = YES;
    self.SubWrapperScrollView.bounces = NO;
    self.SubWrapperScrollView.delegate = self;
    
    self.SubWrapperScrollView.scrollEnabled = NO;
    
    self.SubWrapperScrollView.directionalLockEnabled=YES;
    for (int i = 0; i < self.thirdSilderDataArr.count; i++) {
        
        MZPMPSubTableView *subTable = [[MZPMPSubTableView alloc]initWithFrame:CGRectMake(kScreenW * i, 0, kScreenW, Ninth_SubScrollview_Height)];
        [self.SubWrapperScrollView addSubview:subTable];
        subTable.idx = i;
        [subTable ChangeTabStatesMethodWithAimState:NO];
        
        // 下方列表条跳转
        
//        subTable.SubTabCallBack = ^(MPMainPageSubModel * _Nonnull md, NSInteger tabIdx) {
//
//            if (tabIdx == 0) {
//                // 偏好探测
//
//            }else if (tabIdx == 1){
//                // 线上活动
//            }else if (tabIdx == 2){
//                // 线下活动
//            }else if (tabIdx > 2){
//
//                if (tabIdx == 5) {
//                }else{
//                    // 其他跳转
//                }
//            }
//
//        };
        
        [self.subTableViewArray addObject:subTable];
        
    }
    
    self.MainScrollView.contentSize = CGSizeMake(kScreenW, MainScrollViewContent_Height);

}


#pragma mark ============================================== Delegate

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    
    if (scrollView == self.MainScrollView) {
        
        // 主界面根据 offset 改变透明度
        CGFloat VerticalY = scrollView.contentOffset.y;
        
        if (VerticalY < 210 && VerticalY > 0) {
            self.navBar.alpha = VerticalY / 210 * 1.0;
        }else if (VerticalY >= 210){
            self.navBar.alpha = 1.0;
        }else if (VerticalY <= 0){
            self.navBar.alpha = 0.0;
        }
        
        // 手势冲突解决
        
        CGFloat AimY = self.thirdSilder.frame.origin.y - kTopHeight;
        
        CGFloat currentY = scrollView.contentOffset.y;
        
        if (currentY >= AimY) {
            self.MainScrollView.contentOffset = CGPointMake(0, AimY);
            if (self.CanScroll_Main) {
                self.CanScroll_Main = NO;
                for (MZPMPSubTableView *subTable in self.subTableViewArray) {
                    subTable.CanScroll_Sub = YES;
                }
                
            }
        }
        if (!self.CanScroll_Main) {
            self.MainScrollView.contentOffset = CGPointMake(0, AimY);
        }
        
        
    }
}

#pragma mark - scrollView 滚动停止

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{

    if (scrollView == self.SubWrapperScrollView) {
        CGPoint CurP = self.SubWrapperScrollView.contentOffset;
        NSInteger page = CurP.x / kScreenW;
        if (self.thirdSilder) {
            if (page != self.thirdSilder.currentSelectIdx) {
                [self.thirdSilder ManualSetSelectIdx:page];
            }
        }
    }
}

#pragma mark ============================================== 多个网络请求

// app 首页查看 四笔钱信息
-(void)RequestFourMoneyMethodWithPlateCode:(NSString*)plateCode{
    
    [self.MainVM RequestFourMoneyWithPlateCode:plateCode PageSize:@"5" Success:^(id  _Nonnull response) {
        
        NSMutableArray *tempArr = [NSMutableArray array];
        
        NSArray *originArr = response[@"data"];
        
        for (int i = 0; i < originArr.count; i++) {
            
            NSDictionary *dict = originArr[i];
            MZProductModel *md = [[MZProductModel alloc]initWithDict:dict];
            [tempArr addObject:md];
        }
        
        // 四笔钱类型 401 活钱管理 402 稳健理财 403 财富成长 404 养老计划
        
        if ([plateCode isEqualToString:@"401"]) {
            self.moneyManageCellDataArray[0] = tempArr;
        }else if ([plateCode isEqualToString:@"402"]) {
            self.moneyManageCellDataArray[1] = tempArr;
        }else if ([plateCode isEqualToString:@"403"]) {
            self.moneyManageCellDataArray[2] = tempArr;
        }else if ([plateCode isEqualToString:@"404"]) {
            self.moneyManageCellDataArray[3] = tempArr;
        }
        
        // 赋值
        [self CustomRelaodMoneyManageLayoutMethodWithIdx:plateCode];
        
        
    } Fail:^(NSString * _Nonnull msg, id  _Nonnull info) {
        
        
        if ([msg isEqualToString:@"数据为空"]) {

        }

        @try{
        }@catch(NSException*expt){
            [SRAlertView sr_showAlertWithMessage:@"返回信息解析失败"];
        }
        
    }];
    
}




-(void)CustomRelaodMoneyManageLayoutMethodWithIdx:(NSString *)plateCode{
    
    NSArray *tempDataArr;
    if ([plateCode isEqualToString:@"401"]) {
        tempDataArr = self.moneyManageCellDataArray[0];
    }else if ([plateCode isEqualToString:@"402"]) {
        tempDataArr = self.moneyManageCellDataArray[1];
    }else if ([plateCode isEqualToString:@"403"]) {
        tempDataArr = self.moneyManageCellDataArray[2];
    }else if ([plateCode isEqualToString:@"404"]) {
        tempDataArr = self.moneyManageCellDataArray[3];
    }
    
#pragma mark ================================ 活钱管理容器
    
    for (int i = 0 ; i < self.moneyManageCellViewArray.count; i++) {
        MZPMPProductMentView *pmView = self.moneyManageCellViewArray[i];
        [pmView removeFromSuperview];
    }
    [self.moneyManageCellViewArray removeAllObjects];
    
    BillCell_Heigth = 0.1;
    MZPMPProductMentView *pmView1;
    for (int i = 0; i < tempDataArr.count; i++) {
        MZPMPProductMentView *pmView = [[MZPMPProductMentView alloc]init];
        [self.MoneyManageView addSubview:pmView];
        [pmView mas_makeConstraints:^(MASConstraintMaker *make) {
            if (i == 0) {
                make.top.equalTo(self.MoneyManageView.mas_top);
            }else{
                make.top.equalTo(pmView1.mas_bottom).offset(8);
            }
            make.left.mas_equalTo(23);
            make.right.mas_equalTo(-23);
            make.height.mas_equalTo(112);
        }];
        MZProductModel *md = tempDataArr[i];
        [pmView ConfigDataWithMd:md];
        [self.moneyManageCellViewArray addObject:pmView];
        pmView1 = pmView;
        
        BillCell_Heigth += 120;
    }
    
    [self ReloadAllHeightMethod];
}


-(void)ReloadAllHeightMethod{
    
#pragma mark ================================ 活钱管理容器
    self.MoneyManageView.frame = CGRectMake(0, CGRectGetMaxY(self.secondSilder.frame), kScreenW, BillCell_Heigth);
    
#pragma mark ================================ 活钱管理_footer
    self.MoneyManageView_footerV.frame = CGRectMake(0, CGRectGetMaxY(self.MoneyManageView.frame), kScreenW, 10);
    
#pragma mark ================================ 荣耀榜单上方 banner
    self.thirdBanner.frame = CGRectMake(0, CGRectGetMaxY(self.MoneyManageView_footerV.frame), kScreenW, Seventh_SecondBanner_Height);
    
#pragma mark ================================ 荣耀榜单 slider
    self.thirdSilder.frame = CGRectMake(0, CGRectGetMaxY(self.thirdBanner.frame), kScreenW, Eighth_SubSlider_Height);
    
#pragma mark ================================ 底部 ScrollView
    
    self.SubWrapperScrollView.frame = CGRectMake(0, CGRectGetMaxY(self.thirdSilder.frame), kScreenW, Ninth_SubScrollview_Height);
    
    self.MainScrollView.contentSize = CGSizeMake(kScreenW, MainScrollViewContent_Height);

}



#pragma mark ============================================== 基本数据懒加载

-(NSMutableArray *)subTableViewArray{
    if (!_subTableViewArray) {
        _subTableViewArray = [NSMutableArray array];
    }
    return _subTableViewArray;
}

-(NSMutableArray *)firstBannerDataArr{
    if (!_firstBannerDataArr) {
        _firstBannerDataArr = [NSMutableArray array];
    }
    return  _firstBannerDataArr;
}

-(NSMutableArray *)firstSilderDataArr{
    if (!_firstSilderDataArr) {
        _firstSilderDataArr = [NSMutableArray arrayWithArray:@[@"理顾活动",@"营销竞赛",@"客户活动"]];
    }
    return _firstSilderDataArr;
}

-(NSMutableArray *)secondBannerDataArr{
    if (_secondBannerDataArr) {
        _secondBannerDataArr = [NSMutableArray array];
    }
    return  _secondBannerDataArr;
}

-(NSMutableArray *)secondSilderDataArr{
    if (_secondSilderDataArr) {
        _secondSilderDataArr = [NSMutableArray arrayWithArray:@[@"活钱管理",@"稳健理财",@"财富成长",@"养老规划"]];
    }
    return _secondSilderDataArr;
}

-(NSMutableArray *)moneyManageCellViewArray{
    if (!_moneyManageCellViewArray) {
        _moneyManageCellViewArray = [NSMutableArray array];
    }
    return _moneyManageCellViewArray;;
}

-(NSMutableArray *)thirdBannerDataArr{
    if (!_thirdBannerDataArr) {
        _thirdBannerDataArr = [NSMutableArray array];
    }
    return _thirdBannerDataArr;
}

-(NSMutableArray *)thirdSilderDataArr{
    if (!_thirdBannerDataArr) {
        _thirdBannerDataArr = [NSMutableArray arrayWithArray:@[@"个人AUM",@"资产配置合伙人",@"理顾持仓收益率",@"客户资产权益"]];
    }
    return _thirdBannerDataArr;
}

-(NSMutableArray *)moneyManageCellDataArray{
    if (!_moneyManageCellDataArray) {
        _moneyManageCellDataArray = [NSMutableArray array];
        
        for (int i = 0; i < 4; i++) {
            NSMutableArray *innerArr = [NSMutableArray array];
            [_moneyManageCellDataArray addObject:innerArr];
        }
    }
    return _moneyManageCellDataArray;
}
#pragma mark 测试数据方法
-(void)textSorce{
    [self.thirdBanner ConfigDataWithMd:@[@"早报_分享",@"早报_分享",@"早报_分享"]];
    [self.secondBanner ConfigDataWithMd:@[@"早报_分享",@"早报_分享",@"早报_分享"]];
    self.moneyManageCellDataArray = @[@[@"",@""],@[]].mutableCopy;
    [self CustomRelaodMoneyManageLayoutMethodWithIdx:@"401"];
}
@end
