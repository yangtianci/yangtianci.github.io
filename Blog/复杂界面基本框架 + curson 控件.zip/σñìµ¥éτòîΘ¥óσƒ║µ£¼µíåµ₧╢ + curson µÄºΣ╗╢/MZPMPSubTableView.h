//
//  MZPMPSubTableView.h
//  RichGo
//
//  Created by 杨天赐 on 2021/1/25.
//  Copyright © 2021 chtwm. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MZPMPSubTableView : UIView

@property (assign, nonatomic) NSInteger idx;

-(void)ChangeTabStatesMethodWithAimState:(BOOL)canScroll;

@property (nonatomic,assign) BOOL CanScroll_Sub;

-(void)RefreshMethodForSuperView;

@property (copy, nonatomic) void(^SubTabCallBack)(id md, NSInteger tabIdx);

@end

NS_ASSUME_NONNULL_END
