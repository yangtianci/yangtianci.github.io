//
//  MZPMPSubTableView.m
//  RichGo
//
//  Created by 杨天赐 on 2021/1/25.
//  Copyright © 2021 chtwm. All rights reserved.
//

#import "MZPMPSubTableView.h"


#import "MZPMPThirdSliderCell.h"
#import "MZComeSoonView.h"

#import "MZProductViewModel.h"

#import "MZProductModel.h"

@interface MZPMPSubTableView ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>

@property (strong, nonatomic) MZProductViewModel *VM;

@property(nonatomic,strong) MZComeSoonView*blank;

@property (strong,nonatomic)UITableView *customTB;

@property (assign, nonatomic) BOOL canScoll;

// >>>>>>>>>>>>>> 刷新模板

@property (assign, nonatomic) NSInteger currentPage;
@property (strong, nonatomic) NSMutableArray *dataArr;


// 个人 AUM 才会用到的字段
@property (strong, nonatomic) NSString *collectDate;

#pragma mark ============================================== 个人 AUM 头部视图和组织 AUM 头部视图

@property (strong, nonatomic) UIView *AUMHeader;

@property (strong, nonatomic) UILabel *updateTimeLab;
@property (strong, nonatomic) UIButton *ruleBtn;
@property (strong, nonatomic) UILabel *ruleLab;

@end


@implementation MZPMPSubTableView


-(instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
    }
    return self;
}

-(void)setIdx:(NSInteger)idx{
    _idx = idx;
    [self creatView];
}

-(void)ChangeTabStatesMethodWithAimState:(BOOL)canScroll{
    
    self.CanScroll_Sub = canScroll;
    
}

-(void)RefreshMethodForSuperView{
    
    [self.customTB.mj_header beginRefreshing];
    
}

#pragma mark ============================================== Delegate



-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    if (scrollView == self.customTB) {
        
        if (!self.CanScroll_Sub) {
            scrollView.contentOffset = CGPointZero;
        }
        if (scrollView.contentOffset.y < 0) {
            self.CanScroll_Sub = NO;
            scrollView.contentOffset = CGPointZero;
            [[NSNotificationCenter defaultCenter]postNotificationName:@"MPMainPageChangeScrollState" object:nil];
        }
    }
    
}


-(void)creatView{
    //--必须设置--<##>
    CGRect tbRect = self.bounds;
    self.customTB = [[UITableView alloc]initWithFrame:tbRect style:UITableViewStyleGrouped];
    [self addSubview:self.customTB];
    self.customTB.delegate = self;
    self.customTB.dataSource = self;
    self.customTB.backgroundColor = [UIColor whiteColor];
//    self.customTB.bounces = NO;
    self.customTB.showsHorizontalScrollIndicator = NO;
    self.customTB.alwaysBounceHorizontal = NO;
    
    //--基本设置--<##>
    self.customTB.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.customTB.separatorColor = [UIColor lightGrayColor];
    
    // 预估行高
    self.customTB.estimatedRowHeight = 70;
    self.customTB.rowHeight = UITableViewAutomaticDimension;
    
    self.dataArr = [NSMutableArray array];
    self.currentPage = 1;
    
    
    [self.customTB registerClass:[MZPMPThirdSliderCell class] forCellReuseIdentifier:@"MZPMPThirdSliderCell"];
    
    [self AddRefreshMethod];
    
    if (self.idx == 0) {
        [self addAUMViewMethodWithType:1];
    }
    
}



-(void)AddRefreshMethod{
    
    __weak typeof(self)WS = self;
    
    self.VM = [[MZProductViewModel alloc]init];
    
    self.customTB.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [WS RefreshMethodWithType:0];
    }];
    
    if (self.idx != 0) {
        self.customTB.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
            [WS RefreshMethodWithType:1];
        }];
    }
    
    if (self.idx == 0) {
        [self.customTB.mj_header beginRefreshing];
    }
    
    
}


// 0 刷新 1 加载更多
-(void)RefreshMethodWithType:(NSInteger)refreshType{
    
    if (refreshType == 0) {
        // 刷新
        [self.customTB.mj_footer resetNoMoreData];
        self.currentPage = 1;
        
    }else{
        // 加载
        self.currentPage++;
    }
    
//    if (self.idx == 0) {
//    }else if (self.idx == 1){
//    }else if (self.idx == 2){
        
    
    if (self.idx == 0) {
        [self RequestAUMListMethod];
    }else if(self.idx == 1){
        [self ReqeustPartnerBillMethod];
    }else{
        
        [self addBlank];
        
    }
    
}

#pragma mark --数据源方法--

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArr.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MZProductModel *md = self.dataArr[indexPath.row];
    MZPMPThirdSliderCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MZPMPThirdSliderCell"];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    [cell ConfigDataWithMd:md];
    
    return cell;
    
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 65;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    return 0.01;
    
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *header = [[UIView alloc]init];
    return header;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *footer = [[UIView alloc]init];
    return footer;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MZProductModel *Omd = self.dataArr[indexPath.row];
    
    if (self.SubTabCallBack) {
        self.SubTabCallBack(Omd, self.idx);
    }
    
}

#pragma mark ============================================== 网络请求


-(void)ReqeustPartnerBillMethod{
    
    
    if(self.blank){
        [self.blank removeFromSuperview];
    }
    
    [[CircleLoader shareInstance]startAnimation];
    
    [self.VM RequestPartnerBillWithSuccess:^(id  _Nonnull response) {
        
        
        [[CircleLoader shareInstance]stopAnimation];
        
        if (self.currentPage == 1) {
            [self.dataArr removeAllObjects];
        }
        
        NSArray *dataDict = response[@"data"];
        
        NSMutableArray *tempArr = [NSMutableArray array];
        
        for (int i = 0; i<dataDict.count; i++) {
            NSDictionary * dict = dataDict[i];
            MZProductModel *md = [[MZProductModel alloc]initWithDict:dict];
            md.type = ASSET_MODEL_TYPE;
            md.rankNo = [NSString stringWithFormat:@"%d",i];
            [tempArr addObject:md];
        }
        
        [self.dataArr addObjectsFromArray:tempArr];
        
        [self.customTB reloadData];
        
        // 结束操作
        [self.customTB.mj_header endRefreshing];
        [self.customTB.mj_footer endRefreshing];
        if (tempArr.count < 10) {
            [self.customTB.mj_footer endRefreshingWithNoMoreData];
            
        }
        
        [self addBlank];
        
        
    } Fail:^(NSString * _Nonnull msg, id  _Nonnull info) {
        
        [[CircleLoader shareInstance]stopAnimation];
        //        [self.customTB reloadData];
        [self.customTB.mj_header endRefreshing];
        [self.customTB.mj_footer endRefreshing];
        [self addBlank];
        
        
    }];
    
    
    
}


-(void)RequestAUMListMethod{
    
    if(self.blank){
        [self.blank removeFromSuperview];
    }
    
    [[CircleLoader shareInstance]startAnimation];
    
    [self.VM RequestAUMBillWithSuccess:^(id  _Nonnull response) {
        
        [[CircleLoader shareInstance]stopAnimation];
        
        //        [self.dataArr removeAllObjects];
        if (self.currentPage == 1) {
            [self.dataArr removeAllObjects];
        }
        
        NSDictionary *dataDict = response[@"data"];
        NSArray *listArr = dataDict[@"aumRankingListVo"];
        self.collectDate = [NSString stringWithFormat:@"%@",dataDict[@"collectDate"]];
        
        NSMutableArray *tempArr = [NSMutableArray array];
        
        for (int i = 0; i < listArr.count; i++) {
            
            NSDictionary *dict = listArr[i];
            
            MZProductModel *md = [[MZProductModel alloc]initWithDict:dict];
            md.rankNo = [NSString stringWithFormat:@"%d",i];
            md.type = PERAUM_MODEL_TYPE;
            [tempArr addObject:md];
            
        }
        
        [self.dataArr addObjectsFromArray:tempArr];
        
        [self.customTB reloadData];
        
        // 结束操作
        [self.customTB.mj_header endRefreshing];
        [self.customTB.mj_footer endRefreshing];
        if (tempArr.count < 10) {
            [self.customTB.mj_footer endRefreshingWithNoMoreData];
            
        }
        
        [self addBlank];
        
    } Fail:^(NSString * _Nonnull msg, id  _Nonnull info) {
        
        [[CircleLoader shareInstance]stopAnimation];
        //        [self.customTB reloadData];
        [self.customTB.mj_header endRefreshing];
        [self.customTB.mj_footer endRefreshing];
        [self addBlank];
        
    }];
    
    
}



#pragma mark ============================================== 组织 AUM 上方 view

-(void)addAUMViewMethodWithType:(NSInteger)type{
    
    // 个人 1 团队 2
    
    self.AUMHeader = [[UIView alloc]init];
    self.AUMHeader.backgroundColor = [UIColor whiteColor];
    
    if (type == 1) {
        self.AUMHeader.frame = CGRectMake(0, 0, kScreenW, 35);
    }else{
        self.AUMHeader.frame = CGRectMake(0, 0, kScreenW, 70);
    }
    
    
#pragma mark ============================================== 更新时间
    
    CGRect timeLabRect = CGRectMake(15, 10, 300, 20);
    self.updateTimeLab = [[UILabel alloc]initWithFrame:timeLabRect];
    [self.AUMHeader addSubview:self.updateTimeLab];
    
    self.updateTimeLab.font = [UIFont systemFontOfSize:13];
    self.updateTimeLab.textColor = [UIColor colorWithHexString:@"999EAC"];
    self.updateTimeLab.textAlignment = NSTextAlignmentLeft;
    self.updateTimeLab.numberOfLines = 1;
    self.updateTimeLab.text = @"更新于:";

#pragma mark ============================================== 规则感叹号按钮
    
    //--必须设置--
    CGRect rulebtnRect = CGRectMake(self.frame.size.width - 15 - 16, 10, 16, 16);
    self.ruleBtn = [[UIButton alloc]initWithFrame:rulebtnRect];
    [self.AUMHeader addSubview:self.ruleBtn];
    //--基本设置--<##>
    [self.ruleBtn setImage:[UIImage imageNamed:@"v4.0.5_home_rule"] forState:UIControlStateNormal];

#pragma mark ============================================== 感叹号
    
    self.ruleLab = [[UILabel alloc]init];
    [self.AUMHeader addSubview:self.ruleLab];
    [self.ruleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.ruleBtn.mas_left).with.offset(-5);
        make.centerY.mas_equalTo(self.ruleBtn.mas_centerY);
    }];
    
    self.ruleLab.font = [UIFont systemFontOfSize:13];
    self.ruleLab.textColor = [UIColor colorWithHexString:@"999EAC"];
    self.ruleLab.textAlignment = NSTextAlignmentLeft;
    self.ruleLab.numberOfLines = 1;
    self.ruleLab.text = @"榜单规则";

    self.customTB.tableHeaderView = self.AUMHeader;

}




#pragma mark ================= 占位图
-(void)addBlank{
    
    if (self.dataArr.count == 0) {
        [self addSubview:self.blank];
    } else{
        if(self.blank){
            [self.blank removeFromSuperview];
        }
    }
    
}


-(MZComeSoonView *)blank{
    if (!_blank) {
        _blank = [[NSBundle mainBundle]loadNibNamed:@"MZComeSoonView" owner:self options:nil].firstObject;
        _blank.frame = CGRectMake(0, 0, SCREENWIDTH, self.customTB.frame.size.height);
        _blank.userInteractionEnabled = NO;
    }
    return _blank;
}



@end
