//
//  MZPMPThirdSliderView.h
//  RichGo
//
//  Created by 杨天赐 on 2021/1/25.
//  Copyright © 2021 chtwm. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MZPMPThirdSliderView : UIView


// 配置标题
-(void)ConfigDataWithTitleArr:(NSArray*)titleArr;

// 是否均分
@property (assign, nonatomic) BOOL isAverage;

// 默认选中位置
@property (assign, nonatomic) NSInteger defaultSelectIdx;

// 选中回调
@property (copy, nonatomic) void(^btnCallBack)(NSInteger idx, NSString *title);

// 手动选中某个 idx
-(void)ManualSetSelectIdx:(NSInteger)idx;

@property (assign, nonatomic) NSInteger currentSelectIdx;


@end

NS_ASSUME_NONNULL_END
