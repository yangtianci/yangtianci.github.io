//
//  MZPMPThirdSliderView.m
//  RichGo
//
//  Created by 杨天赐 on 2021/1/25.
//  Copyright © 2021 chtwm. All rights reserved.
//

#import "MZPMPThirdSliderView.h"


@interface MZPMPThirdSliderView ()

@property (strong, nonatomic) UILabel *titleLab;

@property (strong, nonatomic) UIScrollView *MainScrollView;

@property (strong, nonatomic) UIView *cursonView;

@property (strong, nonatomic) UIView *lineView;

@property (strong, nonatomic) NSMutableArray *BtnArr;


@property (strong, nonatomic) NSArray *titleArr;

@property (strong, nonatomic) UIButton *selectBtn;


@end


@implementation MZPMPThirdSliderView


static CGFloat NormalFont = 14;
static CGFloat SelectFont = 14;
static CGFloat FirstAndLastMargin = 15;
static CGFloat MiddleMargin = 15;

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
    }
    return self;
}

-(void)ConfigUI{
    
    self.backgroundColor = [UIColor whiteColor];
    
#pragma mark ============================================== titleLab
    
    self.titleLab = [[UILabel alloc]init];
    self.titleLab.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.titleLab];
    self.titleLab.text = @"荣耀榜单";
    self.titleLab.textColor = [UIColor colorWithHexString:@"33343B"];
    self.titleLab.font = [UIFont boldSystemFontOfSize:18];
    self.titleLab.frame = CGRectMake(10, 10, 200, 20);

    
    UIView *placeView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, 0.1)];
    [self addSubview:placeView];
    placeView.backgroundColor = [UIColor whiteColor];
    
#pragma mark ============================================== BtnArr
    
    CGRect RectMainScrollView = CGRectMake(0, 30, self.frame.size.width, self.frame.size.height - 30);
    
    self.MainScrollView = [[UIScrollView alloc]initWithFrame:RectMainScrollView];
    [self addSubview:self.MainScrollView];
    self.MainScrollView.contentSize = CGSizeMake(kScreenW, RectMainScrollView.size.height);
    self.MainScrollView.showsVerticalScrollIndicator = NO;
    self.MainScrollView.showsHorizontalScrollIndicator = NO;
    self.MainScrollView.backgroundColor = [UIColor whiteColor];
    
#pragma mark ============================================== lineView
    
    self.MainScrollView.bounces = NO;
    
#pragma mark ============================================== Cusron
    
    [self.MainScrollView addSubview:self.cursonView];
    self.cursonView.frame = CGRectMake(0, self.MainScrollView.frame.size.height - 5, 15, 3);
    self.cursonView.backgroundColor = [UIColor colorWithHexString:@"DA2C1F"];
    
    
#pragma mark ============================================== BtnS
    
    CGFloat itemX = 0;
    CGFloat itemY = 15;
    CGFloat itemWidth = 0;
    CGFloat itemH = self.frame.size.height - 60;
    
    
    
    NSInteger defaultIdx = self.defaultSelectIdx;
    
    for (int i = 0; i < self.titleArr.count; i++) {
        
        if (self.isAverage == YES) {
            itemX = itemWidth * i;
        }else{
            itemX = itemX + itemWidth;
            if (i == 0) {
                itemX += FirstAndLastMargin;
            }else{
                itemX += MiddleMargin;
            }
        }
        
        NSString *titleString = self.titleArr[i];
        
        if (self.isAverage == YES) {
            NSInteger count = self.titleArr.count;
            itemWidth = kScreenW / count;
        }else{
            itemWidth = [titleString boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, self.MainScrollView.frame.size.height) options:NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:SelectFont]} context:nil].size.width;
        }
        
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(itemX, itemY, itemWidth, itemH)];
        [self.MainScrollView addSubview:btn];
        
        [btn setTitle:titleString forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor colorWithHexString:@"DA2C1F"] forState:UIControlStateSelected];
        [btn setTitleColor:[UIColor colorWithHexString:@"4E5063"] forState:UIControlStateNormal];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:NormalFont]];
        
        btn.tag = i;
        [btn addTarget:self action:@selector(TagMethodWithSender:) forControlEvents:UIControlEventTouchUpInside];
        
        if (i == defaultIdx) {
            
            [self TagMethodWithSender:btn];
            
        }
        
        [self.BtnArr addObject:btn];
        
    }
    
    UIButton *lastBtn = self.BtnArr.lastObject;
    CGFloat scrollWidth = CGRectGetMaxX(lastBtn.frame) + FirstAndLastMargin;
    self.MainScrollView.contentSize = CGSizeMake(scrollWidth, 45);
    
    self.currentSelectIdx = 0;
    
    
    
}

-(void)TagMethodWithSender:(UIButton*)sender{
    
    self.selectBtn.selected = NO;
    self.selectBtn.titleLabel.font = [UIFont systemFontOfSize:NormalFont];
    
    
    
    self.selectBtn = sender;
    self.selectBtn.selected = YES;
    self.selectBtn.titleLabel.font = [UIFont systemFontOfSize:SelectFont];
    
    // 赋值当前位置
    self.currentSelectIdx = self.selectBtn.tag;
    
    CGRect originRect = self.cursonView.frame;
    originRect.origin.x = sender.frame.origin.x + ( sender.frame.size.width - originRect.size.width ) / 2;
    
#pragma mark ============================================== 计算偏移
    CGFloat btnX = self.selectBtn.x;
    CGFloat btnMaxX = CGRectGetMaxX(self.selectBtn.frame);
    
    CGFloat scrollX = self.MainScrollView.contentOffset.x;
    CGFloat scrollMaxX = self.MainScrollView.contentOffset.x + self.MainScrollView.size.width;
    
    CGPoint offetSet;
    
    if (btnX > scrollX && btnMaxX < scrollMaxX) {
        // 范围内, 不操作
        offetSet = self.MainScrollView.contentOffset;
    }else{
        if (btnX < scrollX) {
            offetSet = CGPointMake(btnX - MiddleMargin, 0);
        }else {
            offetSet = CGPointMake(btnMaxX - self.MainScrollView.frame.size.width + MiddleMargin, 0);
        }
    }
    
    [UIView animateWithDuration:0.2 animations:^{
        self.cursonView.frame = originRect;
        if (!self.isAverage) {
            self.MainScrollView.contentOffset = offetSet;
        }
    }];
    
    if (self.btnCallBack) {
        self.btnCallBack(sender.tag, sender.titleLabel.text);
    }
    
}

-(void)ManualSetSelectIdx:(NSInteger)idx{
    
    [self TagMethodWithSender:self.BtnArr[idx]];
    
}



-(void)ConfigDataWithTitleArr:(NSArray *)titleArr{
    self.titleArr = titleArr;
    [self ConfigUI];
}



#pragma mark ============================================== lazy



-(NSMutableArray *)BtnArr{
    if (!_BtnArr) {
        _BtnArr = [NSMutableArray array];
    }
    return _BtnArr;
}

-(UIView *)cursonView{
    
    if (!_cursonView) {
        _cursonView = [[UIView alloc]init];
    }
    return _cursonView;
}

-(UIView *)lineView{
    if (!_lineView) {
        _lineView = [[UIView alloc]init];
    }
    return _lineView;
}

@end
