//
//  MZProductMainPageController.h
//  RichGo
//
//  Created by 杨天赐 on 2021/1/25.
//  Copyright © 2021 chtwm. All rights reserved.
//

#import "CommenNavController.h"

NS_ASSUME_NONNULL_BEGIN

/**
 
 复杂页面编写步骤_列表内部多种不同数据变动, 下方还含有另外 tableview 的页面, 虽然理论上用 tableview 为主体, 以数据驱动 cell 类型也可以做到, 但是感觉效率不高, 因为没有有效使用重用功能, 而且下方的 tableview 如果可以切换的话, 无法完成左右手势切换, 因此, 还是采用 scrollview 的方式进行手动拼接
 
 1. 设置多个控件的高度常量或变量
 2. configUI 时按照预设高度进行生成布局, MainScrollview 内部高度为总高度
 3. 刷新数据, 获取数据后根据数据内容更新高度常量, 然后自定义刷新 MainScrollview 的视图内容, 循环创建等
 
 注意: scrollview 需要用特殊 scrollview 继承, tableview 内部也有特殊参数需要添加
 
 使用的时候
    1.划分页面模块, 设置对应的参数和常量
    2.重写 configUI 函数, 设置参数
    3.自定义 view 内部创建对应赋值函数, 以及无数据处理函数
    4.网络请求函数, 以及赋值函数, 最后处理界面刷新函数 
    5.MPSubTabView 必须全局替换掉, 另外, tableArray 一定有值, 否则滚动会失效 
 
 
 */

@interface MZProductMainPageController : CommenNavController


@end

NS_ASSUME_NONNULL_END
