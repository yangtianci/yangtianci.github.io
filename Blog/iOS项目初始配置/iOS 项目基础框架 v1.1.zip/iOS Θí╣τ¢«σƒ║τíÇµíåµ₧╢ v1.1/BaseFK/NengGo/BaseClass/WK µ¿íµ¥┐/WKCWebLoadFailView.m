//
//  WebLoadFailView.m
//  WebDemo
//
//  Created by 李江 on 2020/3/18.
//  Copyright © 2020 dd. All rights reserved.
//

#import "WKCWebLoadFailView.h"
@interface WKCWebLoadFailView ()
@property (weak, nonatomic) IBOutlet UIView *view;
@end
@implementation WKCWebLoadFailView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


+ (instancetype)loadFailView {
    WKCWebLoadFailView *failView = [[UINib nibWithNibName:NSStringFromClass(self.class) bundle:nil]instantiateWithOwner:nil options:nil].firstObject;
    return failView;
}



- (IBAction)refresh:(id)sender {
    if (_didRefreshBlock) {
        _didRefreshBlock();
    }
}

@end
