//
//  PMCallRecordListViewController.h
//  RichGo
//
//  Created by 李江 on 2020/4/16.
//  Copyright © 2020 chtwm. All rights reserved.
//

#import "CommenNavController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TempWKWebViewController : CommenNavController

//导航栏标题
@property (copy, nonatomic) NSString *navBarTitle;
//远程html链接。 或者本地html
-(void)ConfigOriginalUrlWith:(NSString*)originalUrl Info:(NSDictionary*)info;

@property (copy, nonatomic) void(^BackRefreshCallBack)(void);

@end

NS_ASSUME_NONNULL_END
