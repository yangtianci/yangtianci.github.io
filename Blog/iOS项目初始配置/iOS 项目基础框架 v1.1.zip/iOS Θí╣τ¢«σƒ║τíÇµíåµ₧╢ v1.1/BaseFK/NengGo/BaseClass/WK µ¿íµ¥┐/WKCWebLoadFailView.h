//
//  WebLoadFailView.h
//  WebDemo
//
//  Created by 李江 on 2020/3/18.
//  Copyright © 2020 dd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WKCWebLoadFailView : UIView

@property (copy, nonatomic) void(^didRefreshBlock)();

+ (instancetype)loadFailView;

@end

NS_ASSUME_NONNULL_END
