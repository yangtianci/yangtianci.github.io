//
//  PMCallRecordListViewController.m
//  RichGo
//
//  Created by 李江 on 2020/4/16.
//  Copyright © 2020 chtwm. All rights reserved.
//

#import "TempWKWebViewController.h"
#import <WebKit/WebKit.h>
#import "WKCWebLoadFailView.h"
#import "NSArray+common.h"
@interface TempWKWebViewController () <WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler>

#pragma mark ================================ UI
@property (strong, nonatomic) WKWebView *webView;
@property (strong, nonatomic) WKCWebLoadFailView *webLoadFailView;
@property (strong, nonatomic) UIProgressView *progressView;


#pragma mark ================================ Important Data
//cookie
@property (copy, nonatomic) NSDictionary *cookieDictionary;
//ssl
@property (strong, nonatomic) NSMutableURLRequest *request;
@property (nonatomic) SSLAuthenticate authenticated;
@property (strong, nonatomic) NSURLConnection *urlConnection;

#pragma mark ================================ Url
@property (copy, nonatomic) NSString *originalUrl;
@property (copy, nonatomic) NSString *loadUrl;

#pragma mark ================================ Custom Para


@end

@implementation TempWKWebViewController

//- (instancetype)init
//{
//    self = [super init];
//    if (self) {
//        _navBarTitle = @"通话记录";
////        _urlString = @"http://lgbh5.dev.chtwm.com/lgbCdn/homePage/callRecordPage/callRecordPage.html?customerNo=463368&customerType=0";
////        _urlString = @"webDemo.html";
//    }
//    return self;
//}

-(void)ConfigOriginalUrlWith:(NSString *)originalUrl Info:(NSDictionary *)info{
    
    self.originalUrl = originalUrl;
    
    if ([self.originalUrl containsString:@"?"]) {
        self.loadUrl = [self appendMaiDianWithUrlString:self.originalUrl isHavePara:YES];
    }else{
        self.loadUrl = [self appendMaiDianWithUrlString:self.originalUrl isHavePara:NO];
    }

}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self configUI];
    [self globalConfig];
    
}

- (void)globalConfig {
    self.navBar.title = _navBarTitle;
    //加载 webView;
    [self loadWebView];
    
    //注册 js 方法
    [self registJsMethod];

    //加载失败 重新加载web
    typeof(self) weakSelf = self;
    self.webLoadFailView.didRefreshBlock = ^{
        if (weakSelf.request && weakSelf.request.URL.absoluteString) {
            [weakSelf loadWebView];
        }
    };
    
}

#pragma mark ============================================== Custom Logic

// 此处放置 JS 调用函数

#pragma mark ============================================== 自定义 OC - JS 交互

#pragma mark ================================ OC 调用 JS

- (void)callJsWithJSCommand:(NSString*)jsCommand{
    [_webView evaluateJavaScript:jsCommand completionHandler:^(id _Nullable result, NSError * _Nullable error) {
        NSLog(@"%@",error);
    }];
}

#pragma mark ================================ JS 调用 OC
- (void)registJsMethod{
    WKUserContentController *userContentController = self.webView.configuration.userContentController;
    
    // 此处注册 JS 可调用函数名称
    
//    [userContentController addScriptMessageHandler:self name:<#MethodName#>];
    
}

//js回调  第一种方式
#pragma mark - WKScriptMessageHandler
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    
//    NSLog(@"方法名字：%@ 方法内容：%@",message.name, message.body);
    
//    if ([message.name isEqualToString:@""]) {
//        // todo
//    }
    
}

//拦截链接 js回调  第二种方式
- (void)interceptLinkUrl:(NSString *)urlString {
    NSString *contentUrlString = [urlString substringFromIndex:9];
    //以斜杠分隔
    NSArray *slashArray = [contentUrlString componentsSeparatedByString:@"/"];
    //当前类型
    NSString *currentType = [NSString stringWithFormat:@"%@",[slashArray objectNonNilAtIndex:1]];

    NSRange typeRange = [contentUrlString rangeOfString:currentType];
    NSString *paramString = @"";
    //方法名字
    NSString *funcName = @"";
    if ([contentUrlString containsString:@"?"]) {
        NSString *subStr1 = [contentUrlString substringFromIndex:typeRange.location + typeRange.length + 1];
        NSArray *subArray1 = [subStr1 componentsSeparatedByString:@"?"];
        funcName = [subArray1 objectNonNilAtIndex:0];
        paramString = [subArray1 objectNonNilAtIndex:1];
    }else {
        funcName = [contentUrlString substringFromIndex:typeRange.location + typeRange.length + 1];
    }
    //方法参数
    NSMutableDictionary *paramDictionary = [NSMutableDictionary dictionary];
    if (paramString.length > 0) {
        if ([paramString containsString:@"&"]) {
            NSArray *paramArray = [paramString componentsSeparatedByString:@"&"];
            [paramArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSString *str = obj;
                NSArray *array = [str componentsSeparatedByString:@"="];
                NSString *key = [array objectNonNilAtIndex:0];
                NSString *value = [array objectNonNilAtIndex:1];
                [paramDictionary setValue:value forKey:key];
            }];
        }else {
            NSArray *array = [paramString componentsSeparatedByString:@"="];
            NSString *key = [array objectNonNilAtIndex:0];
            NSString *value = [array objectNonNilAtIndex:1];
            [paramDictionary setValue:value forKey:key];
        }
    }

    if ([currentType isEqualToString:@""]) {
        //类型。页面
        if ([funcName isEqualToString:@""]) {
            //todo
            
        }
    }
}


#pragma mark ============================================== 自定义交互内容





#pragma mark ============================================== WKWebView Cookie & 代理


//加载html
- (void)loadWebView {
    if ([self.loadUrl containsString:@"http://"] || [self.loadUrl containsString:@"https://"]) {
        //同步cookie
        [self synchronizeCookie];
        //设置cookie
        [self setConfig];
        //加载远程html
        _request = [[NSMutableURLRequest alloc]initWithURL:[NSURL URLWithString:self.loadUrl]];
        [_request setValue:_cookieDictionary[@"header"] forHTTPHeaderField:@"Cookie"];
       
        [self.webView loadRequest:_request];
    }else {
        //加载本地html
//        if ([self.loadUrl containsString:@".html"]) {
//            NSString *path = [[NSBundle mainBundle]pathForResource:self.loadUrl ofType:nil];
//            _request = [[NSMutableURLRequest alloc]initWithURL:[NSURL fileURLWithPath:path]];
//      
//            [self.webView loadRequest:_request];
//        }
    }
}

#pragma mark ================================ 设置-埋点-工具

-(NSString *)appendMaiDianWithUrlString:(NSString *)urlString isHavePara:(BOOL)have{
    
    urlString = [[FlyweightPool shared].urlformatManager urlformat_appendMaiDianSimpleWithOrginalStr:urlString isHavePara:have];
    urlString = [urlString stringByReplacingOccurrencesOfString:@"%23" withString:@"#"];
    return urlString;
}

#pragma mark - WKNavigationDelegate


// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    
//    //账号被踢掉
    if ([webView.URL.absoluteString containsString:@"tologin.html"]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            AppDelegate *app = (AppDelegate *)[[UIApplication  sharedApplication] delegate];
            app.tokenString=nil;
        });
        return;
    }
    
#pragma mark - 后续可能优化
    NSLog(@"开始加载: %@ 授权:%d==%@", [webView.URL absoluteString], _authenticated,[[[webView.URL absoluteString] componentsSeparatedByString:@"/"]lastObject]);
    if (!_authenticated&& [webView.URL.scheme hasPrefix:@"https"]) {
        _authenticated = NO;

        _urlConnection = [[NSURLConnection alloc] initWithRequest:_request delegate:self];

        [_urlConnection start];
    }
    

}


//开始加载时失败
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(nonnull NSError *)error {
    if([error code] == NSURLErrorCancelled){
        
        _webLoadFailView.hidden = YES;
        return;
    }else{
        _webLoadFailView.hidden = NO;
    }
}

//加载框架失败
- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    _webLoadFailView.hidden = NO;
}

//拦截请求
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    NSString *urlString = [NSString stringWithFormat:@"%@",navigationAction.request.URL.absoluteURL.absoluteString];
    if ([urlString containsString:@"richgo://"]) {
        //js掉oc
        [self interceptLinkUrl:urlString];
        decisionHandler(WKNavigationActionPolicyCancel);
    }else {
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}


//如果不实现这个方法,将允许响应web视图,如果web视图可以表现出来。(在收到响应后，决定是否跳转)
- (void)webView:(WKWebView *)webViecw decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler
{
    NSHTTPURLResponse *response = (NSHTTPURLResponse *)navigationResponse.response;
    if (response.statusCode == 200) {
        //加载成功
        _webLoadFailView.hidden = YES;
    }else {
        //加载失败
        _webLoadFailView.hidden = NO;
    }
#pragma mark - 后续可能优化
    
    //获取cookie 并存到本地
//    if (@available(iOS 11.0, *)) {//iOS11也有这种获取方式，但是我使用的时候iOS11系统可以在response里面直接获取到，只有iOS12获取不到
//        WKHTTPCookieStore *cookieStore = webViecw.configuration.websiteDataStore.httpCookieStore;
//        [cookieStore getAllCookies:^(NSArray* cookies) {
//            for (NSHTTPCookie *cookie in cookies) {
//                if ([cookie.name containsString:@"token"]) {
//                    
//                }else{
//                    
//                    [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
//                }
//            }
//        }];
//    }else {
//        NSArray *cookies =[NSHTTPCookie cookiesWithResponseHeaderFields:[response allHeaderFields] forURL:response.URL];
//        for (NSHTTPCookie *cookie in cookies) {
//            if ([cookie.name containsString:@"token"]) {
//                
//            }else{
//                
//                [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
//            }
//        }
//    }
    
    decisionHandler(WKNavigationResponsePolicyAllow);
}

- (void)webView:(WKWebView*)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge*)challenge completionHandler:(void(^)(NSURLSessionAuthChallengeDisposition,NSURLCredential*_Nullable))completionHandler {
    if([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
        NSURLCredential *card = [[NSURLCredential alloc] initWithTrust:challenge.protectionSpace.serverTrust];
        completionHandler(NSURLSessionAuthChallengeUseCredential,card);
    }

}

#pragma mark - WKUIDelegate

/**
 *  web界面中有弹出警告框时调用
 *
 *  @param webView           实现该代理的webview
 *  @param message           警告框中的内容
 *  @param frame             主窗口
 *  @param completionHandler 警告框消失调用
 */
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler
{
#pragma mark - 后续可能优化
    UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertVc addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }]];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertVc animated:YES completion:nil];
    completionHandler();
}

#pragma mark - NSURLConnectionDataDelegate 
#pragma mark - 后续可能优化
- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge{
    NSLog(@"WebController 已经得到授权正在请求 NSURLConnection");
    if ([challenge previousFailureCount] == 0){
        _authenticated = kTryAuthenticate;

        NSURLCredential *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];

        [challenge.sender useCredential:credential forAuthenticationChallenge:challenge];

    } else{
        [[challenge sender] cancelAuthenticationChallenge:challenge];
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    NSLog(@"WebController 已经收到响应并通过了 NSURLConnection请求");

    _authenticated = kTryAuthenticate;
    [self.webView loadRequest:_request];
    [_urlConnection cancel];
}

- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace{

    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

#pragma mark - KVO
// 计算wkWeb进度条
//- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
//    if (object == _webView && [keyPath isEqualToString:@"estimatedProgress"]) {
//        CGFloat newprogress = [[change objectForKey:NSKeyValueChangeNewKey] doubleValue];
//        _progressView.progress = newprogress;
//        if (newprogress >= 1) {
//            _progressView.hidden = YES;
//        }else {
//            _progressView.hidden = NO;
//        }
//    }
//    
//}

- (void)configUI {
    [self.view addSubview:self.webView];
    self.webView.frame = CGRectMake(0, kTopHeight, SCREENWIDTH, SCREENHEIGHT - kTopHeight - kTAB_BAR_BOTTOM);
//    [self.view addSubview:self.progressView];
//    self.progressView.frame = CGRectMake(0, kNavBarHeight, SCREENWIDTH, 1);
    [self.view addSubview:self.webLoadFailView];
    [self.webLoadFailView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(_webView);
    }];
    //observe
//    [_webView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:nil];
    //lzh_edit_v3.5.0
    [self ConfigProgressviewWithWebView:self.webView];
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

//- (UIProgressView *)progressView {
//    if (!_progressView) {
//        _progressView = [UIProgressView new];
//    }
//    return _progressView;
//}

- (WKWebView *)webView {
    if (!_webView) {
        WKWebViewConfiguration *config = [WKWebViewConfiguration new];
        WKUserContentController *userContentController = [WKUserContentController new];
        config.userContentController = userContentController;
        _webView = [[WKWebView alloc]initWithFrame:CGRectZero configuration:config];
        _webView.UIDelegate = self;
        _webView.navigationDelegate = self;
    }
    return _webView;
}

- (WKCWebLoadFailView *)webLoadFailView {
    if (!_webLoadFailView) {
        _webLoadFailView = [WKCWebLoadFailView loadFailView];
        _webLoadFailView.hidden = YES;
    }
    return _webLoadFailView;
}


- (void)setConfig {
    WKWebViewConfiguration *config = _webView.configuration;
    WKUserContentController* userContentController = config.userContentController;
    
     WKUserScript *cookieScript = [[WKUserScript alloc]initWithSource:_cookieDictionary[@"documentCookie"] injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:NO];
     [userContentController addUserScript:cookieScript];
    
}

- (void)synchronizeCookie {
    //先清空cookie
    NSHTTPCookieStorage *cookieJar = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSArray *_tmpArray = [NSArray arrayWithArray:[cookieJar cookies]];
    for (id obj in _tmpArray) {
        [cookieJar deleteCookie:obj];
    }
    //    设置cookie
    NSString *token = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:TOKENSTRING]];
    NSString*domain_final = [self GetDominNameWithOriginalUrl:self.originalUrl];
    NSString *path = @"/";
    NSMutableDictionary *cookieProperties = [[NSMutableDictionary alloc]init];
    [cookieProperties setObject:@"token" forKey:NSHTTPCookieName];
    [cookieProperties setObject:token forKey:NSHTTPCookieValue];
    [cookieProperties setObject:domain_final forKey:NSHTTPCookieDomain];
    [cookieProperties setObject:path forKey:NSHTTPCookiePath];
    [cookieProperties setObject:@"true" forKey:@"HttpOnly"];

    NSHTTPCookie *cookie = [NSHTTPCookie cookieWithProperties:cookieProperties];
    [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
    
    //转成header
    NSMutableString *header = [NSMutableString string];
    [header appendString:[NSString stringWithFormat:@"token=%@;",token]];
    [header appendString:[NSString stringWithFormat:@"domain=%@;",domain_final]];
    [header appendString:[NSString stringWithFormat:@"path=%@;",path]];
    
    _cookieDictionary = @{
        @"header":header,
        @"cookie":cookie,
        @"domain":domain_final,
        @"token":token,
        @"documentCookie":[NSString stringWithFormat:@"document.cookie='%@';",header],
    };
}



- (void)dealloc {
//    [_webView removeObserver:self forKeyPath:@"estimatedProgress"];
}


@end
