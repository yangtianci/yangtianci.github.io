//
//  BaseNavigationController.h
//  NengGo
//
//  Created by 杨天赐 on 2018/10/31.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseNavigationController : UINavigationController

@end

NS_ASSUME_NONNULL_END
