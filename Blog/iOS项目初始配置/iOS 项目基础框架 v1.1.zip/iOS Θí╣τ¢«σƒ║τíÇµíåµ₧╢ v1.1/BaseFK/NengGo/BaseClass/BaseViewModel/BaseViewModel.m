//
//  BaseViewModel.m
//  CommonFK
//
//  Created by mac on 2018/10/25.
//  Copyright © 2018年 yangtianci. All rights reserved.
//

#import "BaseViewModel.h"

@interface BaseViewModel()

@end

static AFHTTPSessionManager *manager;

@implementation BaseViewModel


#pragma mark ============================================== 页面逻辑

/**
 
 请求流程
 
 BaseViewModel 抽象类负责生成 AFN 单例, 以及各种基本请求函数的调用
 实例 ViewModel 根据不同页面封装各自页面函数, 主要是数据处理部分, 实际网络请求函数调用继承的函数
 
 * 抽象类函数可以根据使用情况不同进行添加
 * TransformURLWithPath 函数负责 url 的拼接, info 为空, 使用默认宏拼接, 需要自定义设置时添加 info 数据
 
 */

#pragma mark ================================ URL 拼接函数 ===> 需要修改个别接口路径都改这里

-(NSString*)TransformURLWithPath:(NSString*)path Info:(id)info{
    
    //根据 info 中的内容决定是采用正常 url 还是需要特殊定义
    
    if (info == nil) {
        return [NSString stringWithFormat:@"%@%@%@%@",ProjectProtocol,DominName,Prot, path];
    }else{
        
        NSString *state = info[@"state"];
        
        if ([state isEqualToString:@"1"]) {
            // 替换 DominName 并返回
            return nil;
        }else{
            // balabala
            return path;
        }
    }
    return nil;
}

#pragma mark ================================ 参数签名, 加密函数, 添加公共函数

// 公共参数拼接 & 加密 & 签名函数, 根据 info 字段决定是否进行拼接和加密
-(NSDictionary*)SecuryMethodWithPara:(NSDictionary*)dict{
    
    return nil;
}

#pragma mark ============================================== 网络请求函数


#pragma mark ================================ GET
-(void)GetData_WithPara:(NSDictionary*)para Info:(id)info Path:(NSString*)path Success:(void(^)(NSDictionary *dict, id info))success Fail:(void(^)(NSURLSessionDataTask *task, id info))fail{
    
//    NSLog(@"get");
    
    NSString *url = [self TransformURLWithPath:path Info:info];
    
    manager = [BaseViewModel shareManager];
    
    [manager GET:url parameters:para progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(responseObject, task);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        fail(task, error);
    }];
    
}

#pragma mark ================================ POST
-(void)PostData_WithPara:(NSDictionary*)para Info:(id)info Path:(NSString*)path Success:(void(^)(NSDictionary *dict, id info))success Fail:(void(^)(NSURLSessionDataTask *task, id info))fail{
    
//    NSLog(@"POST");
    
    NSString *url = [self TransformURLWithPath:path Info:info];
    
    manager = [BaseViewModel shareManager];
    
    [manager POST:url parameters:para progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(responseObject, task);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        fail(task, error);
    }];
    
}



#pragma mark ================================ UPLOAD >>> 一般上传
-(void)UpdateData_Normal_WithPara:(NSDictionary*)para Info:(id)info Path:(NSString*)path Data:(NSData*)data Progress:(void(^)(NSProgress *objcProgress, CGFloat floatProgress))progress Success:(void(^)(id responseObjec, id info))success Fail:(void(^)(NSError *error, id info))fail{
    
    NSLog(@"上传数据");
    
    NSString *url = [self TransformURLWithPath:path Info:info];
    
    manager = [BaseViewModel shareManager];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    NSData *uploaddata;
    if (data) {
        uploaddata = data;
    }else{
        if (path) {
            uploaddata = [NSData dataWithContentsOfFile:path];
        }else{
            fail(nil,@"文件路径为空, 且数据为空");
            return;
        }
    }
    
    [manager uploadTaskWithRequest:request fromData:uploaddata progress:^(NSProgress * _Nonnull uploadProgress) {
        if (progress) {
            CGFloat floatProgress = 1.0 * uploadProgress.completedUnitCount / uploadProgress.totalUnitCount;
            progress(uploadProgress, floatProgress);
        }
    } completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        if (!error) {
            success(responseObject, response);
        }else{
            fail(error, response);
        }
    }];
}



#pragma mark ================================ 其他待添加自定义函数

/**
 
 待添加类型
 * 顺序上传文件, dispatch 结合 upload 函数实现
 
 */



#pragma mark ================================ 初始化 AFN 的网络请求类

+(AFHTTPSessionManager*)shareManager{
    static dispatch_once_t onceToken; dispatch_once(&onceToken, ^{
        // 初始化请求管理类
        manager = [AFHTTPSessionManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        // // 设置30秒超时 - 取消请求
        manager.requestSerializer.timeoutInterval = 30.0;
        // // 编码 //
        manager.requestSerializer.stringEncoding = NSUTF8StringEncoding;
        // // 缓存策略 //
        manager.requestSerializer.cachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
        manager.responseSerializer = [AFJSONResponseSerializer serializer];
        // 支持内容格式
//        manager.responseSerializer.acceptableContentTypes=[NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"application/octet-stream",@"multipart/form-data",@"text/plain", nil];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        
    });
    
    return manager;
}

// 其他请求方法待补充

// websocket 待补充



@end
