//
//  BaseViewController.m
//  NengGo
//
//  Created by 范同欢 on 2018/10/30.
//  Copyright © 2018年 tidoo. All rights reserved.
//

#import "BaseViewController.h"

#import "BaseVCEmptyView.h"

@interface BaseViewController ()

@property (strong, nonatomic) BaseVCEmptyView *emptyView;

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}





#pragma mark ============================================== 基类页面逻辑


#pragma mark ================= 跳转至指定页面

-(void)PopToIndexVC:(NSInteger)index{
    
    NSArray *VCArr = self.navigationController.childViewControllers;
    
    if (VCArr.count < index) {
        
    }else if (self.navigationController == nil){
        
    }else{
        UIViewController *vc = VCArr[index];
        [self.navigationController popToViewController:vc animated:YES];
    }
    
}

#pragma mark ================= 空白页占位图

-(void)emptyLoggle{
    
    if (self.emptyView) {
        //隐藏
        [self.emptyView removeFromSuperview];
        self.emptyView = nil;
    }else{
        //展示
        [self.view addSubview:self.emptyView];
        [self.view bringSubviewToFront:self.emptyView];
    }
}

-(BaseVCEmptyView *)emptyView{
    if (!_emptyView) {
        _emptyView = [BaseVCEmptyView shareManager];
    }
    return _emptyView;
}


#pragma mark ================= 加载菊花

- (void)loadingViewInitWithTop:(CGFloat)top {
    if (self.loading) {
        [self.loading mas_updateConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(top);
        }];
    } else {
        self.loading = [[TDLoadingView alloc] init];
        [self.view addSubview:self.loading];
        [self.loading mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(top);
            make.right.left.bottom.mas_equalTo(0);
        }];
    }
}

#pragma mark 返回上一层控制器
- (void)backLastView {
    //如果是最底层的控制器，点击返回则回到首页选择界面
    NSArray *viewControllers = self.navigationController.viewControllers;
    if (viewControllers.count == 1) {
        return;
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)dealloc {
    //获取当前类下的全部子类
    NSArray *arrayChildClass = [self findAllOf:[self class]];
    NSString *name = [NSString stringWithCString:object_getClassName([arrayChildClass lastObject]) encoding:NSUTF8StringEncoding];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    DLog(@"==========%@ 已释放============", name);
}

#pragma mark 获取当前控制器下的子类
- (NSArray *)findAllOf:(Class)defaultClass {
    int count = objc_getClassList(NULL, 0);
    if (count <= 0) {
        return [NSArray arrayWithObject:defaultClass];
    }
    
    NSMutableArray *output = [NSMutableArray arrayWithObject:defaultClass];
    Class *classes = (Class *) malloc(sizeof(Class) * count);
    objc_getClassList(classes, count);
    for (int i = 0; i < count; ++i) {
        if (defaultClass == class_getSuperclass(classes[i])) {//子类
            [output addObject:classes[i]];
        }
    }
    free(classes);
    return [NSArray arrayWithArray:output];
}

@end
