//
//  UITextField+QBXCustomField.m
//  QianBuXian_V2
//
//  Created by YangTianCi on 2017/10/11.
//  Copyright © 2017年 qbx. All rights reserved.
//

#import "UITextField+QBXCustomField.h"

@implementation UITextField (QBXCustomField)

//regist
-(void)registButtonMethodWithSender:(UIButton*)sender{
    [self resignFirstResponder];
}

//设置为安全键盘
-(void)custom_SafeAccessView{
    
    //safeView
    UIView *safeView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 45)];
    safeView.backgroundColor = [UIColor whiteColor];
    
    //lineView
    //lineView
    UIView *lineView = [[UIView alloc]init];
    [safeView addSubview:lineView];
    lineView.backgroundColor = [UIColor lightGrayColor];
    lineView.frame = CGRectMake(0, 0, safeView.frame.size.width, 1);
    
    //Label
    UILabel *textLabel = [[UILabel alloc]init];
    [safeView addSubview:textLabel];
    
    textLabel.font = [UIFont systemFontOfSize:12];
    textLabel.textColor = [UIColor lightGrayColor];
    textLabel.textAlignment = NSTextAlignmentCenter;
    textLabel.numberOfLines = 1;
    textLabel.text = @"钱不闲安全键盘";
    [textLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(safeView.mas_centerX);
        make.centerY.mas_equalTo(safeView.mas_centerY);
    }];
    
    //img图片
    UIImageView *imgV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"icon_anquan"]];
    [safeView addSubview:imgV];
    imgV.backgroundColor = [UIColor clearColor];
    [imgV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(safeView.mas_centerY);
        make.right.mas_equalTo(textLabel.mas_left).with.offset(-7);
    }];
    
    //regist按钮
    //--必须设置--
    UIButton *registButton = [[UIButton alloc]init];
    [safeView addSubview:registButton];
    //--基本设置--<##>
    [registButton setTitle:@"完成" forState:UIControlStateNormal];
    [registButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    registButton.titleLabel.font = [UIFont systemFontOfSize:16];
    
    [registButton addTarget:self action:@selector(registButtonMethodWithSender:) forControlEvents:UIControlEventTouchUpInside];
    
    [registButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(safeView.mas_centerY);
        make.right.mas_equalTo(safeView.mas_right).with.offset(-15);
    }];

    //设置
    self.inputAccessoryView = safeView;
    
}


//设为只有返回的键盘
-(void)custom_BackAccessView{
    
    //safeView
    UIView *safeView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 50)];
    safeView.backgroundColor = [UIColor whiteColor];
    
    //lineView
    //lineView
    UIView *lineView = [[UIView alloc]init];
    [safeView addSubview:lineView];
    lineView.backgroundColor = [UIColor lightGrayColor];
    lineView.frame = CGRectMake(0, 0, safeView.frame.size.width, 1);
 
    //regist按钮
    //--必须设置--
    UIButton *registButton = [[UIButton alloc]init];
    [safeView addSubview:registButton];
    //--基本设置--<##>
    [registButton setTitle:@"完成" forState:UIControlStateNormal];
    [registButton setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    registButton.titleLabel.font = [UIFont systemFontOfSize:18];
    
    [registButton addTarget:self action:@selector(registButtonMethodWithSender:) forControlEvents:UIControlEventTouchUpInside];
    
    [registButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(safeView.mas_centerY);
        make.right.mas_equalTo(safeView.mas_right).with.offset(-15);
    }];
    
    safeView.tintColor = [UIColor redColor];
    
    //设置
    self.inputAccessoryView = safeView;
    
    // 因为暂时不需要完成按钮, 因此先不设置
//    self.inputAccessoryView = nil;
}





@end
