//
//  UIViewController+TDCategory.h
//  NengGo
//
//  Created by 范同欢 on 2018/10/31.
//  Copyright © 2018年 tidoo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (TDCategory)

/**
 *  触摸自动隐藏键盘
 */
- (void)tdTapDismissKeyboard;

@end

NS_ASSUME_NONNULL_END
