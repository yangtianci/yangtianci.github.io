//
//  TDLoadingView.h
//  NengGo
//
//  Created by 范同欢 on 2018/10/30.
//  Copyright © 2018年 tidoo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TDLoadingView : UIView

- (void)loadingShow;
- (void)loadingHidden;

@end

NS_ASSUME_NONNULL_END
