//
//  TDCommon.h
//  NengGo
//
//  Created by 范同欢 on 2018/10/30.
//  Copyright © 2018年 tidoo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#pragma mark -------------- 空判断 ---------------
//判断为空
static inline BOOL TDIsEmpty(id _Nullable objcet) {
    return objcet == nil || [objcet isEqual:[NSNull null]] || ([objcet respondsToSelector:@selector(length)] && [(NSData *)objcet length] == 0) || ([objcet respondsToSelector:@selector(count)] && [(NSArray *)objcet count] == 0);
}
//判断不为空
static inline BOOL TDIsNoEmpty(id _Nullable objct) {
    return !TDIsEmpty(objct);
}

#pragma mark ------------- 获取当前的视图 tabbar nav ---------------

UIKIT_STATIC_INLINE UIViewController * _Nullable TDCurrentViewController() {
    UIViewController *topViewController = [[UIApplication sharedApplication].keyWindow rootViewController];
    if ([topViewController isKindOfClass:[UITabBarController class]]) {
        topViewController = ((UITabBarController *)topViewController).selectedViewController;
    }
    if ([topViewController presentedViewController]) {
        topViewController = [topViewController presentedViewController];
    }
    if ([topViewController isKindOfClass:[UINavigationController class]] && [(UINavigationController *)topViewController topViewController]) {
        return [(UINavigationController*)topViewController topViewController];
    }
    return topViewController;
}

UIKIT_STATIC_INLINE UINavigationController * _Nullable TDCurrentNavigationController() {
    return TDCurrentViewController().navigationController;
}

UIKIT_STATIC_INLINE UITabBarController * _Nullable TDCurrentTabBarController() {
    UIViewController *topViewController = [[UIApplication sharedApplication].keyWindow rootViewController];
    if ([topViewController isKindOfClass:[UITabBarController class]]) {
        return (UITabBarController *)topViewController;
    }
    return nil;
}


@interface TDCommon : NSObject

#pragma mark ------ 默认占位图 ------
//占位图
+ (UIImage * _Nonnull)placeholderImage;
//占位头像
+ (UIImage * _Nonnull)placeholderAvatar;

#pragma mark ------ 前后台判断 ------
//程序是否在后台
+ (BOOL)runningInBackground;
//程序是否在前台
+ (BOOL)runningInForeground;

@end

NS_ASSUME_NONNULL_END
