//
//  GuideController.m
//  NengGo
//
//  Created by 杨天赐 on 2018/11/2.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import "GuideController.h"

#define kScreenHeight_Rate ([[UIScreen mainScreen] bounds].size.height)/667.0

@interface GuideController ()<UIScrollViewDelegate>

@property (nonatomic,strong) UIScrollView *ScrollView;

@property (nonatomic,strong) NSMutableArray *ImageViewArr;

@property (nonatomic,strong) NSMutableArray *ImgArr;

@property (nonatomic,strong) UIButton *InterButton;

@property (nonatomic, strong) UIPageControl *pageControl; // 分段控制器




@end


@implementation GuideController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self ConfigurationUI];
    
    
}

-(void)ConfigurationUI{
    
    self.ImageViewArr = [NSMutableArray array];
    self.ImgArr = [NSMutableArray array];
    
    for (int i = 1; i < 5; i++) {
        
//        if(ISIPHONEX){
        
//            UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"v%zd.jpg",i]];
//            [self.ImgArr addObject:image];
        
//        }else{
            UIImage *image = [UIScreen mainScreen].bounds.size.height == 480?[UIImage imageNamed:[NSString stringWithFormat:@"480-%zd",i]]:[UIImage imageNamed:[NSString stringWithFormat:@"0%zd",i]];
            [self.ImgArr addObject:image];
//        }
        
    }
    
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    [self.view addSubview:scrollView];
    self.ScrollView = scrollView;
    scrollView.backgroundColor = [UIColor whiteColor];
    scrollView.pagingEnabled = YES;
    
    scrollView.delegate = self;
    
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    
    self.ScrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width * self.ImgArr.count, [UIScreen mainScreen].bounds.size.height);
    self.ScrollView.bounces = NO;
    
    //创建图片框
    for (int i = 0; i < self.ImgArr.count; i ++) {
        
        UIImageView *imgV = [[UIImageView alloc]initWithFrame:CGRectMake(i * [UIScreen mainScreen].bounds.size.width, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
        [self.ScrollView addSubview:imgV];
        imgV.backgroundColor = [UIColor brownColor];
        imgV.image = self.ImgArr[i];
        
        
        [self.ImageViewArr addObject:imgV];
    }
    
    // 创建pageControl;
    self.pageControl = [[UIPageControl alloc] init];
    self.pageControl.currentPageIndicatorTintColor = HexColor(0xFA7D26, 1.0);
    self.pageControl.pageIndicatorTintColor = HexColor(0xF0F0F0, 1.0);
    self.pageControl.numberOfPages = self.ImgArr.count;
    self.pageControl.currentPage = 0;
    [self.view addSubview:self.pageControl];
    [self.view bringSubviewToFront:self.pageControl];
    [self.pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(100);
        make.bottom.equalTo(self.view).with.offset(-50*kScreenHeight_Rate);
        make.centerX.equalTo(self.view);
        make.height.mas_equalTo(20);
    }];
    
    //--必须设置-- btn
    CGRect customRect;
//    if(TDIS_IPHONE_X){
//
//        customRect = CGRectMake( kScreenWidth * (self.ImgArr.count - 1)+(kScreenWidth-180)/2.0 , [UIScreen mainScreen].bounds.size.height-96*kScreenHeight_Rate-50*kScreenHeight_Rate-10, 180, 50*kScreenHeight_Rate-10);
//    }else{
        customRect = CGRectMake( [UIScreen mainScreen].bounds.size.width * (self.ImgArr.count - 1)+([UIScreen mainScreen].bounds.size.width-210)/2.0 , [UIScreen mainScreen].bounds.size.height-96*kScreenHeight_Rate-50*kScreenHeight_Rate, 210, 50*kScreenHeight_Rate);
//    }
    
    
    UIButton *customButton = [[UIButton alloc]initWithFrame:customRect];
    [self.ScrollView addSubview:customButton];
    //--基本设置--
    [customButton setTitle:@"立即体验" forState:UIControlStateNormal];
    [customButton setTitleColor:HexColor(0xFF8A00, 1.0) forState:UIControlStateNormal];
    customButton.layer.borderColor = HexColor(0xFF8A00, 1.0).CGColor;
    customButton.layer.borderWidth = 1;
    self.InterButton = customButton;
    [self.InterButton addTarget:self action:@selector(TransformRootControllerWithButton:) forControlEvents:UIControlEventTouchUpInside];
    
}

-(void)TransformRootControllerWithButton:(UIButton*)sender{
    
    UIImageView *imgV = self.ImageViewArr.lastObject;
    
    //    [imgV.layer addAnimation:[self AddAnimation] forKey:nil];
    [UIView animateWithDuration:0.25 animations:^{
        
        imgV.alpha = 0.2;
        imgV.transform = CGAffineTransformMakeScale(1.5, 1.5);
    } completion:^(BOOL finished) {
        
        // 发送通知
        
//        [[NSNotificationCenter defaultCenter]postNotificationName:Notic_AppDelegateChangeWindowToMainPage object:nil];
    }];
    
}



//-(CAAnimationGroup*)AddAnimation{
//
//    CABasicAnimation *opacityAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
//
//    opacityAnimation.fromValue = [NSNumber numberWithFloat:1.0];
//
//    opacityAnimation.toValue = [NSNumber numberWithFloat:0.2];
//
//    opacityAnimation.duration = 0.25f;
//
//    opacityAnimation.repeatCount = 1;
//
//
//    CABasicAnimation * animation2 = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
//
//    animation2.fromValue = [NSNumber numberWithDouble:1];
//
//    animation2.toValue = [NSNumber numberWithDouble:5];
//
//    animation2.duration= 0.25;
//
//    animation2.repeatCount= 1;  //"forever"
//
//    CAAnimationGroup *group = [[CAAnimationGroup alloc]init];
//
//    group.animations = @[opacityAnimation, animation2];
//
//    group.duration = 0.25;
//
//    return group;
//
//}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    NSInteger page = scrollView.contentOffset.x/[UIScreen mainScreen].bounds.size.width;
    self.pageControl.currentPage = page;
    if (page == self.ImgArr.count-1) { // 最后一个
        self.pageControl.hidden = YES;
        self.InterButton.hidden = NO;
    }else{
        self.pageControl.hidden = NO;
        self.InterButton.hidden = YES;
    }
}



@end
