//
//  NetWorkManager.h
//  NengGo
//
//  Created by 杨天赐 on 2018/11/2.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


//网络状态值
typedef NS_ENUM(NSUInteger, NetStatus) {
    NetStatusNotMoniter       = -2,   //未开始监测
    NetStatusUnknown          = -1,   //未知
    NetStatusNotReachable     = 0,    //无网络
    NetStatusCellular         = 1,    //蜂窝
    NetStatusWiFi             = 2,    //WiFi
};




@interface NetWorkManager : NSObject

//网络状态
@property (assign, nonatomic) NetStatus netStatus;

//1.0 监测网络状态
- (void)moniterNetStatus:(void(^)(NetStatus netStatus))netStautsBlock;

@end

NS_ASSUME_NONNULL_END
