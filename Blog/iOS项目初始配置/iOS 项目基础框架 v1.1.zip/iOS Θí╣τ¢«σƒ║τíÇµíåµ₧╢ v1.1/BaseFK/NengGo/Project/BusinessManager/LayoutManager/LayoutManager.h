//
//  LayoutManager.h
//  NengGo
//
//  Created by 杨天赐 on 2018/11/2.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LayoutManager : NSObject

/**
 添加一些需要进行自定义化颜色设置的函数
 */



@end

NS_ASSUME_NONNULL_END
