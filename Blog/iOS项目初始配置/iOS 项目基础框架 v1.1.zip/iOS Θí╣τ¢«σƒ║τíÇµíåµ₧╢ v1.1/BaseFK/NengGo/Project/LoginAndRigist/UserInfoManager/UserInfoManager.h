//
//  UserInfoManager.h
//  NengGo
//
//  Created by 杨天赐 on 2018/11/2.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "BaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface UserInfoManager : BaseModel

#pragma mark ================= 用户信息属性

@property (nonatomic, copy) NSString *message_Id;

+(id)sharedInstance;

#pragma mark ================= 退出清除信息

+ (void)clearInfoParameter;


#pragma mark ================= 归档接档

+(void)UserInfoEnCode;

+(void)UserInfoUnEnCode;


@end

NS_ASSUME_NONNULL_END
