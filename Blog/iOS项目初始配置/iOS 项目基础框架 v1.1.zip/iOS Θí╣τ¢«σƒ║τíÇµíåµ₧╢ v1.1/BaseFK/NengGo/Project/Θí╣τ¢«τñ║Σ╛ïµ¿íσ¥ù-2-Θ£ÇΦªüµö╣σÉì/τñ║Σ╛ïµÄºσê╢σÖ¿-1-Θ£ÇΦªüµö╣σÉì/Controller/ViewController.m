//
//  ViewController.m
//  NengGo
//
//  Created by 杨天赐 on 2018/10/29.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
