//
//  ColorSizeStringValue.h
//  CommonFK
//
//  Created by mac on 2018/10/25.
//  Copyright © 2018年 yangtianci. All rights reserved.
//

#ifndef ColorSizeStringValue_h
#define ColorSizeStringValue_h



//定义常用颜色, 尺寸, 布局需要数据, 字符串, 常用 value ( during... )


#pragma mark ------------ 设置圆角和加边框 ------------

//View 圆角
#define TDViewRadius(View, Radius)\
\
[View.layer setCornerRadius:(Radius)];\
[View.layer setMasksToBounds:YES]

//View 圆角和加边框
#define TDViewBorderRadius(View, Radius, Width, Color)\
\
[View.layer setCornerRadius:(Radius)];\
[View.layer setMasksToBounds:YES];\
[View.layer setBorderWidth:(Width)];\
[View.layer setBorderColor:[Color CGColor]]


#pragma mark ------------------------------ 屏幕尺寸及适配 -----------------------------------

#pragma mark ------------ 获取屏幕宽高 ------------

#define TDScreenWidth   [[UIScreen mainScreen] bounds].size.width
#define TDScreenHeight  [[UIScreen mainScreen] bounds].size.height
#define TDScreenBounds  [UIScreen mainScreen].bounds


#pragma mark ------------ 屏幕适配 ------------

//状态栏及nav的高度
#define TDSTATUS_BAR_HEIGHT  (TDIS_IPHONE_X_SERIES ? 44.0 : 20.0)
#define TDNAV_BAR_HEIGHT     44.0f
#define TDTOP_HEIGHT         (TDSTATUS_BAR_HEIGHT + TDNAV_BAR_HEIGHT)

//tabbar的高度
#define TDTAB_BAR_BOTTOM     (TDIS_IPHONE_X_SERIES ? 34.0 : 0)
#define TDTAB_BAR_HEIGHT     49.0f
#define TDBOTTOM_HEIGHT      (TDTAB_BAR_HEIGHT + TDTAB_BAR_BOTTOM)

//以iPhone6系列为基准比例适配
//width ratio 按宽度适配
#define TDWR(width)     (width)*(TDScreenWidth/375.0f)
//height ratio 按高度适配
#define TDHR(height)    (height)*(TDScreenHeight/667.0f)


#pragma mark ------------ 各机型尺寸判断 ------------

//判断是否是ipad
#define TDIS_IPAD ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
//判断iPhone4系列
#define TDIS_IPHONE_4 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 960), [[UIScreen mainScreen] currentMode].size) && !TDIS_IPAD : NO)
//判断iPhone5系列
#define TDIS_IPHONE_5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) && !TDIS_IPAD : NO)
//判断iPhone6系列
#define TDIS_IPHONE_6 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size) && !TDIS_IPAD : NO)
//判断iphone6+系列
#define TDIS_IPHONE_6_Plus ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) && !TDIS_IPAD : NO)
//判断iPhoneX
#define TDIS_IPHONE_X ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) && !TDIS_IPAD : NO)
//判断iPHoneXr
#define TDIS_IPHONE_Xr ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size) && !TDIS_IPAD : NO)
//判断iPhoneXs
#define TDIS_IPHONE_Xs ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) && !TDIS_IPAD : NO)
//判断iPhoneXs Max
#define TDIS_IPHONE_Xs_Max ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size) && !TDIS_IPAD : NO)

//判断是否是刘海屏系列
#define TDIS_IPHONE_X_SERIES (TDIS_IPHONE_X == YES || TDIS_IPHONE_Xr == YES || TDIS_IPHONE_Xs == YES || TDIS_IPHONE_Xs_Max == YES)


#pragma mark --------------------------------- 颜色 -------------------------------------

//16位颜色 0x000000
#define TDCOLOR_RGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16)) / 255.0 green:((float)((rgbValue & 0xFF00) >> 8)) / 255.0 blue:((float)(rgbValue & 0xFF)) / 255.0 alpha:1]
//16位颜色+颜色透明度 0x000000, 0.5
#define TDCOLOR_RGBA(rgbValue, a) [UIColor colorWithRed:((float)(((rgbValue) & 0xFF0000) >> 16))/255.0 green:((float)(((rgbValue) & 0xFF00)>>8))/255.0 blue: ((float)((rgbValue) & 0xFF))/255.0 alpha:(a)]
//随机色生成
#define TDRandomColor [UIColor colorWithRed:(arc4random_uniform(256)/255.0)/255.0f green:(arc4random_uniform(256)/255.0)/255.0f blue:(arc4random_uniform(256)/255.0)/255.0f alpha:1]

//16进制颜色
#define HexColor(hexValue , Alpha) [UIColor colorWithRed:((float)((hexValue & 0xFF0000) >> 16)) / 255.0 green:((float)((hexValue & 0xFF00) >> 8)) / 255.0 blue:((float)(hexValue & 0xFF)) / 255.0 alpha:Alpha]

#pragma mark --------------------------------- 字体 -------------------------------------

//系统字体大小适配
#define TDFONT_SYSTEM(fontsize)         [UIFont systemFontOfSize:TDWR(fontsize)]
//系统加粗字体大小适配
#define TDFONT_BOLDSYSTEM(fontsize)     [UIFont boldSystemFontOfSize:TDWR(fontsize)]
//系统字体大小及名称适配
#define TDFONT_NAME(fontsize, name)     [UIFont fontWithName:name size:TDWR(fontsize)]

#pragma mark ------------ 弱引用 ------------

#define TDWeakSelf(weakSelf)    __weak __typeof(&*self)weakSelf = self;


#pragma mark -------------- 打印日志 ---------------

//DEBUG  模式下打印日志,当前行
#ifdef DEBUG
#define DLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
#define DLog(...)
#endif

//打印当前方法名
#define TDITTDPRINTMETHODNAME() ITTDPRINT(@"%s", __PRETTY_FUNCTION__)


#pragma mark ------------ 发送(接受,取消)通知 ------------

//发送通知
#define NSNotificationCenterPost(key) [[NSNotificationCenter defaultCenter] postNotificationName:key object:nil];
#define NSNotificationCenterPostWithObject(key,NObject) [[NSNotificationCenter defaultCenter] postNotificationName:key object:NObject];
//接受通知
#define NSNotificationCenterAddObserver(key, function) [[NSNotificationCenter defaultCenter] addObserver:self selector:NSSelectorFromString(function) name:key object:nil];
//取消通知
#define NSNotificationCenterCanceledAll [[NSNotificationCenter defaultCenter] removeObserver:self];


#pragma mark ------------ 单例化一个类 ------------

//单例化一个类
#define TDSINGLETON_FOR_HEADER(className) \
\
+ (className *)shared##className;

#define TDSINGLETON_FOR_CLASS(className) \
\
+ (className *)shared##className { \
static className *shared##className = nil; \
static dispatch_once_t onceToken; \
dispatch_once(&onceToken, ^{ \
shared##className = [[self alloc] init]; \
}); \
return shared##className; \
}

#endif /* ColorSizeStringValue_h */
