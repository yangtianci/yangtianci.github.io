//
//  BaseModel.m
//  CommonFK
//
//  Created by mac on 2018/10/25.
//  Copyright © 2018年 yangtianci. All rights reserved.
//

#import "BaseModel.h"

@interface BaseModel ()<NSCoding>



@end

@implementation BaseModel

#pragma mark ================================== 基础函数

-(instancetype)initWithDict:(NSDictionary*)dict{
    
    if (self = [super init]) {
        
        [self setValuesForKeysWithDictionary:dict];
        
    }
    return self;
}


-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    NSLog(@"%@ 字段未设置属性",key);
}

          
#pragma mark ================================== 进阶函数

-(void)setValuesForKeysWithDictionary:(NSDictionary<NSString *,id> *)keyedValues{
    
    // runtime 检查空字段, 转换类型, 转换 id 字段名称
    
    [keyedValues enumerateKeysAndObjectsUsingBlock:^(NSString * _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:[NSNull class]]) {
            obj = @"~"; // 后台返回空类型
        }
        if ([obj isKindOfClass:[NSNumber class]]) {
            // 后台返回number类型
            obj = [NSString stringWithFormat:@"%@",obj]; 
        }
//        if ([obj isKindOfClass:[NSDictionary class]]) {
//            obj = [obj mutableCopy];
//        }
//        if ([obj isKindOfClass:[NSArray class]]) {
//            obj = [obj mutableCopy];
//        }
        [self setValue:obj forKey:key];
    }];
}

// 归档函数...MJ 宏即可
          
-(void)encodeWithCoder:(NSCoder *)aCoder{
//    <#//Code#>
}


-(instancetype)initWithCoder:(NSCoder *)aDecoder{
//    <#//Code#>
    return nil;
}

          
          
          


@end
