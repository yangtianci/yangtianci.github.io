//
//  BaseVCEmptyView.h
//  NengGo
//
//  Created by 杨天赐 on 2018/11/2.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseVCEmptyView : UIView

// 此界面三种使用方式
/**
 
 1. 调用默认界面
 2. 调用默认界面并修改图片以及文字说明
 3. 自定义占位图片 -> 此功能未添加
 
 */

+(instancetype)shareManager;

-(void)customConfgigUIWithImgName:(NSString*)imgName LabelTitle:(NSString*)labStr;


@end

NS_ASSUME_NONNULL_END
