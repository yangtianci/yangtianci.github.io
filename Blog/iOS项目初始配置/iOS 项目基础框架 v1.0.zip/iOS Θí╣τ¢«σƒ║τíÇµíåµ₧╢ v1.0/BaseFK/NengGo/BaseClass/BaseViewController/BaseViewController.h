//
//  BaseViewController.h
//  NengGo
//
//  Created by 范同欢 on 2018/10/30.
//  Copyright © 2018年 tidoo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TDLoadingView.h"

NS_ASSUME_NONNULL_BEGIN

@interface BaseViewController : UIViewController

@property (nonatomic, strong) TDLoadingView *loading;

//调用空白页展位图
-(void)emptyLoggle;


//跳转至指定页面 

-(void)PopToIndexVC:(NSInteger)index;

@end

NS_ASSUME_NONNULL_END
