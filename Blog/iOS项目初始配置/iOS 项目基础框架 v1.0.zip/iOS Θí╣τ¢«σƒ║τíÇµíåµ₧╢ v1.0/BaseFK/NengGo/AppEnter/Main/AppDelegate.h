//
//  AppDelegate.h
//  NengGo
//
//  Created by 杨天赐 on 2018/10/29.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

