//
//  NSArray+Safety.m
//  NengGo
//
//  Created by 范同欢 on 2018/11/2.
//  Copyright © 2018年 tidoo. All rights reserved.
//

#import "NSArray+Safety.h"

@implementation NSArray (Safety)

- (instancetype)safeObjectAtIndex:(NSInteger)index{
    if (self.count > index && index >= 0) {
        return [self objectAtIndex:index];
    }
    DLog(@"数组越界");
    return nil;
}

@end

@implementation NSMutableArray (Safety)

- (void)safeAddObject:(id)anObject {
    if (anObject != nil && ![anObject isKindOfClass:[NSNull class]]) {
        [self addObject:anObject];
    } else {
        DLog(@"数据违法");
    }
}

- (void)safeInsertObject:(id)anObject atIndex:(NSInteger)index {
    if (self.count >= index && index >= 0 && anObject != nil && ![anObject isKindOfClass:[NSNull class]]) {
        [self insertObject:anObject atIndex:index];
    } else {
        DLog(@"数组越界或数据违法");
    }
}

- (void)safeRemoveObjectAtIndex:(NSInteger)index {
    if (self.count > index && index >= 0) {
        [self removeObjectAtIndex:index];
    } else {
        DLog(@"数组越界");
    }
}

- (void)safeRemoveObject:(id)anObject {
    if (anObject != nil && ![anObject isKindOfClass:[NSNull class]]) {
        [self removeObject:anObject];
    } else {
        DLog(@"数据违法");
    }
}

- (void)safeReplaceObjectAtIndex:(NSInteger)index withObject:(id)anObject {
    if (self.count > index && anObject != nil && ![anObject isKindOfClass:[NSNull class]] && index >= 0) {
        [self replaceObjectAtIndex:index withObject:anObject];
    } else {
        DLog(@"数组越界或数据违法");
    }
}

- (void)safeMoveObjectToIndex:(NSInteger)index withObject:(id)anObject
{
    if (![self containsObject:anObject]) {
        DLog(@"safeMoveObjectToIndex, object is not exit");
        return;
    }
    
    NSInteger fromIndex = [self indexOfObject:anObject];
    [self safeMoveObjectFromIndex:fromIndex toIndex:index];
}

- (void)safeMoveObjectFromIndex:(NSInteger)fromIndex toIndex:(NSInteger)toIndex
{
    if (fromIndex < 0 || fromIndex >= self.count ||
        toIndex < 0 || toIndex >= self.count) {
        DLog(@"safeMoveObjectToIndex error");
        return;
    }
    
    id object = [self safeObjectAtIndex:fromIndex];
    if (fromIndex > toIndex) {
        [self safeRemoveObjectAtIndex:fromIndex];
        [self safeInsertObject:object atIndex:toIndex];
    } else if (fromIndex < toIndex){
        [self safeRemoveObjectAtIndex:fromIndex];
        [self safeInsertObject:object atIndex:toIndex-1];
    }
}

@end
