//
//  NSArray+Safety.h
//  NengGo
//
//  Created by 范同欢 on 2018/11/2.
//  Copyright © 2018年 tidoo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSArray <ObjectType> (Safety)

/**
 *  取值(防止数组越界)
 *
 *  @param index 下标
 *  @return nil 或者 id
 */
- (ObjectType)safeObjectAtIndex:(NSInteger)index;

@end

@interface NSMutableArray <ObjectType> (Safety)

/**
 增加元素
 
 @param anObject 增加的元素
 */
- (void)safeAddObject:(ObjectType)anObject;

/**
 插入元素
 
 @param anObject    插入的元素
 @param index       插入的index
 */
- (void)safeInsertObject:(ObjectType)anObject atIndex:(NSInteger)index;

/**
 删除元素
 
 @param index 删除的index
 */
- (void)safeRemoveObjectAtIndex:(NSInteger)index;

/**
 删除元素
 
 @param anObject 删除的元素
 */
- (void)safeRemoveObject:(ObjectType)anObject;;

/**
 替换元素
 
 @param index       被替换元素的index
 @param anObject    新的元素
 */
- (void)safeReplaceObjectAtIndex:(NSInteger)index withObject:(ObjectType)anObject;

/**
 迁移元素
 
 @param index       迁移之后的下标
 @param anObject    数组中的元素
 */
- (void)safeMoveObjectToIndex:(NSInteger)index withObject:(ObjectType)anObject;

/**
 迁移元素
 
 @param fromIndex   迁移之前的下标
 @param toIndex     当 fromIndex > toIndex 时 toIndex 为迁移之后的下标
 当 fromIndex < toIndex 时 toIndex 为迁移之后的下标 + 1
 */
- (void)safeMoveObjectFromIndex:(NSInteger)fromIndex toIndex:(NSInteger)toIndex;

@end

NS_ASSUME_NONNULL_END
