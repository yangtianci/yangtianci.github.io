//
//  UserInfoManager.m
//  NengGo
//
//  Created by 杨天赐 on 2018/11/2.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import "UserInfoManager.h"

@interface UserInfoManager ()<NSCoding>





@end


@implementation UserInfoManager


+(id)sharedInstance{
    static id _sharedObject = nil;
    static dispatch_once_t onceUserInfoToken;
    
    dispatch_once(&onceUserInfoToken, ^{
        _sharedObject = [[self alloc] init];
    });
    
    return _sharedObject;
}



#pragma mark ================= 退出清除信息

+ (void)clearInfoParameter{
    
    //token 是否清空
    
//    [UserInfoManager sharedInstance].message_Id = nil;
    
    [self UserInfoEnCode];
    
}



#pragma mark ================= 归档接档


+(void)UserInfoEnCode{
    
    UserInfoManager *manager = [UserInfoManager sharedInstance];
    NSString *path = [manager PathForLoginInfo];
    
    [NSKeyedArchiver archiveRootObject:manager toFile:path];
    
    //存储此次登录时间
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    formatter.dateFormat = @"yyyy-MM-dd HH-mm-ss";
    NSString *str = [formatter stringFromDate:[NSDate date]];
    
    [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"lastLoginTIme"];
}


+(void)UserInfoUnEnCode{
    
    UserInfoManager *manager = [UserInfoManager sharedInstance];

    NSString *path = [manager PathForLoginInfo];
    UserInfoManager *localManager = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
    manager.message_Id = localManager.message_Id;

    
}

-(NSString *)PathForLoginInfo{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docDir = [paths objectAtIndex:0];
    
    NSString *path = [docDir stringByAppendingPathComponent:@"userLoginInfo"];
    
    return path;
    
}

- (void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:_message_Id forKey:@"message_Id"];
}


- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder{
    _message_Id = [aDecoder decodeObjectForKey:@"message_Id"];
    return self;
    
}



@end
