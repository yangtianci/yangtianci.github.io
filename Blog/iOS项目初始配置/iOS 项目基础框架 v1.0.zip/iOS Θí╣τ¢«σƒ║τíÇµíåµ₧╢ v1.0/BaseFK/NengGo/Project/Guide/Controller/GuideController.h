//
//  GuideController.h
//  NengGo
//
//  Created by 杨天赐 on 2018/11/2.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GuideController : BaseViewController

@end

NS_ASSUME_NONNULL_END
