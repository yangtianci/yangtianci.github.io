//
//  RootTbbarController.m
//  NengGo
//
//  Created by 杨天赐 on 2018/11/2.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import "RootTbbarController.h"

#import "BaseNavigationController.h"

#import "ViewController.h"

@interface RootTbbarController ()<UITabBarControllerDelegate>

@end

@implementation RootTbbarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSArray *itemNormalArr = @[@"icon_shouye",@"icon_chanpin",@"icon_xueyuan",@"icon_wode"];
    
    NSArray *itemSelectArr = @[@"icondick_shouye",@"icondick_chanpin",@"icondick_xueyuan",@"icondick_wode"];
    
    self.delegate = self;
    [self setupChildVc:[[ViewController alloc] init] title:@"首页" image:itemNormalArr[0] selectedImage:itemSelectArr[0]];
//    [self setupChildVc:[[QBXProductsViewController alloc] init] title:@"产品" image:itemNormalArr[1] selectedImage:itemSelectArr[1]];
//    [self setupChildVc:[[QBXMainCollegeController alloc] init] title:@"学院" image:itemNormalArr[2] selectedImage:itemSelectArr[2]];
//    [self setupChildVc:[[QBXMeViewController alloc] init] title:@"我的" image:itemNormalArr[3] selectedImage:itemSelectArr[3]];
    
    self.tabBar.barTintColor = [UIColor whiteColor];
    
    [self hidesBottomBarWhenPushed];
    
    //设置字体
    UITabBarItem *item = [UITabBarItem appearance];
    // 普通状态下的文字属性
    NSMutableDictionary *normalAttrs = [NSMutableDictionary dictionary];
    normalAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:12];
    normalAttrs[NSForegroundColorAttributeName] = [UIColor darkGrayColor];
    [item setTitleTextAttributes:normalAttrs forState:UIControlStateNormal];
    // 选中状态下的文字属性
    NSMutableDictionary *selectedAttrs = [NSMutableDictionary dictionary];
    selectedAttrs[NSForegroundColorAttributeName] = [UIColor redColor];
    [item setTitleTextAttributes:selectedAttrs forState:UIControlStateSelected];
    
}


//设置控制器的属性、标题
- (void)setupChildVc:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{
    
    vc.navigationItem.title = title;
    
    //设置 NavBar
    BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:vc];
    UINavigationBar *bar=nav.navigationBar;
    
    nav.tabBarItem.title = title;
    nav.tabBarItem.image = [[UIImage imageNamed:image]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nav.hidesBottomBarWhenPushed = NO;
    nav.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    bar.backgroundColor = [UIColor whiteColor];
    
    [self addChildViewController:nav];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    NSLog(@"内存溢出");
    
}



@end
