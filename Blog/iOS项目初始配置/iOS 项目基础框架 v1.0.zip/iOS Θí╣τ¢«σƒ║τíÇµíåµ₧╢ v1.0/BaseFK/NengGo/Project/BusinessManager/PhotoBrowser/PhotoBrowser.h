//
//  PhotoBrowser.h
//  CommonFK
//
//  Created by mac on 2018/10/25.
//  Copyright © 2018年 yangtianci. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PhotoBrowser : NSObject

@end
