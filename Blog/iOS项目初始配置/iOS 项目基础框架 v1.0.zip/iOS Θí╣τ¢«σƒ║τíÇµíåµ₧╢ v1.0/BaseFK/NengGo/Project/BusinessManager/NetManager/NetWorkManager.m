//
//  NetWorkManager.m
//  NengGo
//
//  Created by 杨天赐 on 2018/11/2.
//  Copyright © 2018 tidoo. All rights reserved.
//

#import "NetWorkManager.h"

@implementation NetWorkManager

-(void)moniterNetStatus:(void (^)(NetStatus))netStautsBlock{
    
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                self.netStatus = NetStatusUnknown;
                netStautsBlock(NetStatusUnknown);
                break;
            case AFNetworkReachabilityStatusNotReachable:
                self.netStatus = NetStatusNotReachable;
                netStautsBlock(NetStatusNotReachable);
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
                self.netStatus = NetStatusCellular;
                netStautsBlock(NetStatusCellular);
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                self.netStatus = NetStatusWiFi;
                netStautsBlock(NetStatusWiFi);
                break;
        }
        
    }];
    
    [manager startMonitoring];
    
}


@end
