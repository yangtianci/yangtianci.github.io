//
//  YTCDataCollect.h
//  hengLeHui
//
//  Created by 杨天赐 on 2023/3/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YTCDataCollect : NSObject

+ (instancetype)shared;

-(void)InsertDataWithDictionary:(NSDictionary*)dict;

-(void)checkData;

@end

NS_ASSUME_NONNULL_END
