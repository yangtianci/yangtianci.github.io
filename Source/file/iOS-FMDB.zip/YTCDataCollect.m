//
//  YTCDataCollect.m
//  hengLeHui
//
//  Created by 杨天赐 on 2023/3/15.
//

#import "YTCDataCollect.h"

#import <FMDB.h>


#import "HTCFTrackParams.h"

#import "HLHMainDianViewModel.h"

#import "NSDate+htjfAdd.h"

@interface YTCDataCollect()

@property (nonatomic, strong) FMDatabase *collectionDatabase;

@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic, strong) HLHMainDianViewModel *VM;



@end


@implementation YTCDataCollect


/**
 
 15 秒内检查一次, 有数据则上传, 与另一个条件, 200 条则上传一次其实明显冲突了, 至少从逻辑上来说, 是不合理的
 
 甚至还有另一个条件, 进入后台时上传一次
 
 因此, 实际执行的时候, 进入后台以及 200 条限制均不上传
 
 只执行十五秒上传一次
 
 */

-(void)InsertDataWithDictionary:(NSDictionary*)dict{
    
    if ([self.collectionDatabase open]) {
        
        NSString *c_eventId = [NSString stringWithFormat:@"%@",dict[@"eventId"]];
        NSString *c_pageId = [NSString stringWithFormat:@"%@",dict[@"pageId"]];
        
        NSString *extend = @"";
        if([dict.allKeys containsObject:@"extend"]){
            NSDictionary *paradict = dict[@"extend"];
            NSData *data=[NSJSONSerialization dataWithJSONObject:paradict options:NSJSONWritingPrettyPrinted error:nil];
            NSString *jsonStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
            extend = jsonStr;
        }
        
        HTCFTrackParams *param = [HTCFTrackParams share];
        
        NSString *product = @"app_chtfo";
        NSString *manufactory = @"Apple";
        NSString *platform = @"iOS";
        NSString *appVersion = param.v;
        NSString *model = param.mt;
        NSString *osVersion = param.sv;
        NSString *screen = param.ds;
        NSString *logTime = [NSDate getTimeStamp];
        NSString *deviceId = param.uvid;
        NSString *netType = param.nt;
        NSString *carrier = param.mno;
        NSString *pageId = c_pageId;
        NSString *eventId = c_eventId;
        
        if([pageId isEqualToString:@"(null)"] || [eventId isEqualToString:@"(null)"]){
            return;
        }
        
//        NSString *hpm = @"hpm";
//        NSString *channel = @"appstore";
        
        NSString *uid = @"";
        NSString *uidLevel = @"";
        
        NSString *token = [[NSUserDefaults standardUserDefaults] objectForKey:hlh_token];
        if (token && token.length > 0) {
            // 已登录
            uid = [[NSUserDefaults standardUserDefaults] objectForKey:hlh_customerno];
            
            NSString *level = [[NSUserDefaults standardUserDefaults] objectForKey:hlh_customerLevel];
            if(level && level.length > 0 && ![level isEqualToString:@"(null)"]){
                uidLevel = level;
            }
            
        }else{
            // 未登录
        }
        
        BOOL result = [self.collectionDatabase executeUpdate:@"INSERT INTO maidianTable (product,manufactory,platform,appVersion,model,osVersion,screen,logTime,deviceId,netType,carrier,uid,uidLevel,pageId,eventId,extend) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);",product,manufactory,platform,appVersion,model,osVersion,screen,logTime,deviceId,netType,carrier,uid,uidLevel,pageId,eventId,extend];
        
        if (!result) {
            NSLog(@"增加数据失败");
        }else{
            NSLog(@"增加数据成功");
        }
        [self.collectionDatabase close];
    }
}




-(void)checkData{
    
    if ([self.collectionDatabase open]) {
        
        NSString *selectSQL = [NSString stringWithFormat:@"SELECT Count(*) FROM maidianTable"];
        NSInteger count = [self.collectionDatabase intForQuery:selectSQL];
        
//        NSLog([NSString stringWithFormat:@"执行一次, 数据库条目为 %zd",count]);
        
        if(count == 0){
            return;;
        }else if(count > 0){
            [self UploadMethod];
        }
    }
    
}

-(void)UploadMethod{
    
    // 完整数组
//    NSArray *titleArr = @[@"product",@"manufactory",@"platform",@"appVersion",@"model",@"osVersion",@"screen",@"logTime",@"deviceId",@"netType",@"carrier",@"uid",@"uidLevel",@"pageId",@"eventId",@"extend",@"hpm",@"channel"];
    
    NSArray *titleArr = @[@"product",@"manufactory",@"platform",@"appVersion",@"model",@"osVersion",@"screen",@"logTime",@"deviceId",@"netType",@"carrier",@"uid",@"uidLevel",@"pageId",@"eventId",@"extend"];
    
    if ([self.collectionDatabase open]) {
        // 1.执行查询语句
        FMResultSet *resultSet = [self.collectionDatabase executeQuery:@"SELECT * FROM maidianTable"];
        // 2.遍历结果
        
        int i = 0;
        
        // 此处组装数据, 并进行上传操作
        NSMutableDictionary *para = [NSMutableDictionary dictionary];
        [para setValue:@"6a0aa2be46ba72ba07302007de82e9ee" forKey:@"token"];
        
        NSMutableArray *dataArray = [NSMutableArray array];
        
        while ([resultSet next]) {
            NSLog(@"数据库第 %d 条数据",i);
            i++;
            NSMutableDictionary *dataDict = [NSMutableDictionary dictionary];
            for (int j = 0; j < titleArr.count; j++) {
                
                NSString *key = titleArr[j];
                
                NSString *value = [resultSet stringForColumn:key];
                if(value && ![key isEqualToString:@"extend"]){
                    [dataDict setObject:value forKey:key];
                }
//                NSLog(@"%@ = %@",titleArr[j],value);
                
                if([key isEqualToString:@"extend"]){
                    
                }
                
                if( [key isEqualToString:@"extend"]){
                    
                    if(value && value.length > 0){
                        NSData *jsonData = [value dataUsingEncoding:NSUTF8StringEncoding];
                        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                                            options:NSJSONReadingMutableContainers
                                                                              error:nil];
                        [dataDict setObject:dic forKey:key];
                    }else{
                        [dataDict setObject:[NSNull null] forKey:key];
                    }

                }
                
            }
            
            [dataArray addObject:dataDict];
            
        }
        
        [para setObject:dataArray forKey:@"dtos"];
        
        // 上传完毕, 删除所有数据
        
        [self.VM Request_MaidianUploadWithPara:para Success:^(id  _Nonnull response) {
            
            [self ClearDataBase];
            
        } Fail:^(NSString * _Nonnull msg, id  _Nonnull info) {
            
            [self ClearDataBase];
            
        }];
        
        [self.collectionDatabase close];
    }
    
}

-(void)ClearDataBase{

    if([self.collectionDatabase open]){
        NSString *deleteString =  @"delete from maidianTable";

        [self.collectionDatabase executeUpdate:deleteString];
        [self.collectionDatabase close];
    }
    
    
    
}


-(void)initDataBase{
    
    NSString *doc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *fileName = [doc stringByAppendingPathComponent:@"maidianData.sqlite"];
    
    FMDatabase *collectionDatabase = [FMDatabase databaseWithPath:fileName];
    self.collectionDatabase = collectionDatabase;

    if ([self.collectionDatabase open]) {
        BOOL result = [self.collectionDatabase executeUpdate:@"CREATE TABLE IF NOT EXISTS maidianTable (product TEXT,manufactory TEXT,platform TEXT,appVersion TEXT,model TEXT,osVersion TEXT,screen TEXT,logTime int,deviceId TEXT,netType TEXT,carrier TEXT,uid TEXT,uidLevel TEXT,pageId TEXT,eventId TEXT,extend TEXT,hpm TEXT,channel TEXT);"];
        
        if (result) {
            NSLog(@"创表成功");
        } else {
            NSLog(@"创表失败");
        }
        [self.collectionDatabase close];
    }
    
}





-(instancetype)init{
    
    self.VM = [[HLHMainDianViewModel alloc]init];
    
    self.timer = [NSTimer scheduledTimerWithTimeInterval:15 repeats:YES block:^(NSTimer * _Nonnull timer) {
        [self checkData];
    }];
    
    [self.timer fire];
    
    [self initDataBase];
    
    for (int i = 0; i  < 5; i++) {
        [self InsertDataWithDictionary:nil];
    }
    
    return self;
}


+ (instancetype)shared
{
    static YTCDataCollect *_sharedSingleton = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        // 不能再使用 alloc 方法
        // 因为已经重写了 allocWithZone 方法，所以这里要调用父类的分配空间的方法
        _sharedSingleton = [[super allocWithZone:NULL] init];
    });
    return _sharedSingleton;
}



@end
