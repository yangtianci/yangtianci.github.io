//
//  ZSYSingBookDetialWKController.m
//  HengtianOverseas
//
//  Created by 杨天赐 on 2023/3/17.

//

#import "ZSYSingBookDetialWKController.h"

#import "WXApi.h"

#import <WebKit/WebKit.h>

@interface ZSYSingBookDetialWKController ()<WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler>
#pragma mark ================================ UI
@property (strong, nonatomic) WKWebView *webView;
@property (strong, nonatomic) UIProgressView *progressView;

#pragma mark ================================ Important Data
//cookie
@property (copy, nonatomic) NSDictionary *cookieDictionary;
//ssl
@property (strong, nonatomic) NSMutableURLRequest *request;
@property (nonatomic) SSLAuthenticate authenticated;
@property (strong, nonatomic) NSURLConnection *urlConnection;

#pragma mark ================================ Url
@property (copy, nonatomic) NSString *originalUrl;
@property (copy, nonatomic) NSString *loadUrl;

#pragma mark ================================ Custom Para
@end

@implementation ZSYSingBookDetialWKController




- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.view.backgroundColor = [UIColor whiteColor];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = self.dataMd.bookName;
    
    [self configUI];
    [self globalConfig];
    
}

- (void)globalConfig {
    
    //加载 webView;
    [self loadWebView];
    
    //注册 js 方法
    [self registJsMethod];

    
}

#pragma mark ============================================== Custom Logic

// 此处放置 JS 调用函数

#pragma mark ============================================== 自定义 OC - JS 交互

#pragma mark ================================ OC 调用 JS

- (void)callJsWithJSCommand:(NSString*)jsCommand{
    [_webView evaluateJavaScript:jsCommand completionHandler:^(id _Nullable result, NSError * _Nullable error) {
        NSLog(@"%@",error);
    }];
}

#pragma mark ================================ JS 调用 OC
- (void)registJsMethod{
    WKUserContentController *userContentController = self.webView.configuration.userContentController;
    
    // 此处注册 JS 可调用函数名称
    //产品详情
    [userContentController addScriptMessageHandler:self name:@"callIosMethod"];
}

//js回调  第一种方式
#pragma mark - WKScriptMessageHandler
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    
//    NSLog(@"方法名字：%@ 方法内容：%@",message.name, message.body);
    
    if ([message.name isEqualToString:@"callIosMethod"]){
        [self callIosMethod:message.body];
    }
    
}



#pragma mark ============================================== 自定义交互内容


-(void)callIosMethod:(NSString *)jsString{
    
    // v3.3.5 因为任务模块直接增加埋点数据有问题, 因此, 通过交互传递给 h5 埋点数据
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSString *idx = [NSString stringWithFormat:@"%@",jsString];

        NSInteger number = [idx integerValue];
        
        [self clickedShareViewWithIndex:number];
        
        
    });
    
}



- (void)clickedShareViewWithIndex:(NSInteger)index{
    // index:70:微信，71:朋友圈，72：取消

    NSArray *fileArray = self.dataMd.attachment;
    NSDictionary *shareFileString = fileArray[index];
    
        if ([WXApi isWXAppInstalled]) {
            SendMessageToWXReq *req = [[SendMessageToWXReq alloc] init];
            req.scene = WXSceneSession;
            WXMediaMessage *message = [WXMediaMessage message];
            message.title = [NSString stringWithFormat:@"%@",shareFileString[@"fileName"]];
            message.description = [NSString stringWithFormat:@"%@",shareFileString[@"fileName"]];
            WXWebpageObject *webObj = [WXWebpageObject object];

            webObj.webpageUrl =[NSString stringWithFormat:@"%@",shareFileString[@"filePath"]];
            message.mediaObject = webObj;
            //分享缩略图
            UIImage *shareImage = [UIImage imageNamed:@"shareVideoIcon"];
            message.thumbData = UIImagePNGRepresentation(shareImage);
            req.message = message;
            [WXApi sendReq:req completion:^(BOOL success) {
                NSLog(@"分享成功");
            }];
            
            
        }else{
            [SVProgressHUD showInfoWithStatus:@"您的设备暂未安装微信"];
        }
}


- (void)clickedShareViewWithIndexForHtml:(NSInteger)index{
    // index:70:微信，71:朋友圈，72：取消

    NSArray *fileArray = self.dataMd.attachment;
    NSDictionary *shareFileString = fileArray[index];
    
        if ([WXApi isWXAppInstalled]) {
            SendMessageToWXReq *req = [[SendMessageToWXReq alloc] init];
            req.scene = WXSceneSession;
            WXMediaMessage *message = [WXMediaMessage message];
            message.title = [NSString stringWithFormat:@"%@",shareFileString[@"fileName"]];
            message.description = [NSString stringWithFormat:@"%@",shareFileString[@"fileName"]];
            WXWebpageObject *webObj = [WXWebpageObject object];

            webObj.webpageUrl =[NSString stringWithFormat:@"%@",shareFileString[@"filePath"]];
            message.mediaObject = webObj;
            //分享缩略图
            UIImage *shareImage = [UIImage imageNamed:@"shareVideoIcon"];
            message.thumbData = UIImagePNGRepresentation(shareImage);
            req.message = message;
            [WXApi sendReq:req completion:^(BOOL success) {
                NSLog(@"分享成功");
            }];
            
            
        }else{
            [SVProgressHUD showInfoWithStatus:@"您的设备暂未安装微信"];
        }
}

#pragma mark ============================================== WKWebView Cookie & 代理


//加载html
- (void)loadWebView {

        //加载本地html
    
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"orderDeital" ofType:@"html"];
        
//        NSString *path = [[NSBundle mainBundle]pathForResource:self.loadUrl ofType:nil];
    
    
        _request = [[NSMutableURLRequest alloc]initWithURL:[NSURL fileURLWithPath:filePath]];
        
        [self.webView loadRequest:_request];
    

}

- (void)setConfig {
    WKWebViewConfiguration *config = _webView.configuration;
    WKUserContentController* userContentController = config.userContentController;
    
     WKUserScript *cookieScript = [[WKUserScript alloc]initWithSource:_cookieDictionary[@"documentCookie"] injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:NO];
     [userContentController addUserScript:cookieScript];
    
}

-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    
    
    // 加载完毕, 插入数据
    NSString *jsString = [NSString stringWithFormat:@"window.insertContent('%@')",self.dataMd.content];
    [self.webView evaluateJavaScript:jsString completionHandler:^(id _Nullable, NSError * _Nullable error) {
    }];
    
    // 插入附件数据
    
    for (int i = 0; i < self.dataMd.attachment.count; i++) {
        
        NSDictionary *fileInfo = self.dataMd.attachment[i];
        NSString  *titleString = [NSString stringWithFormat:@"%@",fileInfo[@"fileName"]];
        
        NSString *attJsString = [NSString stringWithFormat:@"window.insertAttachment('%@','%d')",titleString,i];
        [self.webView evaluateJavaScript:attJsString completionHandler:^(id _Nullable, NSError * _Nullable error) {
        }];
        
    }
    
    NSString *widhtString = [NSString stringWithFormat:@"%lfpx",kScreenWidth - 30];
    
    NSString *attJsString = [NSString stringWithFormat:@"window.scaleImage('%@')",widhtString];
    [self.webView evaluateJavaScript:attJsString completionHandler:^(id _Nullable, NSError * _Nullable error) {
    }];
    
    
    
}


#pragma mark - WKNavigationDelegate


// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    
#pragma mark - 后续可能优化
    NSLog(@"开始加载: %@ 授权:%d==%@", [webView.URL absoluteString], _authenticated,[[[webView.URL absoluteString] componentsSeparatedByString:@"/"]lastObject]);
    if (!_authenticated&& [webView.URL.scheme hasPrefix:@"https"]) {
        _authenticated = NO;

        _urlConnection = [[NSURLConnection alloc] initWithRequest:_request delegate:self];

        [_urlConnection start];
    }
    

}


//开始加载时失败
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(nonnull NSError *)error {
    if([error code] == NSURLErrorCancelled){
        return;
    }else{
    }
}

//加载框架失败
- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
}

//拦截请求
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
//    NSString *urlString = [NSString stringWithFormat:@"%@",navigationAction.request.URL.absoluteURL.absoluteString];

        decisionHandler(WKNavigationActionPolicyAllow);
}


//如果不实现这个方法,将允许响应web视图,如果web视图可以表现出来。(在收到响应后，决定是否跳转)
- (void)webView:(WKWebView *)webViecw decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler
{
//    NSHTTPURLResponse *response = (NSHTTPURLResponse *)navigationResponse.response;
//    if (response.statusCode == 200) {
//        //加载成功
//    }else {
//        //加载失败
//    }
#pragma mark - 后续可能优化
    
    //获取cookie 并存到本地
//    if (@available(iOS 11.0, *)) {//iOS11也有这种获取方式，但是我使用的时候iOS11系统可以在response里面直接获取到，只有iOS12获取不到
//        WKHTTPCookieStore *cookieStore = webViecw.configuration.websiteDataStore.httpCookieStore;
//        [cookieStore getAllCookies:^(NSArray* cookies) {
//            for (NSHTTPCookie *cookie in cookies) {
//                [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
//            }
//        }];
//    }else {
//        NSArray *cookies =[NSHTTPCookie cookiesWithResponseHeaderFields:[response allHeaderFields] forURL:response.URL];
//        for (NSHTTPCookie *cookie in cookies) {
//            [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
//        }
//    }
    
    decisionHandler(WKNavigationResponsePolicyAllow);
}

- (void)webView:(WKWebView*)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge*)challenge completionHandler:(void(^)(NSURLSessionAuthChallengeDisposition,NSURLCredential*_Nullable))completionHandler {
    if([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
        NSURLCredential *card = [[NSURLCredential alloc] initWithTrust:challenge.protectionSpace.serverTrust];
        completionHandler(NSURLSessionAuthChallengeUseCredential,card);
    }

}

#pragma mark - WKUIDelegate

/**
 *  web界面中有弹出警告框时调用
 *
 *  @param webView           实现该代理的webview
 *  @param message           警告框中的内容
 *  @param frame             主窗口
 *  @param completionHandler 警告框消失调用
 */
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler
{
#pragma mark - 后续可能优化
    UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertVc addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }]];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertVc animated:YES completion:nil];
    completionHandler();
}

#pragma mark - NSURLConnectionDataDelegate
#pragma mark - 后续可能优化
- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge{
    NSLog(@"WebController 已经得到授权正在请求 NSURLConnection");
    if ([challenge previousFailureCount] == 0){
        _authenticated = kTryAuthenticate;

        NSURLCredential *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];

        [challenge.sender useCredential:credential forAuthenticationChallenge:challenge];

    } else{
        [[challenge sender] cancelAuthenticationChallenge:challenge];
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    NSLog(@"WebController 已经收到响应并通过了 NSURLConnection请求");

    _authenticated = kTryAuthenticate;
    [self.webView loadRequest:_request];
    [_urlConnection cancel];
}

- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace{

    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}


- (void)configUI {
    [self.view addSubview:self.webView];
    self.webView.frame = CGRectMake(0, 0, kScreenWidth, kScreenHeight - TabbarHeight - TabbarHeight);

    //observe
//    [_webView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:nil];
}





- (WKWebView *)webView {
    if (!_webView) {
        WKWebViewConfiguration *config = [WKWebViewConfiguration new];
        WKUserContentController *userContentController = [WKUserContentController new];
        config.userContentController = userContentController;
        _webView = [[WKWebView alloc]initWithFrame:CGRectZero configuration:config];
        _webView.UIDelegate = self;
        _webView.navigationDelegate = self;
    }
    return _webView;
}



- (void)dealloc {
//    [_webView removeObserver:self forKeyPath:@"estimatedProgress"];
}

@end

