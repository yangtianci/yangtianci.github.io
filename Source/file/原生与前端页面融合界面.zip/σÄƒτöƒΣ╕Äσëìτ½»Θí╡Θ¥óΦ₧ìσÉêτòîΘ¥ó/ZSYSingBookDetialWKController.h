//
//  ZSYSingBookDetialWKController.h
//  HengtianOverseas
//
//  Created by 杨天赐 on 2023/3/17.
//

#import "BaseViewController.h"

#import "HTMySignListModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZSYSingBookDetialWKController : BaseViewController

@property (nonatomic, strong) HTMySignListModel *dataMd;


@end

NS_ASSUME_NONNULL_END
