//
//  HtjfTaxCertificateController.h
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/15.
//  Copyright © 2021 LC. All rights reserved.
//

#import "BaseCommonViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HtjfTaxCertificateController : BaseCommonViewController




/**
 
 ZDTaxResidentStatusResult : 
 
 */


// 传值: 基本信息是否已经完善: isPerfect 就行
-(void)ConfigDataWithDict:(NSString*)isPerfect;
-(void)ConfigDataWithCustomNo:(NSString*)customNo;

// 提交完毕的回调 
@property (copy, nonatomic) void(^CommitCallBack)(NSDictionary *dict);


/**
 
 一共有以下几种界面方式
 
 身份 + 基本信息 + 纳税信息( n ) + 继续添加
 
 1.只有一组数据( 基本显示 )  身份
 2.四组数据(  ) 身份 + 基本信息 + 纳税信息( 1 ) + 继续添加 ( 无组头, 第一组无删除 )
 3.四组以上(  )  身份 + 基本信息 + 纳税信息( n ) + 继续添加 ( 全部有组头, 其他组有删除 ) 
 
 
 */

@end

NS_ASSUME_NONNULL_END
