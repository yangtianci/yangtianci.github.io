//
//  HtjfTaxCertificateController.m
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/15.
//  Copyright © 2021 LC. All rights reserved.
//

#import "HtjfTaxCertificateController.h"
#import "HtjfPBPOptionCell.h"
#import "HtjfPBPTextViewCell.h"
#import "HtjfPBPInputCell.h"
#import "HtjfTCBtnCell.h"

#import "HtjfInfoTools.h"

#import "HtjfTCHeaderView.h"
#import "HtjfPBPTotalFooter.h"

#import "BRDatePickerView.h"
#import "BRStringPickerView.h"
#import "HtjfBottomFooterTaxView.h"

#import "HtjfDownLoadFormViewController.h"

#import "HtjfSingleLabelViewController.h"

#import "HTAlertView.h"

#import "HtjfCountryViewController.h"
#import "HtjfMakeInfoAlertView.h"

static NSString *const cellOption = @"cellOption";
static NSString *const cellInput = @"cellInput";
static NSString *const cellDestribute = @"cellDestribute";
static NSString *const cellAorDCell = @"cellAorDCell";

@interface HtjfTaxCertificateController ()<UITableViewDelegate, UITableViewDataSource, CTAPIManagerParamSource, CTAPIManagerCallBackDelegate>

@property (nonatomic, strong) CommonPostAPIManager *queryInfoAPI;
@property (nonatomic, strong) CommonPostAPIManager *queryIdentityAPI;
@property (nonatomic, strong) CommonPostAPIManager *queryAreaChineseAPI;
@property (nonatomic, strong) CommonPostAPIManager *queryCauseAPI;
@property (nonatomic, strong) CommonPostAPIManager *tipmanager;

@property (nonatomic, strong) CommonPostAPIManager *uploadDataAPI;

@property (nonatomic, strong) HtjfMakeInfoAlertView *aletView;

@property (strong, nonatomic) HtjfTCHeaderView *headerView;

@property (nonatomic, strong) HtjfBottomFooterTaxView *footerView;

@property (strong, nonatomic) UIView *sectionHeader;

@property (nonatomic, strong) UITableView *tableView;

@property (assign, nonatomic) NSInteger CurrentMode; // 1 / 2

@property (strong, nonatomic) NSMutableArray *modelArr;

// 因为接口设计的太辣鸡而导致的不得不增加的几个数据

@property (strong, nonatomic) NSMutableArray *identityArr;
@property (strong, nonatomic) NSMutableArray *areaCheineseArr;
@property (strong, nonatomic) NSMutableArray *causeArr;

@property (strong, nonatomic) NSMutableArray *waitTask;


@property (assign, nonatomic) CGFloat headerHeight;


@property (strong, nonatomic) NSString *isPerfect; // 是否已经完善信息 crs个人税收居民身份证明为非中国时 是否完善crs个人税收居民身份证明 0 - 否 1 - 是

@property (strong, nonatomic) NSString *cId;

@property (nonatomic, assign) BOOL popBool;
@property (nonatomic, strong) NSString *tipParString;
@property (nonatomic, strong) NSString *alertString;

@end

@implementation HtjfTaxCertificateController

-(void)ConfigDataWithCustomNo:(NSString *)customNo{
//    self.cId = customNo;
    self.cId = nil;
}

-(void)ConfigDataWithDict:(NSString*)isPerfect{
    
    self.isPerfect = isPerfect;
    
}

-(void)SubArrWithArr:(NSMutableArray*)arr Count:(NSInteger)count{
    
    for (NSInteger i = arr.count; i > count; i--) {
        [arr removeObjectAtIndex:i];
    }
}

-(void)CheckAndUpdateSectionDataWithIdx:(NSInteger)idx{
    
    NSMutableArray *sectionArr = self.modelArr[idx];
    
    // 检查最后一样是否为删除, 有则先删除, 之后再增加
    BOOL isHavaDeleteRow = NO;
    HtjfPracticalBenefitModel *lastModel = sectionArr.lastObject;
    if ([lastModel.cellTitle isEqualToString:@"删除"]) {
        isHavaDeleteRow = YES;
        [sectionArr removeLastObject];
    }
    
    NSInteger arrCount = sectionArr.count;
    
    HtjfPracticalBenefitModel *isHaveNumber = sectionArr[1];
    
    if ([isHaveNumber.value isEqualToString:@"0"]) {
        //无识别号 -> add 原因原则
        if (arrCount >= 3) { // 说明已有选择行或其他行
            HtjfPracticalBenefitModel *thirdRow = sectionArr[2];
            if ([thirdRow.cellTitle isEqualToString:@"原因"]) {
                //已有原因选择行, 进行下一个判断 -> 具体原因
                /**
                 A–居民国（地区）不发放纳税人识别号、 不用加具体原因
                B–账户持有人未能取得纳税人识别号, 添加具体原因行
                 */
                if (thirdRow.value.length == 0 || !thirdRow.value) {
                    // 还未选择, 不管
                }else{
                    if ([thirdRow.value isEqualToString:@"1"]) {
                        // 不用增加行, 检查是否有多余行需要删除
                        if (arrCount >= 4) {
                            [self SubArrWithArr:sectionArr Count:2];
                        }
                    }else if([thirdRow.value isEqualToString:@"2"]){
                        // 需要增加
                        if (arrCount >= 4) {
                            // 大于四条, 判断
                            HtjfPracticalBenefitModel *fourthRow = sectionArr[3];
                            if ([fourthRow.cellTitle isEqualToString:@"具体原因"]) {
                                // 已存在, 不管
                            }else{
                                // 已存在, 但错误, 删除后增加
                                [self SubArrWithArr:sectionArr Count:2];
//                                [sectionArr subarrayWithRange:NSMakeRange(0, 2)];
                                [sectionArr addObject:[self buildFifthFloorModelWithIdx:3]];
                            }
                        }else{
                            // 小于四条, 需要增加
                            [sectionArr addObject:[self buildFifthFloorModelWithIdx:3]];
                        }
                    }
                }
                
            }else{
                // 删除最后一行再添加
//                [sectionArr subarrayWithRange:NSMakeRange(0, 1)];
                [self SubArrWithArr:sectionArr Count:1];
                [sectionArr addObject:[self buildFifthFloorModelWithIdx:2]];
            }
        }else{
            // 需要添加
            [sectionArr addObject:[self buildFifthFloorModelWithIdx:2]];
        }
        
    }else if ([isHaveNumber.value isEqualToString:@"1"]){
        HtjfPracticalBenefitModel *thirdRow = sectionArr[2];
        //有识别号 -> add 识别号填写
        if (arrCount >= 3) { // 说明有多行
            if ([thirdRow.cellTitle isEqualToString:@"纳税人识别号"]){
                // 说明已有识别号行 -> 无需操作 ->
            }else{
                // 有其他行, 删除以后, 增加新的
                [self SubArrWithArr:sectionArr Count:1];
//                [sectionArr subarrayWithRange:NSMakeRange(0, 1)];
                [sectionArr addObject:[self buildFifthFloorModelWithIdx:1]];
            }
        }else{
            // 需要添加
            [sectionArr addObject:[self buildFifthFloorModelWithIdx:1]];
        }
    }
    
    if (isHavaDeleteRow == NO) {
        // 没有删除按钮
    }else{
        [sectionArr addObject:[self buildFourthFloorModelWithDeleteOrAdd:@"D"].lastObject];
    }
    
    [self.tableView reloadData];
    
}

/**
 
 1. 纳税人识别号
 2. 原因 - 选择
 3. 具体原因 - desc
 
 */
-(HtjfPracticalBenefitModel*)buildFifthFloorModelWithIdx:(NSInteger)idx{
    
    NSArray *modelArr = @[];
    if (idx == 1) {
        modelArr = @[@"纳税人识别号",@"taxNo",@"请输入纳税人识别号",@(2),@""];
    }else if (idx == 2){
        modelArr = @[@"原因",@"noTaxNoReason",@"请选择",@(1),@""];
    }else if (idx == 3){
        modelArr = @[@"具体原因",@"taxExplain",@"请输入",@(3),@""];
    }
    
    HtjfPracticalBenefitModel *md = [[HtjfPracticalBenefitModel alloc]init];
    [self buildSimpleModelWithArr:modelArr Model:md];
    return md;
    
}

-(void)buildSimpleModelWithArr:(NSArray*)tempArr Model:(HtjfPracticalBenefitModel*)md{
    md.cellTitle = tempArr[0];
    md.key = tempArr[1];
    md.placeString = tempArr[2];
    md.cellType = tempArr[3];
    md.optionTitle = tempArr[4];
    md.optionsArr = [NSMutableArray arrayWithArray:tempArr[5]];
    md.optionsVaArray = [NSMutableArray arrayWithArray:tempArr[6]];
    md.desc = tempArr[7];
    md.value = tempArr[8];
    
}


-(NSArray*)buildFourthFloorModelWithDeleteOrAdd:(NSString*)AorD{
    
    // title, key,
    NSArray *dataArr_1 = @[];
    
    if ([AorD isEqualToString:@"A"]) {
        
        dataArr_1 = @[
            @[@"继续添加其他纳税国信息",@"",@"",@(4),@""]
        ];
        
    }else if ([AorD isEqualToString:@"D"]) {
        dataArr_1 = @[
            @[@"删除",@"",@"",@(4),@""]
        ];
    }
    
    
    NSMutableArray *modelArr_1 = [NSMutableArray array];
    for (int i = 0; i < dataArr_1.count; i++) {
        HtjfPracticalBenefitModel *md = [[HtjfPracticalBenefitModel alloc]init];
        NSArray *tempArr = dataArr_1[i];
        [self buildSimpleModelWithArr:tempArr Model:md];
        [modelArr_1 addObject:md];
    }
    return modelArr_1;
    
}

-(NSArray*)buildThirdFloorModel{
    
    // title, key,
    NSArray *dataArr_1 = @[
        @[@"税收国/地区",@"taxNation",@"请选择",@(1),@""],
        @[@"是否有税收居民国(地区)\n纳税人识别号",@"isTaxNo",@"请选择",@(1),@"是否有纳税人识别号",@[@"是",@"否"],@[@"1",@"0"]]
    ];
    NSMutableArray *modelArr_1 = [NSMutableArray array];
    for (int i = 0; i < dataArr_1.count; i++) {
        HtjfPracticalBenefitModel *md = [[HtjfPracticalBenefitModel alloc]init];
        NSArray *tempArr = dataArr_1[i];
        [self buildSimpleModelWithArr:tempArr Model:md];
        [modelArr_1 addObject:md];
    }

    return modelArr_1;
    
}

-(NSArray*)buildSecondFloorModel{
    
    // title, key,
    NSArray *dataArr_1 = @[
        @[@"姓 (英文或拼音)",@"crsEnLastName",@"请输入您的姓氏",@(2),@""],
        @[@"名 (英文或拼音)",@"crsEnFirstName",@"请输入您的名字",@(2),@""],
        @[@"出生国家/地区",@"crsNationality",@"请选择",@(1),@"",@[],@[],@"",@""],
        @[@"出生城市",@"crsCity",@"请输入英文/拼音",@(2),@""],
        @[@"居住地址",@"crsEnAddress",@"请输入英文/拼音",@(3),@""],
    ];
    NSMutableArray *modelArr_1 = [NSMutableArray array];
    for (int i = 0; i < dataArr_1.count; i++) {
        HtjfPracticalBenefitModel *md = [[HtjfPracticalBenefitModel alloc]init];
        NSArray *tempArr = dataArr_1[i];
        [self buildSimpleModelWithArr:tempArr Model:md];
        [modelArr_1 addObject:md];
    }
    
    return modelArr_1;
    
}

-(void)buildArrMethod{
    
    NSMutableArray *OuterArr = [NSMutableArray array];
    
    // title, key,
    NSArray *dataArr_1 = @[
        @[@"税收居民身份",@"crsTaxCertificate",@"请选择",@(1),@"税收居民身份"]
    ];
    NSMutableArray *modelArr_1 = [NSMutableArray array];
    for (int i = 0; i < dataArr_1.count; i++) {
        HtjfPracticalBenefitModel *md = [[HtjfPracticalBenefitModel alloc]init];
        NSArray *tempArr = dataArr_1[i];
        [self buildSimpleModelWithArr:tempArr Model:md];
        [modelArr_1 addObject:md];
    }
        
    if (modelArr_1.count > 0) {
        [OuterArr addObject:modelArr_1];
    }

    self.modelArr = OuterArr;
}

- (void)callBack{
    
    // 未完善时点击返回提示信息
    if (![self.isPerfect isEqualToString:@"1"]) {
        self.popBool=YES;
        if (self.alertString) {
            [self alertPopString:self.alertString];
        }else{
            self.tipParString=@"110";
            showSV();
            [self.tipmanager loadData];
        }
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setMidLabelString:@"税收居民身份声明"];
    
    UIButton *left = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
    left.imageEdgeInsets = UIEdgeInsetsMake(0, -18, 0, 0);
    [left setImage:[UIImage imageNamed:@"common_icon_fanhuiBla"] forState:UIControlStateNormal];
    [left addTarget:self action:@selector(callBack) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:left];
    self.tipParString=@"110";
    [self.tipmanager loadData];
    
    
    self.isWhiteNav = YES;
    
    // 请求 options 数据
    [self.queryIdentityAPI loadData];
//    [self.queryAreaChineseAPI loadData];
    [self.queryCauseAPI loadData];
    
    self.CurrentMode = 0;
    
    [self buildArrMethod];
    [self.modelArr addObject:[self buildSecondFloorModel]];
    [self.modelArr addObject:[self buildThirdFloorModel]];
    [self.modelArr addObject:[self buildFourthFloorModelWithDeleteOrAdd:@"A"]];
    
    __weak typeof(self)WS = self;
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
    self.tableView.estimatedRowHeight = 55;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    
    [[HtjfInfoTools shared] getAnnexIds:@"179" success:^(id  _Nonnull data) {
        NSDictionary *dataDic=data;
        [[HtjfInfoTools shared] getContentID:@"1" success:^(id  _Nonnull data) {
            
            NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithDictionary:data];
            [dict enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
                NSString *skey = key;
                NSString *sobj = obj;
                if ([skey isEqualToString:@"titleFst"] && [sobj isEqualToString:@"税收"]) {
                    [dict setValue:@"税收声明" forKey:@"titleFst"];
                }
            }];
            
            self.footerView.attributed = [self attributesText:dataDic seconddata:dict];
            if ([self.isPerfect isEqualToString:@"1"]) {
                // 已完善
                [self.footerView changeToUpdateStyle];
            }
            self.tableView.tableFooterView = self.footerView;
            self.footerView.selecedBlock = ^{
                if (WS.footerView.selectBool) {
//                    WS.footerView.bottomButton.userInteractionEnabled = NO;
                    [WS checkPara];
                }else{
//                    HTAlertView *alertView = [HTAlertView alertWithTitle:@"" description:@"请勾选并同意税收相关协议" buttonTitle:@"我知道了" clickAlertView:^(AlertViewClickType type) {
//
//                    }];
//                    [alertView show];
                    
                    [HUDHelper addHUDInView:self.view text:@"请勾选并同意税收相关协议" hideAfterDelay:HUDDurtaion];
                    
                }
            };
        } failure:^(NSString * _Nonnull error) {
            
        }];
    } failure:^(NSString * _Nonnull error) {
        
    }];
    
    
    _tableView.tableHeaderView = self.headerView;
    self.headerView.autoresizingMask = UIViewAutoresizingNone;
    
    
    
    [_tableView reloadData];
    
    // 开始请求回显数据
    [self.queryInfoAPI loadData];
    
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    if (self.CurrentMode == 0) {
        return  1;
    }else if (self.CurrentMode == 1){
        return  self.modelArr.count;
    }else if (self.CurrentMode == 2){
        return  self.modelArr.count;
    }else{
        return 1;
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSMutableArray *tempArr = self.modelArr[section];
    return  tempArr.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    __weak typeof(self)WS = self;
    
    NSMutableArray *tempArr = self.modelArr[indexPath.section];
    
    HtjfPracticalBenefitModel *md = tempArr[indexPath.row];

    NSInteger cType = 1;
    if ([md.cellType isKindOfClass:[NSNumber class]]) {
        cType = [md.cellType intValue];
    }
    
    if (cType == CellTypeForPracticalBenefi_option) {
        
//        HtjfPBPOptionCell *cell = [tableView dequeueReusableCellWithIdentifier:cellOption];
        
        
        
        HtjfPBPOptionCell *cell = [[NSBundle mainBundle]loadNibNamed:@"HtjfPBPOptionCell" owner:self options:nil].firstObject;
        
        
        [cell ConfigDataWithMd:md];
        
        
        // 下划线逻辑, UI 傻逼, 这种逻辑搞得比业务逻辑还复杂
        if (indexPath.section == 0) {
            [cell MaxLine];
        }else if (indexPath.section == self.modelArr.count - 1){
            // 最后一行, 不用管
        }else{
            
            if (indexPath.section == 1 || indexPath.section == 2) {
                NSArray *sectionArr = self.modelArr[indexPath.section];
                if (indexPath.row == sectionArr.count-1) {
                    [cell MaxLine];
                }else{
                    [cell NormalLine];
                }
            }else{
                NSArray *sectionArr = self.modelArr[indexPath.section];
                if (indexPath.row == sectionArr.count-1 || indexPath.row == sectionArr.count-2) {
                    [cell MaxLine];
                }else{
                    [cell NormalLine];
                }
            }
        }
        
        return cell;
        
    }else if (cType == CellTypeForPracticalBenefit_input){
        
//        HtjfPBPInputCell *cell = [tableView dequeueReusableCellWithIdentifier:cellInput];
        
        HtjfPBPInputCell *cell = [[NSBundle mainBundle]loadNibNamed:@"HtjfPBPInputCell" owner:self options:nil].firstObject;
        
        [cell ConfigDataWithMd:md];
        
        // 下划线逻辑, UI 傻逼, 这种逻辑搞得比业务逻辑还复杂
        if (indexPath.section == 0) {
            [cell MaxLine];
        }else if (indexPath.section == self.modelArr.count - 1){
            // 最后一行, 不用管
        }else{
            
            if (indexPath.section == 1 || indexPath.section == 2) {
                NSArray *sectionArr = self.modelArr[indexPath.section];
                if (indexPath.row == sectionArr.count-1) {
                    [cell MaxLine];
                }else{
                    [cell NormalLine];
                }
            }else{
                NSArray *sectionArr = self.modelArr[indexPath.section];
                if (indexPath.row == sectionArr.count-1 || indexPath.row == sectionArr.count-2) {
                    [cell MaxLine];
                }else{
                    [cell NormalLine];
                }
            }
        }
        
        return cell;
        
    }else if (cType == CellTypeForPracticalBenefit_destribute){
        
//        HtjfPBPTextViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellDestribute];
        
        HtjfPBPTextViewCell *cell = [[NSBundle mainBundle]loadNibNamed:@"HtjfPBPTextViewCell" owner:self options:nil].firstObject;
        
        [cell ConfigDataWithMd:md];
        
        // 下划线逻辑, UI 傻逼, 这种逻辑搞得比业务逻辑还复杂
        if (indexPath.section == 0) {
            [cell MaxLine];
        }else if (indexPath.section == self.modelArr.count - 1){
            // 最后一行, 不用管
        }else{
            
            if (indexPath.section == 1 || indexPath.section == 2) {
                NSArray *sectionArr = self.modelArr[indexPath.section];
                if (indexPath.row == sectionArr.count-1) {
                    [cell MaxLine];
                }else{
                    [cell NormalLine];
                }
            }else{
                NSArray *sectionArr = self.modelArr[indexPath.section];
                if (indexPath.row == sectionArr.count-1 || indexPath.row == sectionArr.count-2) {
                    [cell MaxLine];
                }else{
                    [cell NormalLine];
                }
            }
        }
        
        return cell;
        
    }else if (cType == CellTypeForPracticalBenefit_AorDCell){
        
        HtjfTCBtnCell *cell = [tableView dequeueReusableCellWithIdentifier:cellAorDCell];
        
        [cell ConfigDataWithMd:md];
        
        cell.AorrDCallBack = ^(HtjfPracticalBenefitModel * _Nonnull md) {
        
            // 此处根据文本确定是否删除
            
            if([md.cellTitle containsString:@"删除"]){
                
                [WS.modelArr removeObjectAtIndex:indexPath.section];
                
                // 删除完毕后检查当前组件是否齐全或合理
                [self CheckAndUpdateModelArr];
            }else if ([md.cellTitle containsString:@"添加"]){
                [WS.modelArr insertObject:[WS buildThirdFloorModel] atIndex:WS.modelArr.count-1];
                
                // 添加完毕后检查当前组件是否齐全或合理
                [self CheckAndUpdateModelArr];
            }
            
            [WS.tableView reloadData];
            
        };
        
        return cell;
        
    }
    
    return [[UITableViewCell alloc]init];
}

-(void)CheckAndUpdateModelArr{
    
    if (self.modelArr.count == 4) {
        // 只添加了一组税收数据, 需要: 1.无组头 2.无删除按钮
        
        NSMutableArray *secondFloorArr = self.modelArr[2];
        HtjfPracticalBenefitModel *md = secondFloorArr.lastObject;
        if ([md.cellTitle containsString:@"删除"]) {
            [secondFloorArr removeObject:md];
        }
        
    }else if (self.modelArr.count > 4){
        // 添加了多组信息, 需要: 1.每组带标头 2.从 2- count - 1 组增加删除按钮
        
        for (int i = 2; i < self.modelArr.count - 1; i++) {
            
            NSMutableArray *secondFloorArr = self.modelArr[i];
            
            HtjfPracticalBenefitModel *md = secondFloorArr.lastObject;
            if (![md.cellTitle containsString:@"删除"]) {
                [secondFloorArr addObject:[self buildFourthFloorModelWithDeleteOrAdd:@"D"].lastObject];
            }
        }
    }
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSArray *mdArr = self.modelArr[indexPath.section];
    HtjfPracticalBenefitModel *md = mdArr[indexPath.row];
    
    __block HtjfPracticalBenefitModel *imd = md;
    __weak typeof(self)WS = self;
    
    NSInteger cType = 1;
    if ([md.cellType isKindOfClass:[NSNumber class]]) {
        cType = [md.cellType intValue];
    }
    
    if (cType == 1) { // 选择
        
        /**
         
         1.检查当前模型的选项数据是否齐全
         2.不齐全则先调用接口, 补全数据后重新调用
         3.满足则直接调用 picker
         
         */
        
        if ([md.cellTitle containsString:@"税收国"]) {
            
            HtjfCountryViewController *countryVC = [[HtjfCountryViewController alloc] init];
            [countryVC ConfigDataWithCode:nil NavTitle:@"税收国/地区"];
            countryVC.isWhiteNav = YES;
            countryVC.selectBlock = ^(HtjfVocationModel *cmodel) {
                md.value = cmodel.keyCode;
                md.desc = cmodel.keyValue;
                [WS.tableView reloadData];
            };
            [self.navigationController pushViewController:countryVC animated:YES];
            return;
            
        }
        
        if ([md.cellTitle containsString:@"出生国家"]) {
            
            HtjfCountryViewController *countryVC = [[HtjfCountryViewController alloc] init];
            [countryVC ConfigDataWithCode:@"1092" NavTitle:@"出生国家/地区"];
            countryVC.isWhiteNav = YES;
            countryVC.selectBlock = ^(HtjfVocationModel *cmodel) {
                md.value = cmodel.keyCode;
                md.desc = cmodel.keyValue;
                [WS.tableView reloadData];
            };
            [self.navigationController pushViewController:countryVC animated:YES];
            return;
            
        }
        
        if(md.optionsArr.count > 0 && md.optionsVaArray.count > 0){
            // 有数据 -> 直接弹窗
            [self ShowHaveDataPickerWithRowIndex:indexPath];
            
        }else{
            // 无数据 -> 需要先请求再弹窗
            if (indexPath.section == 0) {
                // 只能是身份选项
                HtjfPracticalBenefitModel *taskModel = [[HtjfPracticalBenefitModel alloc]init];
                taskModel.isBePlace = YES;
                taskModel.indexPath = indexPath;
                taskModel.dataType = @"身份";
                [self.waitTask addObject:taskModel];
                
                [self.queryIdentityAPI loadData];
            }else if (indexPath.section == 1){
                // 只能是地区选项
                if (self.areaCheineseArr.count == 0) {
                    
                    HtjfPracticalBenefitModel *taskModel = [[HtjfPracticalBenefitModel alloc]init];
                    taskModel.isBePlace = YES;
                    taskModel.indexPath = indexPath;
                    taskModel.dataType = @"中地区";
                    [self.waitTask addObject:taskModel];
                    
                    [self.queryAreaChineseAPI loadData];
                }else{
                    md.optionsArr = self.areaCheineseArr[0];
                    md.optionsVaArray = self.areaCheineseArr[1];
                    [self ShowHaveDataPickerWithRowIndex:indexPath];
                }
                
            }else{
                // 可能是: 地区 / 原因 两种可能
                if (indexPath.row == 0) {// 地区
                    if (self.areaCheineseArr.count == 0) {
                        
                        HtjfPracticalBenefitModel *taskModel = [[HtjfPracticalBenefitModel alloc]init];
                        taskModel.isBePlace = YES;
                        taskModel.indexPath = indexPath;
                        taskModel.dataType = @"中地区";
                        [self.waitTask addObject:taskModel];
                        
                        [self.queryAreaChineseAPI loadData];
                    }else{
                        md.optionsArr = self.areaCheineseArr[0];
                        md.optionsVaArray = self.areaCheineseArr[1];
                        [self ShowHaveDataPickerWithRowIndex:indexPath];
                    }
                }else{ // 原因
                    if (self.causeArr.count == 0) {
                        
                        HtjfPracticalBenefitModel *taskModel = [[HtjfPracticalBenefitModel alloc]init];
                        taskModel.isBePlace = YES;
                        taskModel.indexPath = indexPath;
                        taskModel.dataType = @"原因";
                        [self.waitTask addObject:taskModel];
                        
                        [self.queryCauseAPI loadData];
                    }else{
                        md.optionsArr = self.causeArr[0];
                        md.optionsVaArray = self.causeArr[1];
                        [self ShowHaveDataPickerWithRowIndex:indexPath];
                    }
                }
            }
        }
        
    }else if(cType == 2){ // 输入
        
    }else if(cType == 3){
        
    }
    
}

    

-(void)ShowHaveDataPickerWithRowIndex:(NSIndexPath*)indexPath{
    
    NSArray *mdArr = self.modelArr[indexPath.section];
    HtjfPracticalBenefitModel *md = mdArr[indexPath.row];
    
    __block HtjfPracticalBenefitModel *imd = md;
    __weak typeof(self)WS = self;
    
    NSString *pickerTitle = @"";
    if ([md.optionTitle containsString:@"识别号"] || [md.optionTitle containsString:@"居民身份"]) {
        
    }else{
        pickerTitle = md.optionTitle;
    }
    
    [self showPickerWitCardTypeWith:pickerTitle data:md.optionsArr complete:^(BRResultModel *model) {
        
//            NSArray *ImdArr = WS.modelArr[indexPath.section];
//            HtjfPracticalBenefitModel *Imd = ImdArr[indexPath.row];
        
        md.desc = model.selectValue;
        md.value = md.optionsVaArray[model.index];
        
       // 税收居民身份选择完毕
        if ([md.cellTitle isEqualToString:@"税收居民身份"]) {
            WS.CurrentMode = model.index;
            
            if (model.index == 0) {
                // 国内, 刷新即可
            }else if (model.index == 1 || model.index == 2){
                
//                if (WS.modelArr.count == 1) {
//                    // 说明内部数组还没建立过, 需要重新建立
//                    [WS.modelArr addObject:[WS buildSecondFloorModel]];
//                    [WS.modelArr addObject:[WS buildThirdFloorModel]];
//                    [WS.modelArr addObject:[WS buildFourthFloorModelWithDeleteOrAdd:@"A"]];
//                }else{
//                    // 说明已经建立, 不用重新建立, 刷新即可
//                }
                
            }
            
        }else if ([imd.cellTitle containsString:@"纳税人识别号"]) {
            // 是否有税号
            [self CheckAndUpdateSectionDataWithIdx:indexPath.section];
            
        }else if ([imd.cellTitle containsString:@"原因"]) {
            // 原因
            [self CheckAndUpdateSectionDataWithIdx:indexPath.section];
        }
        
        [WS.tableView reloadData];
        
    }];
    
}



- (void)showPickerWitCardTypeWith:(NSString *)title data:(NSArray *)data complete:(void(^)(BRResultModel *model))complete {
    BRStringPickerView *stringPickerView = [[BRStringPickerView alloc]initWithPickerMode:BRStringPickerComponentSingle];
    stringPickerView.title = title;
    stringPickerView.dataSourceArr = data;
    stringPickerView.resultModelBlock = ^(BRResultModel *resultModel) {
        complete(resultModel);
    };
     //自定义弹框样式
    stringPickerView.pickerStyle = [self generatepickerStyle];
    [stringPickerView show];
}

- (void)showDate:(void(^)(NSString *value))complete {
    BRDatePickerView *datePickerView = [[BRDatePickerView alloc]initWithPickerMode:BRDatePickerModeYMD];
    datePickerView.title = @"选择日期";
    datePickerView.resultBlock = ^(NSString *selectValue) {
        complete(selectValue);
    };
        //自定义弹框样式
    BRPickerStyle *customStyle = [[BRPickerStyle alloc]init];
    customStyle.hiddenTitleBottomBorder = YES;
    customStyle.doneTextColor=[UIColor colorWithHexString:@"364D97"];;
    customStyle.doneBtnFrame = CGRectMake(SCREEN_WIDTH - 54, 0, 44, 44);
    customStyle.pickerTextFont = [UIFont systemFontOfSize:20.0f];
    customStyle.titleTextColor=[UIColor blackColor];
    customStyle.pickerTextColor=[UIColor blackColor];
    datePickerView.pickerStyle = customStyle;
    [datePickerView show];
}

- (BRPickerStyle*)generatepickerStyle {
    BRPickerStyle *customStyle = [[BRPickerStyle alloc]init];
    customStyle.hiddenTitleBottomBorder = YES;
    customStyle.doneTextColor = [UIColor colorWithHexString:@"364D97"];;
    customStyle.doneBtnFrame = CGRectMake(SCREEN_WIDTH - 54, 0, 44, 44);
    customStyle.pickerTextFont = [UIFont systemFontOfSize:20.0f];
    customStyle.titleTextColor = [UIColor blackColor];
    customStyle.pickerTextColor = [UIColor blackColor];
    return customStyle;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    if (self.modelArr.count <= 4) {
        UIView *sectionView = [[UIView alloc]init];
        sectionView.backgroundColor = [UIColor colorWithHexString:@"0xF5F5F5"];
        return sectionView;
    }else if (self.modelArr.count > 4){
        if (section >= 2 && section != self.modelArr.count-1) {
            
            NSString *indexString = [self translation:[NSString stringWithFormat:@"%zd",section-1]];
            
            UIView *sectionHeader = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, 55)];
            UILabel *titleLab = [[UILabel alloc]init];
            titleLab.text = [NSString stringWithFormat:@"纳税信息%@",indexString];
            titleLab.font = [UIFont boldSystemFontOfSize:18];
            titleLab.textColor = [UIColor colorWithHexString:@"0x000000"];
            [sectionHeader addSubview:titleLab];
            [titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(15);
                make.bottom.mas_equalTo(-10);
            }];
            
            return sectionHeader;
            
        }
    }
    
    UIView *sectionView = [[UIView alloc]init];
    sectionView.backgroundColor = [UIColor colorWithHexString:@"0xF5F5F5"];
    
    return sectionView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    if (self.modelArr.count <= 4) {
        return 10;
    }else if (self.modelArr.count > 4){
        if (section >= 2 && section != self.modelArr.count-1) {
            return 55;
        }
    }
    
    if (section == 0) {
        return 0.01;
    }
    
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return [[UIView alloc]init];
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
//    return 50;
//}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.bounces = NO;
        
        [_tableView registerNib:[UINib nibWithNibName:NSStringFromClass(HtjfPBPOptionCell.class) bundle:nil] forCellReuseIdentifier:cellOption];
        [_tableView registerNib:[UINib nibWithNibName:NSStringFromClass(HtjfPBPInputCell.class) bundle:nil] forCellReuseIdentifier:cellInput];
        [_tableView registerNib:[UINib nibWithNibName:NSStringFromClass(HtjfPBPTextViewCell.class) bundle:nil] forCellReuseIdentifier:cellDestribute];
        [_tableView registerNib:[UINib nibWithNibName:NSStringFromClass(HtjfTCBtnCell.class) bundle:nil] forCellReuseIdentifier:cellAorDCell];
        
        _tableView.backgroundColor = UIColor.clearColor;
    }
    return _tableView;
}

-(HtjfTCHeaderView *)headerView{
    if (!_headerView) {
        _headerView = [[NSBundle mainBundle]loadNibNamed:@"HtjfTCHeaderView" owner:self options:nil].firstObject;
    }
    return _headerView;
}


- (NSDictionary *)paramsForApi:(CTAPIBaseManager *)manager {
    NSDictionary *para = [NSDictionary dictionary];
    if (manager == self.queryInfoAPI) {
        para=@{
            
        };
    }else if (manager == self.queryIdentityAPI){
        para = @{
            @"dicNo":@"1047"
        };
    }else if (manager == self.queryAreaChineseAPI){
        para = @{
            @"dicNo":@"1092"
        };
    }else if (manager == self.queryCauseAPI){
        para = @{
            @"dicNo":@"1048"
        };
    }else if (manager == self.uploadDataAPI){
        return [self BuildRequestDict];
    }else if (manager==self.tipmanager){
        NSMutableDictionary*paramsDic=[NSMutableDictionary new];
        [paramsDic setObject:self.tipParString forKey:@"contentBelong"];
        return paramsDic;
    }
    return para;
}


-(void)BuildStarModelWithDict:(NSDictionary*)dataDict{
    
    if ([dataDict isKindOfClass: [NSString class]]) {
        // 属于脏数据, 不做处理
        return;
    }
    
    NSString *crsTaxCertificate = dataDict[@"crsTaxCertificate"];
    self.CurrentMode = [crsTaxCertificate intValue];
    if ([crsTaxCertificate isEqualToString:@"0"]) {
        // 说明是国内, 正常初始化即可, 不用处理
        
        // 第一组: 居民身份模型
        NSArray *firstSession = self.modelArr[0];
        HtjfPracticalBenefitModel *md = firstSession.firstObject;
        md.value = crsTaxCertificate;
        
        NSString *descString = [NSString stringWithFormat:@"%@",dataDict[@"crsTaxCertificateDesc"]];
        if (descString && descString.length > 0 && ![descString isEqualToString:@"(null)"]) {
            md.desc = descString;
        }
        
    }else{
        // 国外需要读取数据并赋值
        
        // 第一组: 居民身份模型
        NSArray *firstSession = self.modelArr[0];
        HtjfPracticalBenefitModel *md = firstSession.firstObject;
        md.value = crsTaxCertificate;
        
        NSString *descString = [NSString stringWithFormat:@"%@",dataDict[@"crsTaxCertificateDesc"]];
        if (descString && descString.length > 0 && ![descString isEqualToString:@"(null)"]) {
            md.desc = descString;
        }
        
        // 第二组
        NSMutableArray *secondArr = self.modelArr[1];
        
        // 姓
        NSString *crsEnLastName = [NSString stringWithFormat:@"%@",dataDict[@"crsEnLastName"]];
        if (crsEnLastName.length > 0) {
            HtjfPracticalBenefitModel *xing_md = secondArr.firstObject;
            xing_md.value = crsEnLastName;
            xing_md.desc = crsEnLastName;
        }
        
        // 名
        NSString *crsEnFirstName = [NSString stringWithFormat:@"%@",dataDict[@"crsEnFirstName"]];
        if (crsEnFirstName.length > 0) {
            HtjfPracticalBenefitModel *ming_md = secondArr[1];
            ming_md.value = crsEnFirstName;
            ming_md.desc = crsEnFirstName;
        }
        
        // 国家 / 地区
        NSString *crsNationality = [NSString stringWithFormat:@"%@",dataDict[@"crsNationality"]];
        if (crsNationality.length > 0 && ![crsNationality isEqualToString:@"(null)"]) {
            HtjfPracticalBenefitModel *diqu_md = secondArr[2];
            diqu_md.value = crsNationality;
            diqu_md.desc = [NSString stringWithFormat:@"%@",dataDict[@"crsNationalityDesc"]];
        }
        
        // 城市
        NSString *crsCity = [NSString stringWithFormat:@"%@",dataDict[@"crsCity"]];
        if (crsCity.length > 0) {
            HtjfPracticalBenefitModel *city_md = secondArr[3];
            city_md.value = crsCity;
            city_md.desc = crsCity;
        }
        
        // 城市
        NSString *crsEnAddress = [NSString stringWithFormat:@"%@",dataDict[@"crsEnAddress"]];
        if (crsEnAddress.length > 0 && ![crsEnAddress isEqualToString:@"(null)"]) {
            HtjfPracticalBenefitModel *address_md = secondArr[4];
            address_md.value = crsEnAddress;
            address_md.desc = crsEnAddress;
        }
        
        // 其他数据组
        NSArray *crsTaxList = dataDict[@"crsTaxList"];
        if (crsTaxList.count > 0) {
            // 先移除最后两个
            [self.modelArr removeLastObject];
            [self.modelArr removeLastObject];
            
            NSMutableArray *DataListArr = [NSMutableArray array];
            
            for (int i = 0; i < crsTaxList.count; i++) {
                
                NSDictionary *sessionDict = crsTaxList[i];
                
                NSMutableArray *baseArr = [NSMutableArray arrayWithArray:[self buildThirdFloorModel]];
                
                
                // 税收国 / 地区
                NSString *taxNation = [NSString stringWithFormat:@"%@",sessionDict[@"taxNation"]];
                if (taxNation.length > 0) {
                    HtjfPracticalBenefitModel *taxNation_md = baseArr[0];
                    taxNation_md.value = taxNation;
                    taxNation_md.desc = [NSString stringWithFormat:@"%@",sessionDict[@"taxNationDesc"]];
                }
                
                // 是否有税收号
                NSString *isTaxNo = [NSString stringWithFormat:@"%@",sessionDict[@"isTaxNo"]];
                if (isTaxNo.length > 0) {
                    HtjfPracticalBenefitModel *tisTaxNo_md = baseArr[1];
                    tisTaxNo_md.value = isTaxNo;
                    if ([isTaxNo isEqualToString:@"1"]) {
                        tisTaxNo_md.desc = @"是";
                    }else{
                        tisTaxNo_md.desc = @"否";
                    }
                }
                
                if ([isTaxNo isEqualToString:@"1"]) {
                    // 有税号
                    [baseArr addObject:[self buildFifthFloorModelWithIdx:1]];
                    
                    NSString *taxNo = [NSString stringWithFormat:@"%@",sessionDict[@"taxNo"]];
                    if (taxNo.length > 0) {
                        HtjfPracticalBenefitModel *taxNo_md = baseArr[2];
                        taxNo_md.value = taxNo;
                        taxNo_md.desc = taxNo;
                    }
                    
                }else{
                    // 无税号
                    // 先判断原因
                    NSString *noTaxNoReason = [NSString stringWithFormat:@"%@",sessionDict[@"noTaxNoReason"]];
                    if (noTaxNoReason.length > 0) {
                        // 有原因
                        [baseArr addObject:[self buildFifthFloorModelWithIdx:2]];
                        
                        HtjfPracticalBenefitModel *noTaxNoReason_md = baseArr[2];
                        noTaxNoReason_md.value = noTaxNoReason;
                        noTaxNoReason_md.desc = [NSString stringWithFormat:@"%@",sessionDict[@"noTaxNoReasonDesc"]];
                    }
                    
                    // 如果原因为 B 则再增加一行, 具体理由
                    
                    if ([noTaxNoReason isEqualToString:@"2"]) {
                        
                        NSString *taxExplain = [NSString stringWithFormat:@"%@",sessionDict[@"taxExplain"]];
                        
                        [baseArr addObject:[self buildFifthFloorModelWithIdx:3]];
                        
                        HtjfPracticalBenefitModel *taxExplain_md = baseArr[3];
                        taxExplain_md.value = taxExplain;
                        taxExplain_md.desc = taxExplain;
                    }
                }
                
                
                
                if (crsTaxList.count > 1) {
                    // 说明有多组数据, 需要增加下删除按钮
                    [baseArr addObject:[self buildFourthFloorModelWithDeleteOrAdd:@"D"].firstObject];
                }
                
                [DataListArr addObject:baseArr];
                
            }
            
            [self.modelArr addObjectsFromArray:DataListArr];
            
            if(crsTaxList.count >= 1){
                // 多条, 增加按钮
                [self.modelArr addObject:[self buildFourthFloorModelWithDeleteOrAdd:@"A"]];
            }else{
                //
            }
            
        }else{
            // 无数据, 不处理
        }
        
    }
    
}

-(BOOL)isContainSpecialCharactorWithString:(NSString*)content{
    
    NSRegularExpression *expression = [NSRegularExpression regularExpressionWithPattern:@"[^a-zA-Z-_ 0-9：“，。：# & @ . ； - _ （ ）|  / ”]" options:NSRegularExpressionCaseInsensitive error:nil];
    
    NSInteger num = [expression numberOfMatchesInString:content options:NSMatchingReportProgress range:NSMakeRange(0, content.length)];
    
    if (num == 0) {
        // 无特殊字符
        return NO;
    }else{
        return YES;
    }
}

-(void)AlertMsgWithMd:(HtjfPracticalBenefitModel*)md{
    
    NSString *tipString = @"";
    
    if ([md.cellTitle containsString:@"身份"]) {
        // 不处理, 走下面的逻辑
    }else if ([md.cellTitle containsString:@"姓"]) {
        
        if (!md.value || md.value.length == 0) {
//            tipString = @"请输入您的姓氏";
            // 不处理, 走下面的逻辑
        }else if ( [self isContainSpecialCharactorWithString:md.value]){
            tipString = @"请输入正确的姓氏";
        }
        
    }else if ([md.cellTitle containsString:@"名"]) {
        
        if (!md.value || md.value.length == 0) {
//            tipString = @"请输入您的姓氏";
            // 不处理, 走下面的逻辑
        }else if ( [self isContainSpecialCharactorWithString:md.value]){
            tipString = @"请输入正确的名字";
        }
        
    }else if ([md.cellTitle containsString:@"国家"]) {
        
    }else if ([md.cellTitle containsString:@"城市"]) {
        
        if (!md.value || md.value.length == 0) {
            tipString = @"请输入您的出生城市";
        }else if ( [self isContainSpecialCharactorWithString:md.value] || md.value.length < 10){
            tipString = @"请输入正确的出生城市";
        }
        
    }else if ([md.cellTitle containsString:@"居住地址"]) {
        
        if (!md.value || md.value.length == 0) {
            tipString = @"请输入您的居住地址";
        }else if ( [self isContainSpecialCharactorWithString:md.value] || md.value.length < 10){
            tipString = @"请输入正确的居住地址";
        }
        
    }else if ([md.cellTitle containsString:@"税收国"]) {
        
    }else if ([md.cellTitle containsString:@"识别号"]) {
        
    }else if ([md.cellTitle isEqualToString:@"原因"]) {
        
    }else if ([md.cellTitle containsString:@"具体原因"]) {
        
    }
    
    if (tipString.length == 0) { // 默认的规则处理逻辑
        
        NSInteger cType = 1;
        if ([md.cellType isKindOfClass:[NSNumber class]]) {
            cType = [md.cellType intValue];
        }
        
        if (cType == CellTypeForPracticalBenefi_option) {
            tipString = [NSString stringWithFormat:@"请选择%@",md.cellTitle];
        }else if (cType == CellTypeForPracticalBenefit_input){
            tipString = [NSString stringWithFormat:@"请输入%@",md.cellTitle];
            
            if ([md.cellTitle containsString:@"姓"] || [md.cellTitle containsString:@"名"] || [md.cellTitle containsString:@"出生城市"]) {
                tipString = md.placeString;
            }
            
        }else if (cType == CellTypeForPracticalBenefit_destribute){
            tipString = [NSString stringWithFormat:@"请输入%@",md.cellTitle];
        }
        
    }
    
//    HTAlertView *alertView = [HTAlertView alertWithTitle:@"" description:tipString buttonTitle:@"我知道了" clickAlertView:^(AlertViewClickType type) {
//    }];
//    [alertView show];
    
    [HUDHelper addHUDInView:self.view text:tipString hideAfterDelay:HUDDurtaion];
    
//    self.footerView.bottomButton.userInteractionEnabled = YES;
    
}

-(void)checkPara{
    
    if (self.CurrentMode == 0) { // 只有一行
        
        NSArray *firtsessionArr = self.modelArr[0];
        HtjfPracticalBenefitModel *md = firtsessionArr.firstObject;
        
        if (!md.value || md.value.length == 0) {
            // 弹窗
            [self AlertMsgWithMd:md];
            return;
        }else{
            NSInteger cType = [md.cellType intValue];
            if (cType == CellTypeForPracticalBenefit_input || cType == CellTypeForPracticalBenefit_destribute) {
                if ([self isContainSpecialCharactorWithString:md.value]) {
                    // 弹窗
                    [self AlertMsgWithMd:md];
                    return;
                }
            }
        }
        
    }else if (self.CurrentMode == 1 || self.CurrentMode == 2){ //
        
        NSArray *firtSessionArr = self.modelArr[0];
        HtjfPracticalBenefitModel *md = firtSessionArr.firstObject;
        
        if (!md.value || md.value.length == 0) {
            // 弹窗
            [self AlertMsgWithMd:md];
            return;
        }else{
            NSInteger cType = [md.cellType intValue];
            if (cType == CellTypeForPracticalBenefit_input || cType == CellTypeForPracticalBenefit_destribute) {
                if ([self isContainSpecialCharactorWithString:md.value]) {
                    // 弹窗
                    [self AlertMsgWithMd:md];
                    return;
                }
            }
        }
        
        NSArray *secondSessionArr = self.modelArr[1];
        for (int i = 0; i < secondSessionArr.count; i++) {
            
            
            HtjfPracticalBenefitModel *md = secondSessionArr[i];
            
            if (([md.cellTitle containsString:@"城市"] || [md.cellTitle containsString:@"居住地址"]) ) {
                
                if (!md.value || md.value.length < 10) {
                    // 弹窗
                    [self AlertMsgWithMd:md];
                    return;
                }else{
                    NSInteger cType = [md.cellType intValue];
                    if (cType == CellTypeForPracticalBenefit_input || cType == CellTypeForPracticalBenefit_destribute) {
                        if ([self isContainSpecialCharactorWithString:md.value]) {
                            // 弹窗
                            [self AlertMsgWithMd:md];
                            return;
                        }
                    }
                }
            }
            
            if (!md.value || md.value.length == 0) {
                // 弹窗
                [self AlertMsgWithMd:md];
                return;
            }else{
                NSInteger cType = [md.cellType intValue];
                if (cType == CellTypeForPracticalBenefit_input || cType == CellTypeForPracticalBenefit_destribute) {
                    if ([self isContainSpecialCharactorWithString:md.value]) {
                        // 弹窗
                        [self AlertMsgWithMd:md];
                        return;
                    }
                }
            }
        }
        
        for (int i = 2; i < self.modelArr.count; i++) {
            
            NSArray *listSessionArr = self.modelArr[i];
            
            if (listSessionArr.count == 1) {
                HtjfPracticalBenefitModel *addMd = listSessionArr.firstObject;
                if ([addMd.cellTitle containsString:@"继续添加"]) {
                    continue;;
                }
            }
            
            for (int i = 0; i < listSessionArr.count; i++) {
                HtjfPracticalBenefitModel *md = listSessionArr[i];
                
                if ([md.cellTitle isEqualToString:@"删除"]) {
                    continue;
                }
                if (!md.value || md.value.length == 0) {
                    // 弹窗
                    [self AlertMsgWithMd:md];
                    return;
                }else{
                }
            }
        }
    }
    
    showSV();
    [self.uploadDataAPI loadData];
    
}

-(NSDictionary*)BuildRequestDict{
    
    NSMutableDictionary *totalPara = [NSMutableDictionary dictionary];
    
    if (self.CurrentMode == 0) { // 只有一行
        
        NSArray *firtsessionArr = self.modelArr[0];
        HtjfPracticalBenefitModel *md = firtsessionArr.firstObject;
        
        [totalPara setValue:md.value forKey:md.key];
        
    }else if (self.CurrentMode == 1 || self.CurrentMode == 2){ //
        
        NSArray *firtSessionArr = self.modelArr[0];
        HtjfPracticalBenefitModel *md = firtSessionArr.firstObject;
        [totalPara setValue:md.value forKey:md.key];
        
        NSArray *secondSessionArr = self.modelArr[1];
        for (int i = 0; i < secondSessionArr.count; i++) {
            HtjfPracticalBenefitModel *md = secondSessionArr[i];
            [totalPara setValue:md.value forKey:md.key];
        }
        
        NSMutableArray *taxList = [NSMutableArray array];
        for (int i = 2; i < self.modelArr.count - 1; i++) {
            NSArray *listSessionArr = self.modelArr[i];
            NSMutableDictionary *tempDict = [NSMutableDictionary dictionary];
            for (int i = 0; i < listSessionArr.count; i++) {
                HtjfPracticalBenefitModel *md = listSessionArr[i];
                [tempDict setValue:md.value forKey:md.key];
            }
            [taxList addObject:tempDict];
        }
        [totalPara setValue:taxList forKey:@"crsTaxList"];
        
    }
    
    if (self.cId != nil) {
        [totalPara setValue:self.cId forKey:@"id"];
    }else{
        
    }
    
    return totalPara;
    
}



- (void)managerCallAPIDidSuccess:(CTAPIBaseManager *)manager {
    dismissSV();
    NSDictionary *contentDic = [manager fetchDataWithReformer:nil];
    if (self.queryInfoAPI == manager) {
        
        [self BuildStarModelWithDict:contentDic[@"data"]];
        
        NSString *cid = [NSString stringWithFormat:@"%@",contentDic[@"data"][@"id"]];
        
        if (cid && cid.length > 0 && ![cid isEqualToString:@"(null)"]) {
            self.cId = cid;
        }else{
            self.cId = nil;
        }
        
        [self.tableView reloadData];
        
    }else if (self.queryIdentityAPI == manager) {
        
        NSMutableArray *dataArr = [self DisposeDictDataWithArr:contentDic[@"data"] Key1:@"keyValue" Key2:@"keyCode"];
        
        NSArray *firstSession = self.modelArr[0];
        HtjfPracticalBenefitModel *md = firstSession.firstObject;
        md.optionsArr = dataArr[0];
        md.optionsVaArray = dataArr[1];
        
        
    }else if (self.queryAreaChineseAPI == manager) {
        
        NSMutableArray *dataArr = [self DisposeDictDataWithArr:contentDic[@"data"] Key1:@"keyValue" Key2:@"keyCode"];
        self.areaCheineseArr = dataArr;
        
        if (self.waitTask.count > 0) {
            for (int i = 0; i < self.waitTask.count; i++) {
                HtjfPracticalBenefitModel *idxMd = self.waitTask[i];
                if ([idxMd.dataType containsString:@"中地区"]) {
                    NSIndexPath *aimIdx = idxMd.indexPath;
                    NSMutableArray *sessionArr = self.modelArr[aimIdx.section];
                    HtjfPracticalBenefitModel *md = sessionArr[aimIdx.row];
                    md.optionsArr = self.areaCheineseArr[0];
                    md.optionsVaArray = self.areaCheineseArr[1];
                    [self ShowHaveDataPickerWithRowIndex:idxMd.indexPath];
                    [self.waitTask removeObject:idxMd];
                    break;
                }
            }
            
        }
        
    }else if (self.queryCauseAPI == manager) {
        
        NSMutableArray *dataArr = [self DisposeDictDataWithArr:contentDic[@"data"] Key1:@"keyValue" Key2:@"keyCode"];
        self.causeArr = dataArr;

        if (self.waitTask.count > 0) {
            for (int i = 0; i < self.waitTask.count; i++) {
                HtjfPracticalBenefitModel *idxMd = self.waitTask[i];
                if ([idxMd.dataType containsString:@"原因"]) {
                    NSIndexPath *aimIdx = idxMd.indexPath;
                    NSMutableArray *sessionArr = self.modelArr[aimIdx.section];
                    HtjfPracticalBenefitModel *md = sessionArr[aimIdx.row];
                    md.optionsArr = self.causeArr[0];
                    md.optionsVaArray = self.causeArr[1];
                    [self ShowHaveDataPickerWithRowIndex:idxMd.indexPath];
                    [self.waitTask removeObject:idxMd];
                    break;
                }
            }
            
        }
    }else if (manager == self.uploadDataAPI){
        
//        NSDictionary *dataDict = contentDic[@"data"];
        
        NSArray *sessionArr = self.modelArr.firstObject;
        HtjfPracticalBenefitModel *md = sessionArr.firstObject;
        
        NSMutableDictionary *paraDict = [NSMutableDictionary dictionary];
        [paraDict setValue:md.desc forKey:@"fuck You Zhanx"];
        
        if (self.CommitCallBack) {
            self.CommitCallBack(paraDict);
        }
        
        [HUDHelper addHUDInView:self.view text:@"税收居民身份已更新" hideAfterDelay:HUDDurtaion];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
        });
        
    }else if (manager==self.tipmanager){
        if ([[contentDic objectForKey:@"status"] isEqualToString:@"0000"]) {
            NSDictionary *data = [contentDic objectForKey:@"data"];
           if ([data isKindOfClass:[NSDictionary class]]) {
               if ([self.tipParString isEqualToString:@"110"]) {
                   self.alertString=contentDic[@"data"][@"descr"];
                   if (self.popBool) {
                       [self alertPopString:self.alertString];
                   }
               }else{
                   HTAlertView *alertView = [HTAlertView alertWithTitle:@"温馨提示" description:contentDic[@"data"][@"descr"] buttonTitle:@"我知道了" clickAlertView:^(AlertViewClickType type) {
                       
                   }];
                   [alertView show];
               }
           }else {
               showMiddle2SecondWithText(@"信息未正常展示");
           }
        }else {
            showMiddle2SecondWithText(@"信息未正常展示");
        }
    }
}

-(NSMutableArray*)DisposeDictDataWithArr:(NSArray*)arr Key1:(NSString*)k1 Key2:(NSString*)k2{
    
    NSMutableArray *totalArr = [NSMutableArray array];
    
    NSMutableArray *arr1 = [NSMutableArray array];
    NSMutableArray *arr2 = [NSMutableArray array];
    
    [arr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
        NSDictionary *dict = (NSDictionary*)obj;
        [arr1 addObject:dict[k1]];
        [arr2 addObject:dict[k2]];
        
    }];
    
    [totalArr addObjectsFromArray:@[arr1,arr2]];
    
    return totalArr;
    
}


- (void)managerCallAPIDidFailed:(CTAPIBaseManager *)manager {
    dismissSV();
    NSDictionary *contentDic = [manager fetchDataWithReformer:nil];
    NSString *message = contentDic[@"message"];
    [HUDHelper addHUDInView:self.view text:message hideAfterDelay:HUDDurtaion];
    
//    if (self.uploadDataAPI == manager) {
//        self.footerView.bottomButton.userInteractionEnabled = YES;
//    }
    
}

#pragma mark - - - lazy loading
    
    
    
    - (CommonPostAPIManager *)uploadDataAPI {
        if (!_uploadDataAPI) {
            _uploadDataAPI = [[CommonPostAPIManager alloc] init];
            _uploadDataAPI.delegate = self;
            _uploadDataAPI.paramSource = self;
            _uploadDataAPI.commonAPIAddress = @"/app/account/alterTaxResidentStatusOfZd";
        }
        return _uploadDataAPI;
    }
    
    
- (CommonPostAPIManager *)queryInfoAPI {
    if (!_queryInfoAPI) {
        _queryInfoAPI = [[CommonPostAPIManager alloc] init];
        _queryInfoAPI.delegate = self;
        _queryInfoAPI.paramSource = self;
        _queryInfoAPI.commonAPIAddress = @"/app/account/getTaxResidentStatusOfZd";
    }
    return _queryInfoAPI;
}

- (CommonPostAPIManager *)queryIdentityAPI {
    if (!_queryIdentityAPI) {
        _queryIdentityAPI = [[CommonPostAPIManager alloc] init];
        _queryIdentityAPI.delegate = self;
        _queryIdentityAPI.paramSource = self;
        _queryIdentityAPI.commonAPIAddress = @"/app/account/frontend/queryCrmDataDictionary";
    }
    return _queryIdentityAPI;
}

- (CommonPostAPIManager *)queryAreaChineseAPI {
    if (!_queryAreaChineseAPI) {
        _queryAreaChineseAPI = [[CommonPostAPIManager alloc] init];
        _queryAreaChineseAPI.delegate = self;
        _queryAreaChineseAPI.paramSource = self;
        _queryAreaChineseAPI.commonAPIAddress = @"/app/account/frontend/queryCrmDataDictionary";
    }
    return _queryAreaChineseAPI;
}

- (CommonPostAPIManager *)queryCauseAPI {
    if (!_queryCauseAPI) {
        _queryCauseAPI = [[CommonPostAPIManager alloc] init];
        _queryCauseAPI.delegate = self;
        _queryCauseAPI.paramSource = self;
        _queryCauseAPI.commonAPIAddress = @"/app/account/frontend/queryCrmDataDictionary";
    }
    return _queryCauseAPI;
}

    


-(NSString*)translation:(NSString *)arebic
{   NSString *str = arebic;

    NSArray *arabic_numerals = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"0"];

    NSArray *chinese_numerals = @[@"一",@"二",@"三",@"四",@"五",@"六",@"七",@"八",@"九",@"零"];

    NSArray *digits = @[@"个",@"十",@"百",@"千",@"万",@"十",@"百",@"千",@"亿",@"十",@"百",@"千",@"兆"];

    NSDictionary *dictionary = [NSDictionary dictionaryWithObjects:chinese_numerals forKeys:arabic_numerals];

    

    NSMutableArray *sums = [NSMutableArray array];

    for (int i = 0; i < str.length; i ++) {

        NSString *substr = [str substringWithRange:NSMakeRange(i, 1)];

        NSString *a = [dictionary objectForKey:substr];

        NSString *b = digits[str.length -i-1];

        NSString *sum = [a stringByAppendingString:b];

        if ([a isEqualToString:chinese_numerals[9]])

        {

            if([b isEqualToString:digits[4]] || [b isEqualToString:digits[8]])

            {

                sum = b;

                if ([[sums lastObject] isEqualToString:chinese_numerals[9]])

                {

                    [sums removeLastObject];

                }

            }else

            {

                sum = chinese_numerals[9];

            }

            

            if ([[sums lastObject] isEqualToString:sum])

            {

                continue;

            }

        }

        [sums addObject:sum];

    }

    

    NSString *sumStr = [sums  componentsJoinedByString:@""];

    NSString *chinese = [sumStr substringToIndex:sumStr.length-1];

    NSLog(@"%@ to %@",str,chinese);

    return chinese;

}

-(NSMutableArray *)waitTask{
    if (!_waitTask) {
        _waitTask = [NSMutableArray array];
    }
    return _waitTask;
}

- (HtjfBottomFooterTaxView *)footerView {
    if (!_footerView) {
        _footerView = [[HtjfBottomFooterTaxView alloc] init];
        _footerView.frame = CGRectMake(0, 0, self.view.width, _headerHeight+94);
    }
    return _footerView;
}



- (NSAttributedString *)attributesText:(NSDictionary *)data seconddata:(NSDictionary *)data2 {
     NSString *nameFirString = data2[@"titleFst"];
     NSString *nametextString = data2[@"descr"];
    NSString *name = data[@"accessoryName"];
    NSDictionary *attributes = @{NSFontAttributeName:[UIFont fontWithName:@"PingFangSC-Regular" size:12], NSForegroundColorAttributeName: kColorFromeRGB(@"#9B9B9B")};
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"已阅读并了解 《%@》 %@",nameFirString,name] attributes:attributes];
    [text yy_setTextHighlightRange:[[text string] rangeOfString:[NSString stringWithFormat:@"%@",name]] color:kColorFromeRGB(@"#385FFF") backgroundColor:UIColor.clearColor tapAction:^(UIView * _Nonnull containerView, NSAttributedString * _Nonnull text, NSRange range, CGRect rect) {
        HtjfDownLoadFormViewController *att = [[HtjfDownLoadFormViewController alloc] init];
        att.isWhiteNav = YES;
        att.fileName = name;
        att.fileUrl = data[@"accessoryUrl"];
        [self.navigationController pushViewController:att animated:YES];
    }];
    [text yy_setTextHighlightRange:[[text string] rangeOfString:[NSString stringWithFormat:@"《%@》",nameFirString]] color:kColorFromeRGB(@"#385FFF") backgroundColor:UIColor.clearColor tapAction:^(UIView * _Nonnull containerView, NSAttributedString * _Nonnull text, NSRange range, CGRect rect) {
        
        HtjfSingleLabelViewController *att = [[HtjfSingleLabelViewController alloc] init];
        att.isWhiteNav = YES;
        att.titleStr = nameFirString;
        att.contentStr= nametextString;
        [self.navigationController pushViewController:att animated:YES];
    }];
    _headerHeight = [text.string boundingRectWithSize:CGSizeMake(self.view.width - 55, CGFLOAT_MAX) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:attributes context:nil].size.height ;
    [self.tableView reloadData];
    return text;
}

-(CommonPostAPIManager *)tipmanager{
    if (!_tipmanager) {
        _tipmanager=[[CommonPostAPIManager alloc]init];
        _tipmanager.delegate=self;
        _tipmanager.paramSource=self;
        _tipmanager.commonAPIAddress=@"/app/content/frontend/getContent";
    }
    return _tipmanager;
}

-(void)alertPopString:(NSString *)str{
    __block typeof(self)weakSelf = self;
    self.aletView=[[[NSBundle mainBundle]loadNibNamed:@"HtjfMakeInfoAlertView" owner:self options:nil]lastObject];
    self.aletView.titleLab.text = @"温馨提示";
    self.aletView.contentlabel.text=str;
    self.aletView.buttonPress  = ^(BOOL sucess) {
        [weakSelf.aletView removeFromSuperview];
        if (sucess==NO) {
//            UIViewController*target;
//            for (UIViewController * controller in weakSelf.navigationController.viewControllers) { //遍历
//                if ([controller.tagPoPController isEqualToString:@"YES"]) {
//                    target=controller;
//                }
//            }
//            if (target) {
//                [weakSelf.navigationController popToViewController:target animated:YES];
//            }else{
                [weakSelf.navigationController popViewControllerAnimated:YES];
//            }
        }
    };
    self.aletView.frame=UIScreen.mainScreen.bounds;
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:self.aletView];
    [self.aletView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(0);
        make.left.mas_equalTo(0);
        make.width.mas_equalTo(SCREENWIDTH);
        make.height.mas_equalTo(SCREENHEIGHT);
    }];
}

@end
