//
//  HtjfPBPTotalFooter.h
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/11.
//  Copyright © 2021 LC. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HtjfPBPTotalFooter : UIView

@property (nonatomic, strong) NSString *buttonText;

@property (nonatomic, copy) void(^selecedBlock)(void);


@end

NS_ASSUME_NONNULL_END
