//
//  HtjfPBPOptionCell.m
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/10.
//  Copyright © 2021 LC. All rights reserved.
//

#import "HtjfPBPOptionCell.h"


@interface HtjfPBPOptionCell ()

@property (weak, nonatomic) IBOutlet UIView *subLine;


@end


@implementation HtjfPBPOptionCell

-(void)ConfigDataWithMd:(HtjfPracticalBenefitModel *)md{
    
    self.leftLabel.text = md.cellTitle;
    
    if (md.desc.length > 0) {
        self.rigthLabel.text = md.desc;
        self.rigthLabel.textColor = [UIColor colorWithHexString:@"0x000000"];
        self.rigthLabel.font = [UIFont boldSystemFontOfSize:16];
    }else{
        self.rigthLabel.text = md.placeString;
        self.rigthLabel.textColor = [UIColor lightGrayColor];
        self.rigthLabel.font = [UIFont systemFontOfSize:16];
    }
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



-(void)lastCellUI{
    
//    [self.limitView mas_remakeConstraints:^(MASConstraintMaker *make) {
//        make.left.equalTo(self.contentView).offset(0);
//        make.bottom.equalTo(self.contentView.mas_bottom);
//        make.right.equalTo(0);
//        make.height.offset(0.5);
//    }];
    
}

-(void)MaxLine{
 
    [self.subLine mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.mas_left).with.offset(0);
        make.right.mas_equalTo(self.mas_right).with.offset(-0);
    }];
    
}

-(void)NormalLine{
 
    [self.subLine mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.mas_left).with.offset(15);
        make.right.mas_equalTo(self.mas_right).with.offset(-15);
    }];
    
}

@end
