//
//  HtjfPBPTextViewCell.m
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/10.
//  Copyright © 2021 LC. All rights reserved.
//

#import "HtjfPBPTextViewCell.h"

#import "ReactiveObjC.h"

@interface HtjfPBPTextViewCell ()<UITextViewDelegate>

@property (weak, nonatomic) IBOutlet UILabel *titleLab;

@property (weak, nonatomic) IBOutlet UITextView *inputView;

@property (strong, nonatomic) UILabel *placeLab;

@property (weak, nonatomic) IBOutlet UIView *subLine;

@property (strong, nonatomic) HtjfPracticalBenefitModel *md;



@property (assign, nonatomic) NSInteger maxLength;

@end



@implementation HtjfPBPTextViewCell


-(void)awakeFromNib{
    
    [super awakeFromNib];
    
    self.inputView.delegate = self;
    
    self.placeLab = [[UILabel alloc] init];

    self.placeLab.text = @"";
    self.placeLab.numberOfLines = 0;
    self.placeLab.textColor = [UIColor lightGrayColor];
    [self.placeLab sizeToFit];
    self.placeLab.font = [UIFont systemFontOfSize:16];
    self.placeLab.textAlignment = NSTextAlignmentRight;
    
    [self.inputView addSubview:self.placeLab];
    [self.inputView setValue:self.placeLab forKey:@"_placeholderLabel"];
    
    
    [[self.inputView rac_textSignal] subscribeNext:^(NSString * _Nullable x) {
       
        // 再筛选长度
        if (x.length > self.maxLength)
        {
            self.inputView.text = [x substringToIndex:self.maxLength];
        }
        else
        {
            
        }
        
    }];
    
    
}

-(void)ConfigDataWithMd:(HtjfPracticalBenefitModel *)md{
    self.md = md;
    self.titleLab.text = md.cellTitle;
    if (md.value && md.value.length > 0) {
        self.inputView.text = md.value;
    }else{
        self.placeLab.text = md.placeString;
        
    }
    
    
    if ([self.md.cellTitle containsString:@"具体原因"] || [self.md.cellTitle containsString:@"居住地址"]) {
        self.maxLength = 100;
    }
    
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    
    self.md.value = textView.text;
    self.md.desc = textView.text;
    
    if (textView.text.length == 0) {
        
        [self.placeLab removeFromSuperview];
        
        self.placeLab = [[UILabel alloc] init];

        self.placeLab.text = @"";
        self.placeLab.numberOfLines = 0;
        self.placeLab.textColor = [UIColor lightGrayColor];
        [self.placeLab sizeToFit];
        self.placeLab.font = [UIFont systemFontOfSize:16];
        self.placeLab.textAlignment = NSTextAlignmentRight;
        
        [self.inputView addSubview:self.placeLab];
        [self.inputView setValue:self.placeLab forKey:@"_placeholderLabel"];
        self.placeLab.text = self.md.placeString;
        
    }else{
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

-(void)MaxLine{
 
    [self.subLine mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.mas_left).with.offset(0);
        make.right.mas_equalTo(self.mas_right).with.offset(-0);
    }];
    
}

-(void)NormalLine{
 
    [self.subLine mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.mas_left).with.offset(15);
        make.right.mas_equalTo(self.mas_right).with.offset(-15);
    }];
    
}

@end
