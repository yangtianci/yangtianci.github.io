//
//  HtjfPBPTextViewCell.h
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/10.
//  Copyright © 2021 LC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HtjfTextView.h"
#import "HtjfPracticalBenefitModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface HtjfPBPTextViewCell : UITableViewCell


-(void)MaxLine;

-(void)NormalLine;

-(void)ConfigDataWithMd:(HtjfPracticalBenefitModel *)md;

@end

NS_ASSUME_NONNULL_END
