//
//  HtjfPBPTotalHeader.h
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/11.
//  Copyright © 2021 LC. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HtjfPBPTotalHeader : UIView


@property (weak, nonatomic) IBOutlet UILabel *titleLab;

// 1 / 2
-(void)ConfigStateWithIdx:(NSInteger)idx;

@property (copy, nonatomic) void(^ClickCallBack)(NSInteger idx);

@end

NS_ASSUME_NONNULL_END
