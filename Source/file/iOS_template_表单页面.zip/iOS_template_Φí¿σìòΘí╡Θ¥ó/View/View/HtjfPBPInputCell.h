//
//  HtjfPBPInputCell.h
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/10.
//  Copyright © 2021 LC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HtjfPracticalBenefitModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface HtjfPBPInputCell : UITableViewCell<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UILabel *leftLabel;

//@property (weak, nonatomic) IBOutlet UIView *rigthView;
//
//@property (weak, nonatomic) IBOutlet UILabel *rigthLabel;

@property (weak, nonatomic) IBOutlet UITextField *textField;


-(void)ConfigDataWithMd:(HtjfPracticalBenefitModel *)md;

-(void)MaxLine;

-(void)NormalLine;

@end

NS_ASSUME_NONNULL_END
