//
//  HtjfPBPTotalHeader.m
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/11.
//  Copyright © 2021 LC. All rights reserved.
//

#import "HtjfPBPTotalHeader.h"

@interface HtjfPBPTotalHeader ()

@property (weak, nonatomic) IBOutlet UIView *bgView;

@property (weak, nonatomic) IBOutlet UIImageView *iconOne;

@property (weak, nonatomic) IBOutlet UIImageView *iconTwo;


@end



@implementation HtjfPBPTotalHeader


-(void)awakeFromNib{
    
    self.bgView.layer.cornerRadius = 8;
    self.bgView.layer.masksToBounds = YES;
    

    
}

-(void)ConfigStateWithIdx:(NSInteger)idx{
    if (idx == 1) {
        _iconOne.highlighted = YES;
        _iconTwo.highlighted = NO;
    }else if (idx == 2){
        _iconOne.highlighted = NO;
        _iconTwo.highlighted = YES;
    }
    
    self.ClickCallBack(idx);
    
}


- (IBAction)btnClickMethod:(UIButton *)sender {
    [self ConfigStateWithIdx:sender.tag - 1000];
}



@end



