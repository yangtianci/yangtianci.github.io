//
//  HtjfPBPTotalFooter.m
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/11.
//  Copyright © 2021 LC. All rights reserved.
//

#import "HtjfPBPTotalFooter.h"


@interface HtjfPBPTotalFooter ()

@property (nonatomic, strong) UIButton *btn;

@end

@implementation HtjfPBPTotalFooter

- (instancetype)init {
    if (self = [super init]) {
        [self addSubview:self.btn];
        self.btn.sd_layout
        .leftSpaceToView(self, 15)
        .rightSpaceToView(self, 15)
        .topSpaceToView(self, 15)
        .heightIs(49);
    }
    return self;
}

- (void)buttonClick {
    if (self.selecedBlock) {
        self.selecedBlock();
    }
}

- (void)setButtonText:(NSString *)buttonText {
    [self.btn setTitle:buttonText forState:UIControlStateNormal];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    UIImage *patter = [UIImage gradientImageWithSize:CGSizeMake(self.width - 30, 49) andColors:@[kColorFromeRGB(@"#6C83C9"), kColorFromeRGB(@"#061D6A")] andGradientType:GradientDirectionLeftToRight];
    [self.btn setBackgroundImage:patter forState:UIControlStateNormal];
}

- (UIButton *)btn {
    if (!_btn) {
        _btn = [UIButton buttonWithType:UIButtonTypeCustom];
        _btn.layer.cornerRadius = 5;
        _btn.layer.masksToBounds = YES;
        [_btn setTitle:@"确认" forState:UIControlStateNormal];
        [_btn addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _btn;
}

@end
