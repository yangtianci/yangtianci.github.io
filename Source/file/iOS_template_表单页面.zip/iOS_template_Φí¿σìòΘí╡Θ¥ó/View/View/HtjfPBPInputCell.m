//
//  HtjfPBPInputCell.m
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/10.
//  Copyright © 2021 LC. All rights reserved.
//

#import "HtjfPBPInputCell.h"
#import "ReactiveObjC.h"

@interface HtjfPBPInputCell ()

@property (strong, nonatomic) HtjfPracticalBenefitModel *md;

@property (weak, nonatomic) IBOutlet UIView *subLine;

@property (assign, nonatomic) NSInteger maxLength;

@end

@implementation HtjfPBPInputCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.textField.delegate = self;
    
//    [self.textField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];

    [[self.textField rac_textSignal] subscribeNext:^(NSString * _Nullable x) {
       
        // 先筛选不符合的字符
        
//        NSRegularExpression *expression = [NSRegularExpression regularExpressionWithPattern:@"[^a-zA-Z-_ 0-9：“，。：# & @ . ； - _ （ ）|  / ”]" options:NSRegularExpressionCaseInsensitive error:nil];
//
//        NSArray *resultArr = [expression matchesInString:x options:NSMatchingReportCompletion range:NSMakeRange(0, x.length)];
//
//        NSMutableString *resultString = [NSMutableString stringWithString:x];
//
//        for (int i = 0; i < resultArr.count; i++) {
//            NSTextCheckingResult *result = resultArr[i];
//            NSLog(@"resultArr 内存储的数据 %d - %d",result.range.location,result.range.length);
//        }
//
//        NSLog(@"%zd ???????",resultString.length);
//
//        for (int i = resultArr.count - 1; i >= 0 ; i--) {
//            NSTextCheckingResult *result = resultArr[i];
//
////            if (result.range.location + result.range.length >= resultString.length) {
////
////            }else{
//
////                NSLog(@"\n\n 本次准备删除的数据为  %@ \n\n",  )
//
//
//                resultString = [resultString substringWithRange:result.range];
//
////                [resultString replaceCharactersInRange:result.range withString:@""];
//
////            }
//
//            NSLog(@"\n\n idx = %d range = %d - %d, resultString = %@ length = %zd\n\n",i, result.range.location, result.range.length, resultString, resultString.length);
//
//
//        }
//
//        x = resultString;
//        NSLog(@"\n 此时 x = %@",x);
        
        // 再筛选长度
        if (x.length > self.maxLength)
        {
            self.textField.text = [x substringToIndex:self.maxLength];
        }
        else
        {
            
        }
        
    }];
    
    
}

//- (void)textFieldDidChange:(UITextField *)textField {
    
    
//    NSRegularExpression *expression = [NSRegularExpression regularExpressionWithPattern:@"[^a-zA-Z-_ 0-9：“，。：# & @ . ； - _ （ ）|  / ”]" options:NSRegularExpressionCaseInsensitive error:nil];
//
//    NSArray *resultArr = [expression matchesInString:textField.text options:NSMatchingReportCompletion range:NSMakeRange(0, textField.text.length)];
//
//    NSMutableString *resultString = [NSMutableString stringWithString:textField.text];
//
//    for (NSUInteger i = resultArr.count; i > 0; i--) {
//        NSTextCheckingResult *result = resultArr[i];
//
//        if (result.range.location + result.range.length > resultString.length) {
//
//        }else{
//            if (result.range.location == 0 && result.range.location == 0 && resultString.length > 0) {
//                [resultString replaceCharactersInRange:NSMakeRange(0, 1) withString:@""];
//            }else{
//                [resultString replaceCharactersInRange:result.range withString:@""];
//            }
//        }
//}
//
//    textField.text = resultString;
    
//}

//- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
//{
//
//   if (range.location>= self.maxLength)
//   {
//       return  NO;
//   }
//   else
//   {
//       return YES;
//   }
//}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    
    self.md.value = textField.text;
    self.md.desc = textField.text;
    
    if (textField.text.length == 0) {
        self.textField.placeholder = self.md.placeString;
        self.textField.font = [UIFont systemFontOfSize:16];
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)ConfigDataWithMd:(HtjfPracticalBenefitModel *)md{
    
    self.md = md;
    
    if ([self.md.cellTitle containsString:@"出生城市"] || [self.md.cellTitle containsString:@"居住地址"] || [self.md.cellTitle containsString:@"识别号"] || [self.md.cellTitle containsString:@"具体原因"] || [self.md.cellTitle containsString:@"名"] || [self.md.cellTitle containsString:@"姓"]) {
        self.maxLength = 100;
    }
    
    self.leftLabel.text = md.cellTitle;
    if ([self.md.cellTitle containsString:@"姓"] || [self.md.cellTitle containsString:@"名"]) {
        NSRange attRange = [self.md.cellTitle rangeOfString:@"(英文或拼音)"];
        
        NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc]initWithString:self.md.cellTitle];
        [attStr addAttributes:@{NSForegroundColorAttributeName : [UIColor lightGrayColor]} range:attRange];
        self.leftLabel.attributedText = attStr;
    }
    
    
    if (md.value && md.value.length > 0 && ![md.value isEqualToString:@"(null)"]) {
        self.textField.text = md.value;
        self.textField.font = [UIFont boldSystemFontOfSize:16];
    }else{
        self.textField.placeholder = md.placeString;
        self.textField.font = [UIFont systemFontOfSize:16];
        
    }
    
    
    
}

-(void)MaxLine{
 
    [self.subLine mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.mas_left).with.offset(0);
        make.right.mas_equalTo(self.mas_right).with.offset(-0);
    }];
    
}

-(void)NormalLine{
 
    [self.subLine mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.mas_left).with.offset(15);
        make.right.mas_equalTo(self.mas_right).with.offset(-15);
    }];
    
}

@end
