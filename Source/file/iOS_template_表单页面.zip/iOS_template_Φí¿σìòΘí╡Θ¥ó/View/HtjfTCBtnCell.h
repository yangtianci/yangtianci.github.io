//
//  HtjfTCBtnCell.h
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/15.
//  Copyright © 2021 LC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HtjfPracticalBenefitModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface HtjfTCBtnCell : UITableViewCell

@property (copy, nonatomic) void(^AorrDCallBack)(HtjfPracticalBenefitModel *md);

-(void)ConfigDataWithMd:(HtjfPracticalBenefitModel *)md;

@end

NS_ASSUME_NONNULL_END
