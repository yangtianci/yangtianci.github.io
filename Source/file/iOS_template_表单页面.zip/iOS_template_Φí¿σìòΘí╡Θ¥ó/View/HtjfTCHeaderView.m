//
//  HtjfTCHeaderView.m
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/15.
//  Copyright © 2021 LC. All rights reserved.
//

#import "HtjfTCHeaderView.h"

@implementation HtjfTCHeaderView


-(void)awakeFromNib{
    self.bgView.layer.cornerRadius = 4;
    self.bgView.layer.masksToBounds = YES;

}


@end
