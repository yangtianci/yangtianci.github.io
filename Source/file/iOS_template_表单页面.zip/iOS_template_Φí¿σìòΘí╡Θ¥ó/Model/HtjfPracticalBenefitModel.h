//
//  HtjfPracticalBenefitModel.h
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/8.
//  Copyright © 2021 LC. All rights reserved.
//

#import "BaseModel.h"
#import "HtjfPracticalBenefitPersonControllerViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface HtjfPracticalBenefitModel : BaseModel

// cell 的基本数据
@property (strong, nonatomic) NSString *cellTitle;
@property (strong, nonatomic) NSString *placeString;

@property (strong, nonatomic) NSString *key;
@property (strong, nonatomic) NSString *value;

@property (strong, nonatomic) NSNumber *cellType;

// cell 高级数据
@property (strong, nonatomic) NSString *optionTitle;
@property (strong, nonatomic) NSMutableArray *optionsArr;// 选项的文字描述
@property (strong, nonatomic) NSMutableArray *optionsVaArray;// 选项的参数

@property (strong, nonatomic) NSString *desc;




// 关于选项的一个数据串设置
@property (assign, nonatomic) BOOL isBePlace;
@property (strong, nonatomic) NSIndexPath *indexPath;
@property (strong, nonatomic) NSString *dataType;// 身份, 中地区, 原因


@end

NS_ASSUME_NONNULL_END
