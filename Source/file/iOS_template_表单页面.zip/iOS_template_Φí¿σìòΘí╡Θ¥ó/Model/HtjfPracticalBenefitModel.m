//
//  HtjfPracticalBenefitModel.m
//  HtmzApp
//
//  Created by 杨天赐 on 2021/11/8.
//  Copyright © 2021 LC. All rights reserved.
//

#import "HtjfPracticalBenefitModel.h"

@implementation HtjfPracticalBenefitModel

@end
